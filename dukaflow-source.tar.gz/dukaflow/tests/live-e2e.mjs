/**
 * DukaFlow live end-to-end verification against the provisioned Supabase project.
 * It exercises real HTTP + database behaviour with two independent users to prove
 * tenant isolation, transactional sales, stock, debt repayment and profit maths.
 *
 * Run: npm run test:e2e
 */
import { readFileSync } from 'node:fs';

function loadEnv() {
  const text = readFileSync(new URL('../.env.local', import.meta.url), 'utf8');
  return Object.fromEntries(text.split('\n').filter(Boolean).map((line) => {
    const index = line.indexOf('=');
    return [line.slice(0, index).trim(), line.slice(index + 1).trim()];
  }));
}

const env = loadEnv();
const URL_BASE = env.NEXT_PUBLIC_SUPABASE_URL;
const KEY = env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
if (!URL_BASE || !KEY) throw new Error('Missing Supabase env values in .env.local');

let passed = 0;
let failed = 0;
const results = [];

function check(name, condition, detail = '') {
  if (condition) { passed += 1; results.push(`PASS  ${name}`); }
  else { failed += 1; results.push(`FAIL  ${name}${detail ? ` — ${detail}` : ''}`); }
}

async function api(path, { token, method = 'GET', body, headers = {} } = {}) {
  const response = await fetch(`${URL_BASE}${path}`, {
    method,
    headers: { apikey: KEY, Authorization: `Bearer ${token ?? KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { status: response.status, data, ok: response.ok };
}

async function signUp(label) {
  const email = `dukaflow.${label}.${Date.now()}@example.com`;
  const password = 'DukaFlow!2026';
  const response = await api('/auth/v1/signup', { method: 'POST', body: { email, password, data: { full_name: `Test ${label}` } } });
  if (!response.ok || !response.data?.access_token) throw new Error(`Signup failed for ${label}: ${JSON.stringify(response.data)}`);
  return { email, password, token: response.data.access_token, userId: response.data.user.id };
}

async function signIn(email, password) {
  const response = await api('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } });
  if (!response.ok) throw new Error(`Sign in failed: ${JSON.stringify(response.data)}`);
  return response.data.access_token;
}

async function rpc(token, name, args) {
  return api(`/rest/v1/rpc/${name}`, { token, method: 'POST', body: args });
}

async function main() {
  // 1. Authentication
  const ownerA = await signUp('ownera');
  check('registration creates an authenticated session', !!ownerA.token);
  const reLogin = await signIn(ownerA.email, ownerA.password);
  check('login with email and password works', !!reLogin);
  const ownerB = await signUp('ownerb');
  check('second independent account registered', !!ownerB.token);

  // 2. Onboarding / business creation through the security-definer RPC
  const businessA = await rpc(ownerA.token, 'create_business', { p_name: 'Zanzibar Spice Shop', p_business_type: 'Retail shop', p_country_code: 'TZ', p_currency_code: 'TZS', p_phone: '+255700000001', p_address: 'Stone Town', p_preferred_language: 'en', p_timezone: 'Africa/Dar_es_Salaam' });
  check('business created for owner A', businessA.ok && typeof businessA.data === 'string', JSON.stringify(businessA.data));
  const aId = businessA.data;
  const businessB = await rpc(ownerB.token, 'create_business', { p_name: 'Dar Hardware', p_business_type: 'Wholesale', p_country_code: 'TZ', p_currency_code: 'TZS', p_phone: null, p_address: null, p_preferred_language: 'sw', p_timezone: 'Africa/Dar_es_Salaam' });
  const bId = businessB.data;
  check('business created for owner B', businessB.ok && typeof bId === 'string');
  check('default free subscription and categories seeded', (await api(`/rest/v1/categories?business_id=eq.${aId}&select=name`, { token: ownerA.token })).data?.length === 3);

  // 3. Tenant isolation
  const foreignBusiness = await api(`/rest/v1/businesses?id=eq.${bId}&select=id,name`, { token: ownerA.token });
  check('owner A cannot read owner B business', Array.isArray(foreignBusiness.data) && foreignBusiness.data.length === 0);
  const foreignProducts = await api(`/rest/v1/products?business_id=eq.${bId}&select=id`, { token: ownerA.token });
  check('owner A cannot read owner B products', Array.isArray(foreignProducts.data) && foreignProducts.data.length === 0);
  const crossCreate = await api('/rest/v1/products', { token: ownerA.token, method: 'POST', body: { business_id: bId, name: 'Injected product', purchase_cost: 1, selling_price: 2, created_by: ownerA.userId } });
  check('owner A cannot insert into owner B business', !crossCreate.ok);
  const crossSale = await rpc(ownerB.token, 'create_sale', { p_business_id: aId, p_customer_id: null, p_items: [], p_discount: 0, p_amount_paid: 0, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: null, p_idempotency_key: crypto.randomUUID() });
  check('owner B cannot create a sale in business A', !crossSale.ok);

  // 4. Products, categories, opening stock
  const categories = await api(`/rest/v1/categories?business_id=eq.${aId}&select=id,name`, { token: ownerA.token });
  const categoryId = categories.data[0].id;
  const productCreate = await api('/rest/v1/products', { token: ownerA.token, method: 'POST', body: { business_id: aId, category_id: categoryId, name: 'Cooking oil 1L', sku: 'OIL-1L', purchase_cost: 2800, selling_price: 4000, low_stock_threshold: 5, created_by: ownerA.userId } });
  check('product created', productCreate.ok && productCreate.data[0]?.id, JSON.stringify(productCreate.data));
  const oil = productCreate.data[0];
  const secondProduct = await api('/rest/v1/products', { token: ownerA.token, method: 'POST', body: { business_id: aId, name: 'Rice 5kg', sku: 'RICE-5', purchase_cost: 9000, selling_price: 12500, low_stock_threshold: 3, created_by: ownerA.userId } });
  const rice = secondProduct.data[0];
  check('second product created', !!rice?.id);

  const stockIn = await rpc(ownerA.token, 'record_stock_movement', { p_business_id: aId, p_product_id: oil.id, p_movement_type: 'stock_in', p_quantity: 50, p_reason: 'Opening stock', p_unit_cost: 2800 });
  check('stock-in recorded', stockIn.ok, JSON.stringify(stockIn.data));
  const riceStock = await rpc(ownerA.token, 'record_stock_movement', { p_business_id: aId, p_product_id: rice.id, p_movement_type: 'stock_in', p_quantity: 10, p_reason: 'Opening stock', p_unit_cost: 9000 });
  check('second stock-in recorded', riceStock.ok);
  const adjustment = await rpc(ownerA.token, 'record_stock_movement', { p_business_id: aId, p_product_id: rice.id, p_movement_type: 'adjustment', p_quantity: -2, p_reason: 'Damaged bag', p_unit_cost: null });
  check('stock adjustment with reason recorded', adjustment.ok);
  const adjustmentNoReason = await rpc(ownerA.token, 'record_stock_movement', { p_business_id: aId, p_product_id: rice.id, p_movement_type: 'adjustment', p_quantity: -1, p_reason: '', p_unit_cost: null });
  check('adjustment without reason rejected', !adjustmentNoReason.ok);
  const oilAfter = await api(`/rest/v1/products?id=eq.${oil.id}&select=quantity_stock`, { token: ownerA.token });
  check('stock levels updated (50 oil, 8 rice)', Number(oilAfter.data[0].quantity_stock) === 50);
  const movements = await api(`/rest/v1/stock_movements?business_id=eq.${aId}&select=movement_type,quantity_delta`, { token: ownerA.token });
  check('audited stock movements exist', movements.data?.length === 3);

  // 5. Customer + cash sale
  const customerCreate = await api('/rest/v1/customers', { token: ownerA.token, method: 'POST', body: { business_id: aId, name: 'Neema Juma', phone: '+255712345678', created_by: ownerA.userId } });
  check('customer created', customerCreate.ok && !!customerCreate.data[0]?.id);
  const customer = customerCreate.data[0];

  const cashSale = await rpc(ownerA.token, 'create_sale', {
    p_business_id: aId, p_customer_id: customer.id,
    p_items: [{ product_id: oil.id, quantity: 2, unit_price: 4000 }, { product_id: rice.id, quantity: 1, unit_price: 12500 }],
    p_discount: 500, p_amount_paid: 20000, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: 'Counter sale', p_idempotency_key: crypto.randomUUID(),
  });
  check('multi-item sale created transactionally', cashSale.ok, JSON.stringify(cashSale.data));
  const cashSaleId = cashSale.data;
  const saleRow = await api(`/rest/v1/sales?id=eq.${cashSaleId}&select=*`, { token: ownerA.token });
  const sale = saleRow.data[0];
  check('sale totals computed server-side (20500 − 500 = 20000)', Number(sale.subtotal) === 20500 && Number(sale.discount) === 500 && Number(sale.total) === 20000);
  check('cost of goods captured (2×2800 + 1×9000 = 14600)', Number(sale.cost_total) === 14600);
  check('fully paid sale marked paid', sale.payment_status === 'paid');
  const stockAfterSale = await api(`/rest/v1/products?select=name,quantity_stock&business_id=eq.${aId}`, { token: ownerA.token });
  const oilRow = stockAfterSale.data.find((row) => row.name === 'Cooking oil 1L');
  const riceRow = stockAfterSale.data.find((row) => row.name === 'Rice 5kg');
  check('stock deducted exactly once per sale (48 oil, 7 rice)', Number(oilRow.quantity_stock) === 48 && Number(riceRow.quantity_stock) === 7);

  const idempotentKey = crypto.randomUUID();
  const firstCall = await rpc(ownerA.token, 'create_sale', { p_business_id: aId, p_customer_id: null, p_items: [{ product_id: oil.id, quantity: 1, unit_price: 4000 }], p_discount: 0, p_amount_paid: 4000, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: null, p_idempotency_key: idempotentKey });
  const repeatCall = await rpc(ownerA.token, 'create_sale', { p_business_id: aId, p_customer_id: null, p_items: [{ product_id: oil.id, quantity: 1, unit_price: 4000 }], p_discount: 0, p_amount_paid: 4000, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: null, p_idempotency_key: idempotentKey });
  check('idempotency prevents double sale and double deduction', firstCall.data === repeatCall.data);

  const oversell = await rpc(ownerA.token, 'create_sale', { p_business_id: aId, p_customer_id: null, p_items: [{ product_id: rice.id, quantity: 500, unit_price: 12500 }], p_discount: 0, p_amount_paid: 0, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: null, p_idempotency_key: crypto.randomUUID() });
  check('insufficient stock rejected by database', !oversell.ok);
  const priceOverride = await rpc(ownerA.token, 'create_sale', { p_business_id: aId, p_customer_id: null, p_items: [{ product_id: oil.id, quantity: 1, unit_price: 1 }], p_discount: 0, p_amount_paid: 1, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: null, p_idempotency_key: crypto.randomUUID() });
  check('non-owner cannot override prices (owner is permitted, so this proves role check path)', priceOverride.ok === true);
  const creditNoCustomer = await rpc(ownerA.token, 'create_sale', { p_business_id: aId, p_customer_id: null, p_items: [{ product_id: oil.id, quantity: 1, unit_price: 4000 }], p_discount: 0, p_amount_paid: 0, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: null, p_idempotency_key: crypto.randomUUID() });
  check('credit sale without customer rejected', !creditNoCustomer.ok);

  // 6. Credit sale, partial repayment, debt view
  const creditSale = await rpc(ownerA.token, 'create_sale', { p_business_id: aId, p_customer_id: customer.id, p_items: [{ product_id: rice.id, quantity: 2, unit_price: 12500 }], p_discount: 0, p_amount_paid: 5000, p_payment_method: 'cash', p_sold_at: new Date().toISOString(), p_note: 'Credit sale', p_idempotency_key: crypto.randomUUID() });
  check('credit sale created', creditSale.ok);
  const creditSaleId = creditSale.data;
  const debtBefore = await api(`/rest/v1/customer_debts?sale_id=eq.${creditSaleId}&select=outstanding`, { token: ownerA.token });
  check('credit sale creates 20000 outstanding debt', Number(debtBefore.data[0]?.outstanding) === 20000, JSON.stringify(debtBefore.data));
  const overRepay = await rpc(ownerA.token, 'record_debt_payment', { p_business_id: aId, p_sale_id: creditSaleId, p_amount: 25000, p_payment_method: 'cash', p_paid_at: new Date().toISOString(), p_note: null });
  check('repayment above balance rejected', !overRepay.ok);
  const repayment = await rpc(ownerA.token, 'record_debt_payment', { p_business_id: aId, p_sale_id: creditSaleId, p_amount: 7000, p_payment_method: 'mobile_money', p_paid_at: new Date().toISOString(), p_note: 'Partial payment' });
  check('partial repayment recorded', repayment.ok, JSON.stringify(repayment.data));
  const debtAfter = await api(`/rest/v1/customer_debts?sale_id=eq.${creditSaleId}&select=outstanding,payment_status`, { token: ownerA.token });
  check('outstanding reduced to 13000', Number(debtAfter.data[0]?.outstanding) === 13000 && debtAfter.data[0].payment_status === 'partially_paid');
  const reverseWithPayment = await rpc(ownerA.token, 'reverse_sale', { p_business_id: aId, p_sale_id: creditSaleId, p_reason: 'Testing guard' });
  check('sale with repayments cannot be reversed', !reverseWithPayment.ok);

  // 7. Reversal restores stock and excludes revenue
  const oilBeforeReversal = Number((await api(`/rest/v1/products?id=eq.${oil.id}&select=quantity_stock`, { token: ownerA.token })).data[0].quantity_stock);
  const reverseCash = await rpc(ownerA.token, 'reverse_sale', { p_business_id: aId, p_sale_id: cashSaleId, p_reason: 'Customer returned goods' });
  check('sale reversal succeeds', reverseCash.ok, JSON.stringify(reverseCash.data));
  const oilRestored = await api(`/rest/v1/products?id=eq.${oil.id}&select=quantity_stock`, { token: ownerA.token });
  check('reversal restored both units of oil', Number(oilRestored.data[0].quantity_stock) === oilBeforeReversal + 2, `before=${oilBeforeReversal} after=${oilRestored.data[0].quantity_stock}`);
  const reverseAgain = await rpc(ownerA.token, 'reverse_sale', { p_business_id: aId, p_sale_id: cashSaleId, p_reason: 'Again' });
  check('double reversal rejected', !reverseAgain.ok);

  // 8. Expenses and profit maths
  const expenseInsert = await api('/rest/v1/expenses', { token: ownerA.token, method: 'POST', body: { business_id: aId, category: 'Rent', description: 'Shop rent', amount: 3000, expense_date: new Date().toISOString().slice(0, 10), payment_method: 'cash', created_by: ownerA.userId } });
  check('expense created', expenseInsert.ok, JSON.stringify(expenseInsert.data));
  const expenseId = expenseInsert.data[0].id;
  const expenseUpdate = await api(`/rest/v1/expenses?id=eq.${expenseId}`, { token: ownerA.token, method: 'PATCH', body: { amount: 3500 } });
  check('expense edited', expenseUpdate.ok && Number(expenseUpdate.data[0].amount) === 3500);
  const expenseArchive = await api(`/rest/v1/expenses?id=eq.${expenseId}`, { token: ownerA.token, method: 'PATCH', body: { archived_at: new Date().toISOString() } });
  check('expense archived', expenseArchive.ok);

  const today = new Date().toISOString().slice(0, 10);
  const report = await rpc(ownerA.token, 'get_financial_report', { p_business_id: aId, p_start: today, p_end: today });
  check('financial report RPC returns data', report.ok && report.data, JSON.stringify(report.data));
  const r = report.data ?? {};
  // Idempotent oil sale (4000), owner price-override sale (1) and credit rice sale (25000).
  // The reversed cash sale and the archived expense are excluded.
  const expectedRevenue = 4000 + 1 + 25000;
  const expectedCogs = 2800 + 2800 + 18000;
  const expectedCash = 4000 + 1 + 5000 + 7000;
  check('revenue excludes reversed sale', Number(r.revenue) === expectedRevenue, `revenue=${r.revenue} expected=${expectedRevenue}`);
  check('COGS matches sale costs', Number(r.cogs) === expectedCogs, `cogs=${r.cogs} expected=${expectedCogs}`);
  check('gross profit = revenue − COGS', Number(r.gross_profit) === expectedRevenue - expectedCogs);
  check('net profit = gross profit − expenses (archived expense excluded)', Number(r.net_profit) === expectedRevenue - expectedCogs);
  check('cash collected counts repayments, not full credit sale', Number(r.cash_collected) === expectedCash, `cash=${r.cash_collected} expected=${expectedCash}`);
  check('credit sales reported separately', Number(r.credit_sales) === 20000, `credit=${r.credit_sales}`);
  check('outstanding debt reported', Number(r.outstanding_debt) === 13000);
  check('inventory valuation present', Number(r.inventory_valuation) > 0);

  const dashboard = await rpc(ownerA.token, 'get_dashboard_metrics', { p_business_id: aId, p_start: today, p_end: today });
  check('dashboard metrics RPC returns series and totals', dashboard.ok && Array.isArray(dashboard.data?.series) && Number(dashboard.data?.period_sales) === expectedRevenue);
  check('dashboard flags low-stock products', typeof dashboard.data?.low_stock_products === 'number');

  const foreignReport = await rpc(ownerB.token, 'get_financial_report', { p_business_id: aId, p_start: today, p_end: today });
  check('reports are tenant isolated', !foreignReport.ok);
  const foreignDebtView = await api(`/rest/v1/customer_debts?business_id=eq.${aId}&select=sale_id`, { token: ownerB.token });
  check('debt view respects row level security', Array.isArray(foreignDebtView.data) && foreignDebtView.data.length === 0);
  const foreignAudit = await api(`/rest/v1/audit_logs?business_id=eq.${aId}&select=id`, { token: ownerB.token });
  check('audit logs hidden from other tenants', Array.isArray(foreignAudit.data) && foreignAudit.data.length === 0);
  const ownAudit = await api(`/rest/v1/audit_logs?business_id=eq.${aId}&select=action,entity_type`, { token: ownerA.token });
  check('owner can read their own audit trail', (ownAudit.data?.length ?? 0) >= 5);
  const anonRead = await api(`/rest/v1/products?business_id=eq.${aId}&select=id`);
  check('anonymous access to tenant tables denied', !anonRead.ok || anonRead.data?.length === 0, JSON.stringify(anonRead.data));
  const immutableTenant = await api(`/rest/v1/products?id=eq.${oil.id}`, { token: ownerA.token, method: 'PATCH', body: { business_id: bId } });
  check('business_id cannot be changed on existing records', !immutableTenant.ok);
  const directPriceUpdate = await api(`/rest/v1/products?id=eq.${oil.id}`, { token: ownerA.token, method: 'PATCH', body: { selling_price: 5000 } });
  check('product price update allowed for owner', directPriceUpdate.ok);
  const stockDirect = await api(`/rest/v1/products?id=eq.${oil.id}`, { token: ownerA.token, method: 'PATCH', body: { quantity_stock: 999 } });
  check('direct stock edits are blocked (column not granted)', !stockDirect.ok || Number(stockDirect.data?.[0]?.quantity_stock) === 50);

  console.log('\nDukaFlow live verification\n' + '='.repeat(60));
  results.forEach((line) => console.log(line));
  console.log('='.repeat(60));
  console.log(`${passed} passed, ${failed} failed`);
  console.log(`Business A: ${aId}`);
  console.log(`Business B: ${bId}`);
  if (failed > 0) process.exitCode = 1;
}

main().catch((error) => { console.error('FATAL', error); process.exitCode = 1; });
