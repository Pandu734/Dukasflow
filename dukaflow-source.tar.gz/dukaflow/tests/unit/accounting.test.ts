import { describe, expect, it } from 'vitest';
import { calculateAccounting, outstanding, roundMoney } from '@/lib/accounting';
import { currency, isoDate, number as formatNumber } from '@/lib/format';
import { translate } from '@/lib/translations';

describe('accounting', () => {
  it('gross profit equals revenue minus COGS', () => {
    const result = calculateAccounting({ revenue: 20000, cogs: 14600, expenses: 0, initialCash: 20000, debtRepayments: 0 });
    expect(result.grossProfit).toBe(5400);
  });

  it('net profit equals gross profit minus operating expenses', () => {
    const result = calculateAccounting({ revenue: 20500, cogs: 14600, expenses: 3500, initialCash: 20000, debtRepayments: 0 });
    expect(result.grossProfit).toBe(5900);
    expect(result.netProfit).toBe(2400);
  });

  it('keeps cash collected separate from revenue and includes repayments', () => {
    const result = calculateAccounting({ revenue: 25000, cogs: 18000, expenses: 0, initialCash: 5000, debtRepayments: 7000 });
    expect(result.revenue).toBe(25000);
    expect(result.cashCollected).toBe(12000);
    expect(result.grossProfit).toBe(7000);
    expect(result.netProfit).toBe(7000);
  });

  it('credit sales never inflate cash collected', () => {
    const result = calculateAccounting({ revenue: 50000, cogs: 30000, expenses: 0, initialCash: 0, debtRepayments: 0 });
    expect(result.cashCollected).toBe(0);
    expect(result.grossProfit).toBe(20000);
  });

  it('negative profit is reported, not clamped', () => {
    const result = calculateAccounting({ revenue: 1000, cogs: 1200, expenses: 500, initialCash: 1000, debtRepayments: 0 });
    expect(result.grossProfit).toBe(-200);
    expect(result.netProfit).toBe(-700);
  });

  it('rounds money to two decimals without float drift', () => {
    expect(roundMoney(0.1 + 0.2)).toBe(0.3);
    expect(roundMoney(1234.567)).toBe(1234.57);
  });

  it('outstanding balance never goes below zero', () => {
    expect(outstanding(20000, 5000)).toBe(15000);
    expect(outstanding(20000, 25000)).toBe(0);
  });
});

describe('local formatting', () => {
  it('formats TZS without decimals for English and Swahili', () => {
    expect(currency(20000, 'TZS', 'en')).toContain('20,000');
    expect(currency(20000, 'TZS', 'sw')).toContain('20,000');
  });

  it('formats other currencies with their own symbol', () => {
    expect(currency(12.5, 'USD', 'en')).toContain('$');
    expect(currency(12.5, 'USD', 'en')).toContain('12.50');
  });

  it('groups large numbers locally', () => {
    expect(formatNumber(1250000, 'en')).toBe('1,250,000');
  });

  it('produces an ISO date string', () => {
    expect(isoDate(new Date('2026-11-17T09:00:00Z'))).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });
});

describe('translations', () => {
  it('returns Swahili strings', () => {
    expect(translate('sw', 'dashboard')).toBe('Dashibodi');
    expect(translate('sw', 'netProfit')).toBe('Faida halisi');
  });

  it('falls back to English keys', () => {
    expect(translate('en', 'sales')).toBe('Sales');
  });
});
