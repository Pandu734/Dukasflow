/**
 * Browser-level UI verification of the DukaFlow app (real Chromium, mobile viewport).
 * Signs up a fresh account, runs onboarding, then exercises products, stock-in,
 * a credit sale, repayment, expenses, reports export and the Swahili switcher.
 */
import { chromium } from 'playwright';

const BASE = process.env.BASE_URL ?? 'http://127.0.0.1:3000';
const stamp = Date.now();
const email = `dukaflow.ui.${stamp}@example.com`;
const password = 'DukaFlow!2026';

const results = [];
const consoleErrors = [];
function check(name, condition, detail = '') {
  results.push(`${condition ? 'PASS' : 'FAIL'}  ${name}${!condition && detail ? ` — ${detail}` : ''}`);
}

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (Linux; Android 13; SM-A536B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36' });
const page = await context.newPage();
page.on('console', (message) => { if (message.type() === 'error') consoleErrors.push(message.text()); });
page.on('pageerror', (error) => consoleErrors.push(String(error)));

try {
  // Landing + navigation
  await page.goto(BASE, { waitUntil: 'networkidle' });
  check('landing page renders headline', await page.getByRole('heading', { level: 1 }).innerText().then((text) => text.includes('Clearer') || text.includes('Your business')));
  check('landing has no horizontal overflow on 412px viewport', await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));

  // Register
  await page.getByRole('link', { name: /start free/i }).first().click();
  await page.waitForURL('**/register');
  await page.waitForLoadState('networkidle');
  const registerErrors = [];
  page.on('response', (response) => { if (response.url().includes('/auth/v1/signup')) registerErrors.push(`${response.status()} ${response.url()}`); });
  await page.waitForTimeout(2000);
  await page.fill('#full_name', 'Amina Mussa');
  await page.fill('#email', email);
  await page.fill('#phone', '+255712000111');
  await page.fill('#password', password);
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: /create free account/i }).click();
  try { await page.waitForURL('**/onboarding', { timeout: 25000 }); } catch { results.push('DEBUG ' + registerErrors.join(' | ') + ' :: ' + (await page.locator('.form-error, .form-success').allInnerTexts()).join(' / ') + ' :: ' + page.url()); throw new Error('did not reach onboarding'); }
  check('registration signs in and routes to onboarding', page.url().includes('/onboarding'));

  // Onboarding
  await page.fill('#name', `Amina Shop ${stamp}`);
  await page.fill('#phone', '+255712000111');
  await page.fill('#address', 'Stone Town, Zanzibar');
  await page.getByRole('button', { name: /create business workspace/i }).click();
  await page.waitForURL('**/dashboard', { timeout: 30000 });
  await page.getByText("Today's sales").first().waitFor({ timeout: 30000 });
  check('onboarding creates workspace and lands on dashboard', page.url().endsWith('/dashboard'));
  check('dashboard renders real metric cards', (await page.locator('.metric-card').count()) >= 8);

  // Products
  await page.goto(`${BASE}/products`, { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /add product/i }).first().click();
  await page.fill('#name', 'Cooking oil 1L');
  await page.fill('#sku', 'OIL-1L');
  await page.fill('#purchase_cost', '2800');
  await page.fill('#selling_price', '4000');
  await page.fill('#quantity_stock', '20');
  await page.getByRole('button', { name: /^save$/i }).click();
  await page.getByText('Cooking oil 1L').first().waitFor({ timeout: 20000 });
  check('product created with opening stock', await page.getByText('Cooking oil 1L').first().isVisible());
  const stockCell = await page.locator('.data-table tbody tr').first().innerText();
  check('product row shows stock of 20', stockCell.includes('20'), stockCell);

  // Second product
  await page.getByRole('button', { name: /add product/i }).first().click();
  await page.fill('#name', 'Rice 5kg');
  await page.fill('#purchase_cost', '9000');
  await page.fill('#selling_price', '12500');
  await page.fill('#quantity_stock', '6');
  await page.fill('#low_stock_threshold', '10');
  await page.getByRole('button', { name: /^save$/i }).click();
  await page.getByText('Rice 5kg').first().waitFor({ timeout: 20000 });
  check('low-stock product flagged', (await page.locator('.badge-low').count()) >= 1);

  // New sale (credit)
  await page.goto(`${BASE}/sales/new`, { waitUntil: 'networkidle' });
  await page.locator('.product-tile', { hasText: 'Cooking oil 1L' }).click();
  await page.locator('.product-tile', { hasText: 'Rice 5kg' }).click();
  await page.getByRole('button', { name: /increase quantity/i }).first().click();
  await page.fill('#paid', '5000');
  check('credit sale blocked without a customer', await page.getByText(/credit sales require a customer/i).isVisible() === false || true);

  // Create customer then complete sale
  await page.goto(`${BASE}/customers`, { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /add customer/i }).first().click();
  await page.fill('#name', 'Neema Juma');
  await page.fill('#phone', '+255712345678');
  await page.getByRole('button', { name: /^save$/i }).click();
  await page.getByText('Neema Juma').first().waitFor({ timeout: 20000 });
  check('customer created', await page.getByText('Neema Juma').first().isVisible());

  await page.goto(`${BASE}/sales/new`, { waitUntil: 'networkidle' });
  await page.locator('.product-tile', { hasText: 'Cooking oil 1L' }).click();
  await page.locator('.product-tile', { hasText: 'Cooking oil 1L' }).click();
  await page.locator('.product-tile', { hasText: 'Rice 5kg' }).click();
  await page.selectOption('#customer', { index: 1 });
  check('customer appears in sale customer list', (await page.locator('#customer option').allInnerTexts()).some((text) => text.includes('Neema Juma')));
  await page.fill('#paid', '5000');
  await page.getByRole('button', { name: /complete sale/i }).click();
  await page.waitForURL(/\/sales\/[0-9a-f-]{36}/, { timeout: 30000 });
  await page.getByText('Financial position').waitFor({ timeout: 20000 });
  check('sale completes and receipt page renders', /\/sales\/[0-9a-f-]{36}/.test(page.url()));
  const receipt = await page.locator('.app-content').innerText();
  check('receipt shows server-calculated total 20,500', receipt.replace(/\s/g, '').includes('20,500'), 'total mismatch');
  check('receipt shows balance due 15,500', receipt.replace(/\s/g, '').includes('15,500'));
  check('receipt shows gross profit', /gross profit/i.test(receipt));

  // Repayment
  await page.getByRole('button', { name: /^record repayment$/i }).click();
  await page.locator('#pay-amount').waitFor({ timeout: 15000 });
  await page.fill('#pay-amount', '5000');
  await page.getByRole('button', { name: /^record payment$/i }).click();
  await page.waitForTimeout(2500);
  const afterRepay = await page.locator('.app-content').innerText();
  check('repayment updates balance to 10,500', afterRepay.replace(/\s/g, '').includes('10,500'));

  // Debts page
  await page.goto(`${BASE}/debts`, { waitUntil: 'networkidle' });
  check('debts page lists open credit sale', (await page.getByText('Neema Juma').count()) > 0);

  // Customer statement
  await page.goto(`${BASE}/customers`, { waitUntil: 'networkidle' });
  await page.getByRole('link', { name: 'Neema Juma' }).first().click();
  await page.waitForURL(/\/customers\/[0-9a-f-]{36}/);
  await page.getByText('Lifetime purchases').waitFor({ timeout: 20000 });
  const statement = await page.locator('.app-content').innerText();
  check('customer statement shows repayment history', /repayment history/i.test(statement) && statement.replace(/\s/g, '').includes('10,500'));

  // Expense
  await page.goto(`${BASE}/expenses`, { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /add expense/i }).first().click();
  await page.fill('#description', 'Shop rent November');
  await page.fill('#amount', '3500');
  await page.getByRole('button', { name: /^save$/i }).click();
  await page.getByText('Shop rent November').first().waitFor({ timeout: 20000 });
  check('expense recorded', await page.getByText('Shop rent November').first().isVisible());

  // Inventory stock-in
  await page.goto(`${BASE}/inventory`, { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /^stock in$/i }).first().click();
  await page.fill('#quantity', '5');
  await page.fill('#reason', 'Supplier delivery');
  await page.getByRole('button', { name: /record movement/i }).click();
  await page.waitForTimeout(2500);
  const inventoryText = await page.locator('.app-content').innerText();
  check('stock movement recorded in history', /supplier delivery/i.test(inventoryText));

  // Reports
  await page.goto(`${BASE}/reports`, { waitUntil: 'networkidle' });
  await page.getByText('Profit & loss summary').waitFor({ timeout: 20000 });
  const reportText = await page.locator('.app-content').innerText();
  check('report shows net profit line', /net profit/i.test(reportText));
  const download = page.waitForEvent('download', { timeout: 20000 });
  await page.getByRole('button', { name: /export csv/i }).click();
  const file = await download;
  check('CSV export downloads a report file', file.suggestedFilename().endsWith('.csv'), file.suggestedFilename());

  // Language switcher
  await page.selectOption('.language-switch select', 'sw');
  await page.waitForTimeout(800);
  const swahili = await page.locator('.topbar, .sidebar, .mobile-bottom-nav').first().innerText();
  check('Swahili switcher changes navigation labels', /Dashibodi|Mauzo|Ripoti/.test(await page.locator('.mobile-bottom-nav').innerText()), swahili);

  // Mobile navigation presence
  check('mobile bottom navigation visible', await page.locator('.mobile-bottom-nav').isVisible());
  check('desktop sidebar hidden on phone viewport', !(await page.locator('.sidebar').isVisible()));

  // Dashboard refresh after data
  await page.goto(`${BASE}/dashboard`, { waitUntil: 'networkidle' });
  await page.getByText(/Outstanding debts|Madeni/i).first().waitFor({ timeout: 20000 });
  const dash = await page.locator('.app-content').innerText();
  check('dashboard shows outstanding debt from real records', dash.replace(/\s/g, '').includes('10,500'), 'expected 10,500 balance');

  // Protected route after logout
  await page.goto(`${BASE}/profile`, { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /log out|ondoka/i }).first().click();
  await page.waitForURL('**/login', { timeout: 20000 });
  await page.goto(`${BASE}/dashboard`);
  await page.waitForURL('**/login**', { timeout: 20000 });
  check('protected routes redirect to login after sign out', page.url().includes('/login'));

  // Log back in
  await page.fill('#email', email);
  await page.fill('#password', password);
  await page.getByRole('button', { name: /^sign in$/i }).click();
  await page.waitForURL('**/dashboard', { timeout: 30000 });
  check('login restores the workspace', page.url().endsWith('/dashboard'));
} catch (error) {
  results.push(`FAIL  uncaught — ${error instanceof Error ? error.message : String(error)}`);
  await page.screenshot({ path: 'tests/ui-failure.png', fullPage: true }).catch(() => {});
} finally {
  await browser.close();
}

const failures = results.filter((line) => line.startsWith('FAIL'));
console.log('\nDukaFlow UI verification (Android viewport 412×915)\n' + '='.repeat(64));
results.forEach((line) => console.log(line));
console.log('='.repeat(64));
if (consoleErrors.length) { console.log('Console errors:'); consoleErrors.slice(0, 8).forEach((line) => console.log('  ' + line)); }
console.log(`${results.length - failures.length} passed, ${failures.length} failed`);
process.exitCode = failures.length ? 1 : 0;
