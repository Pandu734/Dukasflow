import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // DukaFlow is a fully authenticated, per-tenant app: every page except the
  // marketing/auth surface is rendered per request, so Cache Components is off.
  cacheComponents: false,
  partialPrefetching: false,
  // Sandbox preview proxying arrives from many hostnames; allow the common dev origins.
  allowedDevOrigins: ['127.0.0.1', 'localhost', '*.e2b.app', '*.arena.ai'],
};

export default nextConfig;
