# DukaFlow

Production-minded, mobile-first, multi-tenant business platform for SMEs in Tanzania and beyond.
Sales, stock, expenses, customers, debts and **real** profit — on Supabase Auth + PostgreSQL.

---

## 1. What is running now

| Item | Status |
| --- | --- |
| Next.js 16 app (`/home/user/dukaflow`) | ✅ builds, type-checks, runs |
| Local preview | ✅ `npm run dev` → http://localhost:3000 (proxy-safe, `0.0.0.0`) |
| Supabase project `DukaFlow` (`gvgbsksyrbixdncxomee`, eu-central-1, PostgreSQL 17) | ✅ ACTIVE_HEALTHY |
| Database schema, RLS, RPCs | ✅ applied (see §3) |
| Live API/database test suite (59 checks) | ✅ 59/59 pass |
| Browser UI test suite on Android viewport (28 checks) | ✅ 28/28 pass |
| Unit tests (accounting, formatting, i18n) | ✅ 13/13 pass |
| Vercel deployment | ⛔ not created (preview-first was chosen) |
| Subscription billing | ⛔ intentionally not implemented (plan data model only) |

---

## 2. Run it

```bash
cd /home/user/dukaflow
npm install
npm run dev            # http://localhost:3000
npm run build          # production build
npm test               # unit tests
npm run test:live      # 59 live database/security/accounting checks
npm run test:ui        # 28 Playwright checks at 412×915 (needs the dev server running)
```

`.env.local` (already present, only public values):

```
NEXT_PUBLIC_SUPABASE_URL=https://gvgbsksyrbixdncxomee.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_…
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

No service-role key is used by the app. Every write goes through RLS or a
`security definer` RPC that re-derives the user from `auth.uid()`.

**Signing up:** email confirmation is currently **auto-confirmed** in the Supabase
project so the flow works without an inbox. Before public launch, switch
*Authentication → Providers → Email → Confirm email* back on; the app already
handles the `/auth/callback` exchange.

---

## 3. Database

Four migrations in `supabase/migrations/` (all applied live):

1. `202611170001_core_schema.sql` — tables, constraints, indexes, timestamps, plan catalogue, profile bootstrap trigger.
2. `202611170002_security.sql` — membership helpers, RLS on every tenant table, grants, immutable-tenant guards, audit triggers.
3. `202611170003_functions_reports.sql` — transactional sales/stock/debt RPCs, dashboard + financial-report RPCs, `customer_debts` view.
4. `202611170004_active_business.sql` — per-user active business preference.

**15 tables:** `profiles`, `businesses`, `business_members`, `subscription_plans`,
`subscriptions`, `categories`, `products`, `customers`, `business_counters`,
`sales`, `sale_items`, `expenses`, `stock_movements`, `debt_payments`, `audit_logs`.
Plus the `customer_debts` security-invoker view.

Verified live: **15/15 tables have RLS enabled**, **27 policies**, **28 triggers**.

### Server-side rules that the UI cannot bypass

* `create_sale` — validates membership + role, rejects duplicate lines, re-reads
  prices from the database, recomputes subtotal/discount/total and COGS,
  enforces the negative-stock policy, requires a customer for credit, blocks
  `paid > total`, allocates the sale number from a counter with
  `FOR UPDATE`, deducts stock exactly once, writes `stock_movements` and
  `audit_logs`, and is idempotent on `idempotency_key`.
* `reverse_sale` — owner/admin/manager only, restore stock per item, refuses
  when repayments exist, records reason + before/after JSON, keeps the sale out
  of revenue.
* `record_stock_movement` — stock-in or adjustment with mandatory reason,
  negative-stock policy, cost update, full before/after trail.
* `record_debt_payment` — cannot exceed the outstanding balance; updates
  `payment_status` to `partially_paid`/`paid`.
* `get_dashboard_metrics` / `get_financial_report` — all maths in SQL, cancelled
  sales excluded, expenses net of archived rows, cash ≠ revenue.
* `business_id` / `owner_id` are immutable on existing rows; `quantity_stock`,
  `cost_total`, `amount_paid` and totals are **not** writable by the client
  (column-level grants only).

---

## 4. Accounting model

```
revenue      = Σ completed sales.total            (credit sales included, reversed excluded)
COGS         = Σ completed sales.cost_total       (unit cost captured at sale time)
gross profit = revenue − COGS
expenses     = Σ active expenses.amount
net profit   = gross profit − expenses
cash         = initial payments received + debt repayments received in the period
debt         = Σ (sale.total − sale.amount_paid) for completed sales
```

Revenue, received cash, credit sales, debt and profit are reported as separate
figures everywhere (dashboard, receipts, reports, CSV).

---

## 5. Screens

`/` landing · `/register` · `/login` · `/forgot-password` · `/reset-password` ·
`/auth/callback` · `/onboarding` · `/dashboard` · `/products` · `/inventory` ·
`/sales` · `/sales/new` · `/sales/[id]` (receipt, repayment, reversal) ·
`/expenses` · `/customers` · `/customers/[id]` (statement) · `/debts` ·
`/reports` · `/settings` · `/profile`.

All list pages have search/filtering, date-range presets (today / 7 days / month /
custom), CSV export, print styles, empty and error states, and a Swahili switch.
Navigation is a navy sidebar on desktop and a 5-item bottom bar with a raised
“New sale” action on phones, plus a business switcher in the sidebar and top bar.

---

## 6. Known gaps (not silently faked)

* **Staff invitations** — the `business_members` table, roles and policies exist,
  but no invite-email flow is implemented; members can only be added by SQL.
* **Billing** — plan/subscription rows are real data, but no payment provider,
  invoices or upgrade flow are wired.
* **Reports** — inventory valuation, product performance, expense categories and
  trends exist; a monthly comparison / tax-report export is not built yet.
* **Email** — Supabase's built-in SMTP is used (rate-limited); no branded
  transactional email templates.
* **Deployment** — nothing is deployed to Vercel yet, by your instruction.
* Test accounts used by the automated suites remain in the project's
  `auth.users` (clearly named `dukaflow.*@example.com`).
