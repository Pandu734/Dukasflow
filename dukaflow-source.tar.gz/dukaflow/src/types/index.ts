import type { AppLanguage } from '@/lib/format';

export type Business = {
  id: string; name: string; business_type: string; country_code: string; currency_code: string;
  phone: string | null; address: string | null; preferred_language: AppLanguage; timezone: string;
  allow_negative_stock: boolean; role: string;
};
export type AppUser = { id: string; email: string; full_name: string | null; phone: string | null };
export type Category = { id: string; business_id: string; name: string; archived_at: string | null };
export type Product = {
  id: string; business_id: string; category_id: string | null; name: string; sku: string | null;
  purchase_cost: number; selling_price: number; quantity_stock: number; low_stock_threshold: number;
  archived_at: string | null; categories?: { name: string } | null;
};
export type Customer = {
  id: string; business_id: string; name: string; phone: string | null; email: string | null;
  address: string | null; notes: string | null; archived_at: string | null;
};
export type Sale = {
  id: string; business_id: string; customer_id: string | null; sale_number: string; sold_at: string;
  subtotal: number; discount: number; total: number; cost_total: number; initial_amount_paid: number;
  amount_paid: number; payment_method: string; payment_status: 'paid'|'partially_paid'|'unpaid';
  status: 'completed'|'reversed'; note: string | null; reversal_reason: string | null;
  customers?: { name: string; phone?: string | null } | null;
};
export type Expense = {
  id: string; business_id: string; category: string; description: string; amount: number;
  expense_date: string; payment_method: string; archived_at: string | null; created_at: string;
};
export type StockMovement = {
  id: string; product_id: string; movement_type: string; quantity_delta: number; quantity_before: number;
  quantity_after: number; unit_cost: number | null; reason: string | null; created_at: string;
  products?: { name: string; sku: string | null } | null;
};
export type Debt = {
  business_id: string; customer_id: string; customer_name: string; phone: string | null; sale_id: string;
  sale_number: string; sold_at: string; total: number; amount_paid: number; outstanding: number; payment_status: string;
};
export type DebtPayment = {
  id: string; sale_id: string; customer_id: string; amount: number; paid_at: string; payment_method: string;
  note: string | null; customers?: { name: string } | null; sales?: { sale_number: string } | null;
};
