export type AppLanguage = 'en' | 'sw';

export function currency(value: number | string | null | undefined, code = 'TZS', language: AppLanguage = 'en') {
  const amount = Number(value ?? 0);
  return new Intl.NumberFormat(language === 'sw' ? 'sw-TZ' : 'en-TZ', {
    style: 'currency', currency: code, maximumFractionDigits: code === 'TZS' ? 0 : 2,
  }).format(Number.isFinite(amount) ? amount : 0);
}

export function number(value: number | string | null | undefined, language: AppLanguage = 'en', digits = 0) {
  return new Intl.NumberFormat(language === 'sw' ? 'sw-TZ' : 'en-TZ', { maximumFractionDigits: digits }).format(Number(value ?? 0));
}

export function localDate(value: string | Date, language: AppLanguage = 'en', withTime = false) {
  const date = value instanceof Date ? value : new Date(value);
  return new Intl.DateTimeFormat(language === 'sw' ? 'sw-TZ' : 'en-TZ', withTime
    ? { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Africa/Dar_es_Salaam' }
    : { dateStyle: 'medium', timeZone: 'Africa/Dar_es_Salaam' }).format(date);
}

export function isoDate(date = new Date()) {
  const tzDate = new Date(date.toLocaleString('en-US', { timeZone: 'Africa/Dar_es_Salaam' }));
  const y = tzDate.getFullYear();
  const m = String(tzDate.getMonth() + 1).padStart(2, '0');
  const d = String(tzDate.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function monthStart() {
  const today = isoDate();
  return `${today.slice(0, 8)}01`;
}

export function errorMessage(error: unknown) {
  if (error instanceof Error) return error.message;
  if (typeof error === 'object' && error && 'message' in error) return String((error as { message: unknown }).message);
  return 'Something went wrong. Please try again.';
}
