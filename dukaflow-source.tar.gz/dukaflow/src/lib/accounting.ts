export type AccountingInput = { revenue: number; cogs: number; expenses: number; initialCash: number; debtRepayments: number };

export function calculateAccounting(input: AccountingInput) {
  const grossProfit = roundMoney(input.revenue - input.cogs);
  return {
    revenue: roundMoney(input.revenue),
    cashCollected: roundMoney(input.initialCash + input.debtRepayments),
    grossProfit,
    netProfit: roundMoney(grossProfit - input.expenses),
  };
}

export function roundMoney(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function outstanding(total: number, paid: number) {
  return Math.max(0, roundMoney(total - paid));
}
