import type { AppLanguage } from './format';

const en = {
  dashboard:'Dashboard', products:'Products', inventory:'Inventory', sales:'Sales', newSale:'New sale', expenses:'Expenses', customers:'Customers', debts:'Debts', reports:'Reports', settings:'Settings', profile:'Profile',
  search:'Search', add:'Add', edit:'Edit', save:'Save', cancel:'Cancel', archive:'Archive', close:'Close', confirm:'Confirm', loading:'Loading…', actions:'Actions', date:'Date', amount:'Amount', status:'Status', category:'Category', description:'Description', name:'Name', phone:'Phone', address:'Address', language:'Language', currency:'Currency',
  todaySales:"Today's sales", monthlySales:'Monthly sales', totalExpenses:'Total expenses', grossProfit:'Gross profit', netProfit:'Net profit', totalProducts:'Products', lowStock:'Low stock', outstandingDebts:'Outstanding debts', recentSales:'Recent sales', salesProfitTrend:'Sales & profit trend', cashCollected:'Cash collected', creditSales:'Credit sales', revenue:'Revenue', cogs:'Cost of goods sold',
  today:'Today', last7:'Last 7 days', thisMonth:'This month', custom:'Custom range', from:'From', to:'To', apply:'Apply', viewAll:'View all', noData:'No records yet', tryAgain:'Try again',
  runSmarter:'Run Your Business Smarter.', logout:'Log out', english:'English', swahili:'Kiswahili', business:'Business', welcomeBack:'Welcome back',
};
const sw: typeof en = {
  dashboard:'Dashibodi', products:'Bidhaa', inventory:'Stoo', sales:'Mauzo', newSale:'Mauzo mapya', expenses:'Matumizi', customers:'Wateja', debts:'Madeni', reports:'Ripoti', settings:'Mipangilio', profile:'Wasifu',
  search:'Tafuta', add:'Ongeza', edit:'Hariri', save:'Hifadhi', cancel:'Ghairi', archive:'Hifadhi mbali', close:'Funga', confirm:'Thibitisha', loading:'Inapakia…', actions:'Vitendo', date:'Tarehe', amount:'Kiasi', status:'Hali', category:'Aina', description:'Maelezo', name:'Jina', phone:'Simu', address:'Anwani', language:'Lugha', currency:'Sarafu',
  todaySales:'Mauzo ya leo', monthlySales:'Mauzo ya mwezi', totalExpenses:'Jumla ya matumizi', grossProfit:'Faida ghafi', netProfit:'Faida halisi', totalProducts:'Bidhaa', lowStock:'Stoo ndogo', outstandingDebts:'Madeni yaliyobaki', recentSales:'Mauzo ya hivi karibuni', salesProfitTrend:'Mwenendo wa mauzo na faida', cashCollected:'Fedha zilizopokelewa', creditSales:'Mauzo ya mkopo', revenue:'Mapato', cogs:'Gharama ya bidhaa zilizouzwa',
  today:'Leo', last7:'Siku 7 zilizopita', thisMonth:'Mwezi huu', custom:'Muda maalum', from:'Kuanzia', to:'Mpaka', apply:'Tumia', viewAll:'Tazama zote', noData:'Hakuna rekodi bado', tryAgain:'Jaribu tena',
  runSmarter:'Endesha Biashara Yako kwa Ufanisi.', logout:'Ondoka', english:'English', swahili:'Kiswahili', business:'Biashara', welcomeBack:'Karibu tena',
};

export type TranslationKey = keyof typeof en;
export function translate(language: AppLanguage, key: TranslationKey) { return (language === 'sw' ? sw : en)[key] ?? en[key]; }
