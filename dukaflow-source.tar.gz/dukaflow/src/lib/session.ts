import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

// The active business is persisted server-side on the profile, so switching
// works even when the preview proxy rewrites hosts and cookies are unreliable.
export const ACTIVE_BUSINESS_COOKIE = 'dukaflow-business';

export type BusinessSummary = { id: string; name: string; role: string };
export type SessionContext = {
  userId: string; email: string; fullName: string | null; phone: string | null;
  business: {
    id: string; name: string; business_type: string; country_code: string; currency_code: string;
    phone: string | null; address: string | null; preferred_language: 'en' | 'sw'; timezone: string;
    allow_negative_stock: boolean; role: string;
  } | null;
  businesses: BusinessSummary[];
};

export async function getSessionContext(requireBusiness = true): Promise<SessionContext> {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect('/login');

  const { data: profile } = await supabase.from('profiles').select('full_name,phone,active_business_id').eq('id', user.id).maybeSingle();
  const preferredBusinessId = profile?.active_business_id ?? undefined;
  const { data: memberships } = await supabase
    .from('business_members')
    .select('business_id,role,created_at')
    .eq('user_id', user.id)
    .eq('status', 'active')
    .order('created_at', { ascending: true });

  const base = { userId: user.id, email: user.email ?? '', fullName: profile?.full_name ?? null, phone: profile?.phone ?? null };
  if (!memberships || memberships.length === 0) {
    if (requireBusiness) redirect('/onboarding');
    return { ...base, business: null, businesses: [] };
  }

  const activeMembership = memberships.find((membership) => membership.business_id === preferredBusinessId) ?? memberships[0];
  const { data: business } = await supabase
    .from('businesses')
    .select('id,name,business_type,country_code,currency_code,phone,address,preferred_language,timezone,allow_negative_stock')
    .eq('id', activeMembership.business_id)
    .maybeSingle();

  if (!business) {
    if (requireBusiness) redirect('/onboarding');
    return { ...base, business: null, businesses: [] };
  }

  const { data: allBusinesses } = await supabase
    .from('businesses')
    .select('id,name')
    .in('id', memberships.map((membership) => membership.business_id))
    .order('name');

  const summaries: BusinessSummary[] = (allBusinesses ?? []).map((row) => ({
    id: row.id,
    name: row.name,
    role: memberships.find((membership) => membership.business_id === row.id)?.role ?? 'member',
  }));

  return {
    ...base,
    business: { ...business, preferred_language: business.preferred_language === 'sw' ? 'sw' : 'en', role: activeMembership.role },
    businesses: summaries.length ? summaries : [{ id: business.id, name: business.name, role: activeMembership.role }],
  };
}
