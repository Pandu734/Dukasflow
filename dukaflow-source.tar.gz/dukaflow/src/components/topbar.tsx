'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Plus } from 'lucide-react';
import { Brand } from '@/components/brand';
import { LanguageSwitcher } from '@/components/language-switcher';
import { useApp } from '@/components/app-provider';
import { BusinessSwitcher } from '@/components/business-switcher';
import { localDate } from '@/lib/format';

const titles: Record<string, string> = {
  '/dashboard': 'dashboard', '/products': 'products', '/inventory': 'inventory', '/sales': 'sales', '/sales/new': 'newSale',
  '/expenses': 'expenses', '/customers': 'customers', '/debts': 'debts', '/reports': 'reports', '/settings': 'settings', '/profile': 'profile',
};

export function Topbar() {
  const pathname = usePathname();
  const { business, language, t } = useApp();
  const key = Object.keys(titles).find((path) => pathname === path || (path !== '/dashboard' && path !== '/sales' && pathname.startsWith(path + '/'))) ?? '/dashboard';
  return <header className="topbar">
    <span className="mobile-top-brand"><Brand compact href="/dashboard" /></span>
    <h2 className="topbar-title">{t(titles[key] as never)}</h2>
    <div className="topbar-spacer" />
    <span className="mobile-business-switch"><BusinessSwitcher compact /></span>
    <span className="topbar-date">{localDate(new Date(), language)} · {business.currency_code}</span>
    {pathname !== '/sales/new' && <Link href="/sales/new" className="button button-primary button-sm"><Plus size={15} /><span>New sale</span></Link>}
    <LanguageSwitcher />
  </header>;
}
