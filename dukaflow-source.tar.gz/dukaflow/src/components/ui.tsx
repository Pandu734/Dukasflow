'use client';

import { X } from 'lucide-react';
import type { ReactNode } from 'react';

export function Modal({ open, title, children, onClose, size = 'md' }: { open: boolean; title: string; children: ReactNode; onClose: () => void; size?: 'sm'|'md'|'lg' }) {
  if (!open) return null;
  return <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <section className={`modal modal-${size}`} role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <header className="modal-header"><h2 id="modal-title">{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close"><X size={20}/></button></header>
      <div className="modal-body">{children}</div>
    </section>
  </div>;
}

export function EmptyState({ icon, title, description, action }: { icon?: ReactNode; title: string; description?: string; action?: ReactNode }) {
  return <div className="empty-state">{icon && <div className="empty-icon">{icon}</div>}<h3>{title}</h3>{description && <p>{description}</p>}{action}</div>;
}

export function Spinner({ label = 'Loading…' }: { label?: string }) { return <div className="spinner-wrap"><span className="spinner"/><span>{label}</span></div>; }

export function ConfirmDialog({ open, title, message, confirmLabel = 'Confirm', danger = false, busy = false, onConfirm, onClose }: { open: boolean; title: string; message: string; confirmLabel?: string; danger?: boolean; busy?: boolean; onConfirm: () => void; onClose: () => void }) {
  return <Modal open={open} title={title} onClose={onClose} size="sm"><p className="muted" style={{marginBottom:20}}>{message}</p><div className="form-actions"><button className="button button-ghost" onClick={onClose}>Cancel</button><button className={`button ${danger?'button-danger':'button-primary'}`} disabled={busy} onClick={onConfirm}>{busy?'Working…':confirmLabel}</button></div></Modal>;
}

export function StatusBadge({ status }: { status: string }) { const key = status.toLowerCase().replaceAll('_','-'); return <span className={`badge badge-${key}`}>{status.replaceAll('_',' ')}</span>; }
