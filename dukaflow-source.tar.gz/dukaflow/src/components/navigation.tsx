'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { BarChart3, Boxes, CreditCard, LayoutDashboard, LogOut, Package, ReceiptText, Settings, ShoppingCart, UserRound, Users, Wallet } from 'lucide-react';
import { Brand } from '@/components/brand';
import { BusinessSwitcher } from '@/components/business-switcher';
import { useApp } from '@/components/app-provider';
import { createClient } from '@/lib/supabase/client';

const main = [
  { href: '/dashboard', key: 'dashboard', icon: LayoutDashboard },
  { href: '/sales', key: 'sales', icon: ReceiptText },
  { href: '/sales/new', key: 'newSale', icon: ShoppingCart },
  { href: '/products', key: 'products', icon: Package },
  { href: '/inventory', key: 'inventory', icon: Boxes },
  { href: '/expenses', key: 'expenses', icon: Wallet },
  { href: '/customers', key: 'customers', icon: Users },
  { href: '/debts', key: 'debts', icon: CreditCard },
  { href: '/reports', key: 'reports', icon: BarChart3 },
] as const;

export function Sidebar() {
  const { business, user, t } = useApp();
  const pathname = usePathname();
  const router = useRouter();
  const initials = (user.full_name || user.email).trim().slice(0, 2).toUpperCase();
  async function logout() {
    await createClient().auth.signOut();
    router.replace('/login');
    router.refresh();
  }
  return <aside className="sidebar">
    <Brand href="/dashboard" light />
    <BusinessSwitcher />
    <nav className="sidebar-nav" aria-label="Main navigation">
      <div className="nav-section">Workspace</div>
      {main.map(({ href, key, icon: Icon }) => {
        const active = href === '/sales' ? pathname === '/sales' || /^\/sales\/(?!new)/.test(pathname) : pathname === href || (href !== '/dashboard' && pathname.startsWith(href + '/'));
        return <Link key={href} href={href} className={`nav-link ${active ? 'active' : ''}`}><Icon /><span>{t(key)}</span></Link>;
      })}
      <div className="nav-section">Account</div>
      <Link href="/settings" className={`nav-link ${pathname.startsWith('/settings') ? 'active' : ''}`}><Settings /><span>{t('settings')}</span></Link>
      <Link href="/profile" className={`nav-link ${pathname.startsWith('/profile') ? 'active' : ''}`}><UserRound /><span>{t('profile')}</span></Link>
    </nav>
    <div className="sidebar-footer">
      <div className="profile-mini"><span className="profile-avatar">{initials}</span><div><strong>{user.full_name || 'Business owner'}</strong><span>{user.email}</span></div></div>
      <button className="nav-link" style={{ width: '100%', border: 0, background: 'transparent' }} onClick={logout}><LogOut /><span>{t('logout')}</span></button>
    </div>
  </aside>;
}

export function MobileNav() {
  const { t } = useApp();
  const pathname = usePathname();
  const items: { href: string; key: 'dashboard'|'sales'|'newSale'|'products'|'reports'; icon: typeof LayoutDashboard; primary?: boolean }[] = [
    { href: '/dashboard', key: 'dashboard', icon: LayoutDashboard },
    { href: '/sales', key: 'sales', icon: ReceiptText },
    { href: '/sales/new', key: 'newSale', icon: ShoppingCart, primary: true },
    { href: '/products', key: 'products', icon: Package },
    { href: '/reports', key: 'reports', icon: BarChart3 },
  ];
  return <nav className="mobile-bottom-nav" aria-label="Mobile navigation">{items.map(({ href, key, icon: Icon, primary }) => {
    const active = href === '/sales/new' ? pathname === href : href === '/sales' ? pathname === '/sales' || /^\/sales\/(?!new)/.test(pathname) : pathname === href;
    if (primary) return <Link key={href} href={href} className={`new-sale-mobile ${active ? 'active' : ''}`} aria-label={t(key)}><span><Icon size={21} /></span><span>{t(key)}</span></Link>;
    return <Link key={href} href={href} className={active ? 'active' : ''}><Icon /><span>{t(key)}</span></Link>;
  })}</nav>;
}
