import { CheckCircle2 } from 'lucide-react';
import { Brand } from './brand';

export function AuthShell({ children }: { children: React.ReactNode }) {
  return <main className="auth-page"><aside className="auth-aside"><Brand light/><div className="auth-message"><div className="eyebrow"><span/> Business, made clearer</div><h1>Know your numbers.<br/>Grow with confidence.</h1><p>One simple workspace for your sales, stock, expenses, customers, debts and real profit.</p><div className="auth-points"><span><CheckCircle2 size={17}/> Accurate sales and inventory records</span><span><CheckCircle2 size={17}/> Clear cash, credit and profit reporting</span><span><CheckCircle2 size={17}/> Built for mobile, English and Kiswahili</span></div></div><small>© 2026 DukaFlow · Run Your Business Smarter.</small></aside><section className="auth-form-side"><div className="auth-card"><div style={{marginBottom:28}} className="mobile-top-brand"><Brand/></div>{children}</div></section></main>;
}
