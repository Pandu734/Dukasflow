'use client';

import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import type { AppLanguage } from '@/lib/format';
import { translate, type TranslationKey } from '@/lib/translations';
import type { AppUser, Business } from '@/types';

type Toast = { id: number; type: 'success'|'error'|'info'; message: string };
type BusinessSummary = { id: string; name: string; role: string };
type AppContextValue = {
  business: Business; businesses: BusinessSummary[]; user: AppUser; language: AppLanguage; setLanguage: (language: AppLanguage) => void;
  t: (key: TranslationKey) => string; toasts: Toast[]; notify: (message: string, type?: Toast['type']) => void;
};
const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ business, businesses, user, children }: { business: Business; businesses: BusinessSummary[]; user: AppUser; children: React.ReactNode }) {
  const [language, setLanguageState] = useState<AppLanguage>(business.preferred_language || 'en');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const setLanguage = useCallback((next: AppLanguage) => { setLanguageState(next); localStorage.setItem('dukaflow-language', next); }, []);
  const notify = useCallback((message: string, type: Toast['type'] = 'success') => {
    const id = Date.now() + Math.random(); setToasts((items) => [...items, { id, type, message }]);
    window.setTimeout(() => setToasts((items) => items.filter((item) => item.id !== id)), 4200);
  }, []);
  const value = useMemo(() => ({ business, businesses, user, language, setLanguage, t: (key: TranslationKey) => translate(language, key), toasts, notify }), [business, businesses, user, language, setLanguage, toasts, notify]);
  return <AppContext.Provider value={value}>{children}<div className="toast-stack" aria-live="polite">{toasts.map((toast) => <div key={toast.id} className={`toast toast-${toast.type}`}>{toast.message}</div>)}</div></AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside AppProvider');
  return context;
}
