'use client';
import { Languages } from 'lucide-react';
import { useApp } from './app-provider';

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { language, setLanguage } = useApp();
  return <label className={`language-switch ${compact?'compact':''}`}><Languages size={17}/><span className="sr-only">Language</span><select value={language} onChange={(e) => setLanguage(e.target.value as 'en'|'sw')} aria-label="Language"><option value="en">EN</option><option value="sw">SW</option></select></label>;
}
