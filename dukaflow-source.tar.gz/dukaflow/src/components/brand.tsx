import Link from 'next/link';

export function Brand({ href = '/', light = false, compact = false }: { href?: string; light?: boolean; compact?: boolean }) {
  return <Link href={href} className={`brand ${light?'brand-light':''}`} aria-label="DukaFlow home">
    <span className="brand-mark" aria-hidden="true"><svg viewBox="0 0 36 36" role="img"><path d="M7 10.5h22l-2.4 16.2a3 3 0 0 1-3 2.6H12.4a3 3 0 0 1-3-2.6L7 10.5Z"/><path d="M12.5 12V9a5.5 5.5 0 0 1 11 0v3" fill="none"/><path d="m13 21 3 3 7-8" fill="none"/></svg></span>
    {!compact && <span className="brand-word">Duka<span>Flow</span></span>}
  </Link>;
}
