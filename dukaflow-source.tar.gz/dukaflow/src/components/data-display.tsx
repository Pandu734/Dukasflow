'use client';
import { BarChart3 } from 'lucide-react';
import type { ReactNode } from 'react';

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return <div className="page-header"><div><h1>{title}</h1>{description && <p>{description}</p>}</div>{actions && <div className="page-actions">{actions}</div>}</div>;
}

export function MetricCard({ label, value, sub, icon, tone = 'green' }: { label: string; value: string; sub?: string; icon?: ReactNode; tone?: 'green'|'navy'|'amber'|'red' }) {
  return <article className="metric-card"><div className="metric-top"><span className="metric-label">{label}</span>{icon && <span className={`metric-icon ${tone}`}>{icon}</span>}</div><div><div className="metric-value">{value}</div>{sub && <div className="metric-sub">{sub}</div>}</div></article>;
}

export type TrendPoint = { date: string; sales: number; gross_profit: number; expenses: number; net_profit: number };

export function TrendChart({ data, currencyFormatter }: { data: TrendPoint[]; currencyFormatter: (value: number) => string }) {
  const hasActivity = data.some((point) => Number(point.sales) !== 0 || Number(point.gross_profit) !== 0);
  if (data.length > 0 && !hasActivity) {
    return <div className="chart-empty"><BarChart3 size={22} /><strong>No sales in this period</strong><span>Record a sale or choose a different date range to see the trend.</span></div>;
  }
  const points = data.length ? data : [{ date: '', sales: 0, gross_profit: 0, expenses: 0, net_profit: 0 }];
  const max = Math.max(1, ...points.map((point) => Math.max(point.sales, point.gross_profit)));
  const width = 720; const height = 220; const pad = 8;
  const x = (index: number) => (points.length === 1 ? width / 2 : pad + (index * (width - pad * 2)) / (points.length - 1));
  const y = (value: number) => height - 14 - (Math.max(0, value) / max) * (height - 34);
  const line = (key: 'sales' | 'gross_profit') => points.map((point, index) => `${index === 0 ? 'M' : 'L'}${x(index).toFixed(1)},${y(point[key]).toFixed(1)}`).join(' ');
  const area = `${line('sales')} L${x(points.length - 1).toFixed(1)},${height} L${x(0).toFixed(1)},${height} Z`;
  const labelIndexes = points.length <= 8 ? points.map((_, index) => index) : [0, Math.floor(points.length / 3), Math.floor((points.length * 2) / 3), points.length - 1];
  const total = points.reduce((sum, point) => sum + point.sales, 0);
  return <div>
    <div className="chart">
      <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" role="img" aria-label={`Sales trend, total ${currencyFormatter(total)}`}>
        <defs><linearGradient id="chartArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#1fac75" stopOpacity="0.22" /><stop offset="100%" stopColor="#1fac75" stopOpacity="0" /></linearGradient></defs>
        {[0, 0.25, 0.5, 0.75, 1].map((ratio) => <line key={ratio} x1="0" x2={width} y1={height - 14 - ratio * (height - 34)} y2={height - 14 - ratio * (height - 34)} className="chart-grid" />)}
        <path d={area} className="chart-area" />
        <path d={line('sales')} className="chart-sales" vectorEffect="non-scaling-stroke" />
        <path d={line('gross_profit')} className="chart-profit" vectorEffect="non-scaling-stroke" />
      </svg>
    </div>
    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
      <div className="chart-legend"><span><i className="legend-dot" /> Sales</span><span><i className="legend-dot navy" /> Gross profit</span></div>
      <div className="chart-legend">{labelIndexes.map((index) => <span key={index}>{points[index]?.date ? points[index].date.slice(5) : '—'}</span>)}</div>
    </div>
  </div>;
}

export function MiniBarChart({ data }: { data: { label: string; value: number }[] }) {
  const max = Math.max(1, ...data.map((item) => item.value));
  return <div style={{ display: 'grid', gap: 11 }}>{data.length === 0 && <p className="muted" style={{ fontSize: 12 }}>No expenses in this period.</p>}{data.map((item) => <div key={item.label}><div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 5 }}><span style={{ color: 'var(--ink)', fontWeight: 600 }}>{item.label}</span><strong style={{ color: 'var(--navy-900)' }}>{new Intl.NumberFormat().format(item.value)}</strong></div><div style={{ height: 6, borderRadius: 5, background: '#eef2f5' }}><div style={{ height: '100%', width: `${(item.value / max) * 100}%`, borderRadius: 5, background: 'var(--green-500)' }} /></div></div>)}</div>;
}
