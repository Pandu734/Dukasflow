'use client';
import { useState } from 'react';
import { isoDate, monthStart } from '@/lib/format';

export type RangePreset = 'today' | '7d' | 'month' | 'custom';
export type DateRange = { start: string; end: string; preset: RangePreset };

export function defaultRange(preset: RangePreset = 'month'): DateRange {
  const today = isoDate();
  if (preset === 'today') return { start: today, end: today, preset };
  if (preset === '7d') {
    const date = new Date(today + 'T12:00:00'); date.setDate(date.getDate() - 6);
    return { start: date.toISOString().slice(0, 10), end: today, preset };
  }
  return { start: monthStart(), end: today, preset };
}

export function DateRangeFilter({ value, onChange, labels }: { value: DateRange; onChange: (next: DateRange) => void; labels: { today: string; last7: string; thisMonth: string; custom: string; from: string; to: string; apply: string } }) {
  const [draft, setDraft] = useState({ start: value.start, end: value.end });
  function pick(preset: RangePreset) {
    if (preset === 'custom') { onChange({ ...value, preset: 'custom' }); return; }
    const next = defaultRange(preset); setDraft({ start: next.start, end: next.end }); onChange(next);
  }
  const invalid = draft.start > draft.end || !draft.start || !draft.end;
  return <div className="filter-bar no-print">
    <div className="segment" role="group" aria-label="Date range">
      <button type="button" className={value.preset === 'today' ? 'active' : ''} onClick={() => pick('today')}>{labels.today}</button>
      <button type="button" className={value.preset === '7d' ? 'active' : ''} onClick={() => pick('7d')}>{labels.last7}</button>
      <button type="button" className={value.preset === 'month' ? 'active' : ''} onClick={() => pick('month')}>{labels.thisMonth}</button>
      <button type="button" className={value.preset === 'custom' ? 'active' : ''} onClick={() => pick('custom')}>{labels.custom}</button>
    </div>
    <div className="filter-spacer" />
    <div className="date-inputs">
      <span className="sr-only">{labels.from}</span><input type="date" value={draft.start} max={draft.end || undefined} onChange={(e) => setDraft({ ...draft, start: e.target.value })} aria-label={labels.from} />
      <span className="muted" style={{ fontSize: 11 }}>→</span>
      <span className="sr-only">{labels.to}</span><input type="date" value={draft.end} min={draft.start || undefined} onChange={(e) => setDraft({ ...draft, end: e.target.value })} aria-label={labels.to} />
      <button type="button" className="button button-soft button-sm" disabled={invalid} onClick={() => onChange({ ...draft, preset: 'custom' })}>{labels.apply}</button>
    </div>
  </div>;
}
