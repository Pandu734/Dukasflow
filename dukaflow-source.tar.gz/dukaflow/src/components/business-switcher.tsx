'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronsUpDown } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { Modal } from '@/components/ui';
import { errorMessage } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';

export function BusinessSwitcher({ compact = false }: { compact?: boolean }) {
  const { business, businesses, user } = useApp();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [busyId, setBusyId] = useState('');
  const [error, setError] = useState('');

  async function switchTo(id: string) {
    setError(''); setBusyId(id);
    try {
      const client = createClient();
      const { error: updateError } = await client.from('profiles').update({ active_business_id: id }).eq('id', user.id);
      if (updateError) throw updateError;
      setOpen(false); router.replace('/dashboard'); router.refresh();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusyId(''); }
  }

  return <>
    <button type="button" className={compact ? 'business-chip compact' : 'business-chip'} onClick={() => { setError(''); setOpen(true); }} aria-label="Switch business">
      <span className="business-avatar">{business.name.slice(0, 2).toUpperCase()}</span>
      {!compact && <div><strong>{business.name}</strong><span>{business.role} · {business.currency_code}</span></div>}
      <ChevronsUpDown size={14} style={{ marginLeft: compact ? 0 : 'auto', flexShrink: 0, color: '#8aa4b8' }} />
    </button>
    <Modal open={open} title="Switch business" onClose={() => setOpen(false)} size="sm">
      {error && <div className="form-error" style={{ marginBottom: 12 }}>{error}</div>}
      <div style={{ display: 'grid', gap: 8 }}>
        {businesses.map((item) => <button key={item.id} type="button" className="recent-item" style={{ border: '1px solid var(--line-soft)', borderRadius: 10, padding: '11px 12px', textAlign: 'left', background: item.id === business.id ? 'var(--green-50)' : '#fff', width: '100%' }} onClick={() => item.id !== business.id && switchTo(item.id)} disabled={busyId !== ''}>
          <span className="recent-icon" style={{ width: 30, height: 30 }}>{item.name.slice(0, 2).toUpperCase()}</span>
          <div><strong>{item.name}</strong><span style={{ textTransform: 'capitalize' }}>{item.role}{item.id === business.id ? ' · current' : ''}</span></div>
          <span className={item.id === business.id ? 'badge badge-active' : 'badge'}>{busyId === item.id ? 'Switching…' : item.id === business.id ? 'active' : 'switch'}</span>
        </button>)}
      </div>
      <p className="field-help" style={{ marginTop: 14 }}>Create another business from Settings → Plan &amp; team.</p>
    </Modal>
  </>;
}
