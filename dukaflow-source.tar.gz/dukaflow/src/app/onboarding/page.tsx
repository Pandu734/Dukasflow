import { redirect } from 'next/navigation';
import { OnboardingForm } from './onboarding-form';
import { getSessionContext } from '@/lib/session';
import { Brand } from '@/components/brand';

export default async function OnboardingPage() {
  const session = await getSessionContext(false);
  if (session.business) redirect('/dashboard');
  return <main className="auth-page" style={{ gridTemplateColumns: '1fr' }}>
    <section className="auth-form-side" style={{ minHeight: '100vh' }}>
      <div className="auth-card" style={{ maxWidth: 520 }}>
        <div style={{ marginBottom: 30 }}><Brand /></div>
        <div className="eyebrow"><span /> Step 1 of 1</div>
        <h2 style={{ marginTop: 12 }}>Set up your business</h2>
        <p>This creates your private workspace. You can add staff and more businesses later.</p>
        <OnboardingForm defaultLanguage={session.email ? 'en' : 'en'} />
      </div>
    </section>
  </main>;
}
