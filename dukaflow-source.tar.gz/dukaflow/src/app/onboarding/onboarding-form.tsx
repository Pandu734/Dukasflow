'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { errorMessage } from '@/lib/format';

const currencies = [
  { code: 'TZS', label: 'TZS — Tanzanian Shilling' }, { code: 'KES', label: 'KES — Kenyan Shilling' },
  { code: 'UGX', label: 'UGX — Ugandan Shilling' }, { code: 'USD', label: 'USD — US Dollar' },
  { code: 'EUR', label: 'EUR — Euro' }, { code: 'GBP', label: 'GBP — British Pound' },
  { code: 'ZAR', label: 'ZAR — South African Rand' }, { code: 'NGN', label: 'NGN — Nigerian Naira' },
];
const countries = [{ code: 'TZ', label: 'Tanzania' }, { code: 'KE', label: 'Kenya' }, { code: 'UG', label: 'Uganda' }, { code: 'RW', label: 'Rwanda' }, { code: 'NG', label: 'Nigeria' }, { code: 'ZA', label: 'South Africa' }, { code: 'GB', label: 'United Kingdom' }, { code: 'US', label: 'United States' }];

export function OnboardingForm({ defaultLanguage }: { defaultLanguage: 'en' | 'sw' }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [country, setCountry] = useState('TZ');

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError('');
    const form = new FormData(event.currentTarget);
    try {
      const { data, error } = await createClient().rpc('create_business', {
        p_name: String(form.get('name') ?? '').trim(),
        p_business_type: String(form.get('business_type') ?? '').trim(),
        p_country_code: country,
        p_currency_code: String(form.get('currency_code')),
        p_phone: String(form.get('phone') ?? '').trim() || null,
        p_address: String(form.get('address') ?? '').trim() || null,
        p_preferred_language: String(form.get('language')) as 'en' | 'sw',
        p_timezone: 'Africa/Dar_es_Salaam',
      });
      if (error) throw error;
      if (!data) throw new Error('Your business could not be created.');
      router.replace('/dashboard'); router.refresh();
    } catch (err) { setError(errorMessage(err)); setBusy(false); }
  }

  return <form className="form-stack" onSubmit={submit}>
    {error && <div className="form-error" role="alert">{error}</div>}
    <div className="field"><label htmlFor="name">Business name</label><input id="name" name="name" required minLength={2} placeholder="Mussa General Store" /></div>
    <div className="field"><label htmlFor="business_type">Business type</label><select id="business_type" name="business_type" required defaultValue="Retail shop"><option>Retail shop</option><option>Wholesale</option><option>Restaurant or food</option><option>Services</option><option>Pharmacy</option><option>Salon or barbershop</option><option>Other</option></select></div>
    <div className="form-row">
      <div className="field"><label htmlFor="country">Country</label><select id="country" value={country} onChange={(e) => { const next = e.target.value; setCountry(next); }}>{countries.map((item) => <option key={item.code} value={item.code}>{item.label}</option>)}</select></div>
      <div className="field"><label htmlFor="currency_code">Currency</label><select id="currency_code" name="currency_code" defaultValue="TZS">{currencies.map((item) => <option key={item.code} value={item.code}>{item.label}</option>)}</select></div>
    </div>
    <div className="field"><label htmlFor="phone">Business phone</label><input id="phone" name="phone" type="tel" placeholder="+255 7xx xxx xxx" /></div>
    <div className="field"><label htmlFor="address">Address</label><input id="address" name="address" placeholder="Stone Town, Zanzibar" /></div>
    <div className="field"><label htmlFor="language">Business language</label><select id="language" name="language" defaultValue={defaultLanguage}><option value="en">English</option><option value="sw">Kiswahili</option></select></div>
    <button className="button button-primary button-lg" disabled={busy}>{busy ? 'Creating workspace…' : 'Create business workspace'}</button>
  </form>;
}
