'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { LogOut } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { errorMessage, localDate } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';

export default function ProfilePage() {
  const { user, business, language, t, notify } = useApp();
  const router = useRouter();
  const [profile, setProfile] = useState({ full_name: user.full_name ?? '', phone: user.phone ?? '' });
  const [passwords, setPasswords] = useState({ password: '', confirm: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function saveProfile(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      if (profile.full_name.trim().length < 2) throw new Error('Enter your full name.');
      const { error: updateError } = await createClient().from('profiles').update({ full_name: profile.full_name.trim(), phone: profile.phone.trim() || null }).eq('id', user.id);
      if (updateError) throw updateError;
      notify('Profile updated.'); router.refresh();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function changePassword(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    if (passwords.password.length < 8) { setError('Password must be at least 8 characters.'); return; }
    if (passwords.password !== passwords.confirm) { setError('Passwords do not match.'); return; }
    setBusy(true);
    try {
      const { error: updateError } = await createClient().auth.updateUser({ password: passwords.password });
      if (updateError) throw updateError;
      setPasswords({ password: '', confirm: '' }); notify('Password changed.');
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function logout() { await createClient().auth.signOut(); router.replace('/login'); router.refresh(); }

  return <>
    <PageHeader title={t('profile')} description="Your account, password and current workspace." />
    {error && <div className="form-error" style={{ marginBottom: 14 }}>{error}</div>}
    <div className="section-grid">
      <section className="card span-7">
        <div className="card-header"><h2>Personal details</h2></div>
        <div className="card-body">
          <form className="form-stack" onSubmit={saveProfile}>
            <div className="field"><label htmlFor="full_name">Full name</label><input id="full_name" required value={profile.full_name} onChange={(e) => setProfile({ ...profile, full_name: e.target.value })} /></div>
            <div className="field"><label htmlFor="email">Email</label><input id="email" value={user.email} disabled /></div>
            <div className="field"><label htmlFor="phone">Phone</label><input id="phone" type="tel" value={profile.phone} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} /></div>
            <div className="form-actions"><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : t('save')}</button></div>
          </form>
        </div>
      </section>
      <aside className="card span-5">
        <div className="card-header"><h2>Workspace</h2></div>
        <div className="card-body" style={{ display: 'grid', gap: 12 }}>
          <div><span className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: 1 }}>{t('business')}</span><strong style={{ display: 'block', color: 'var(--navy-900)' }}>{business.name}</strong><span className="muted" style={{ fontSize: 11 }}>{business.business_type}</span></div>
          <div style={{ display: 'flex', gap: 24 }}><div><span className="muted" style={{ fontSize: 10 }}>Role</span><strong style={{ display: 'block', fontSize: 12, textTransform: 'capitalize' }}>{business.role}</strong></div><div><span className="muted" style={{ fontSize: 10 }}>{t('currency')}</span><strong style={{ display: 'block', fontSize: 12 }}>{business.currency_code}</strong></div><div><span className="muted" style={{ fontSize: 10 }}>{t('language')}</span><strong style={{ display: 'block', fontSize: 12 }}>{language === 'sw' ? 'Kiswahili' : 'English'}</strong></div></div>
          <p className="field-help">Timezone {business.timezone}. Today is {localDate(new Date(), language)}.</p>
          <button className="button button-ghost" onClick={logout} style={{ justifySelf: 'start' }}><LogOut size={15} /> {t('logout')}</button>
        </div>
      </aside>
      <section className="card span-7">
        <div className="card-header"><h2>Change password</h2></div>
        <div className="card-body">
          <form className="form-stack" onSubmit={changePassword}>
            <div className="form-row">
              <div className="field"><label htmlFor="new-password">New password</label><input id="new-password" type="password" minLength={8} required value={passwords.password} onChange={(e) => setPasswords({ ...passwords, password: e.target.value })} /></div>
              <div className="field"><label htmlFor="confirm-password">Confirm password</label><input id="confirm-password" type="password" minLength={8} required value={passwords.confirm} onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })} /></div>
            </div>
            <div className="form-actions"><button className="button button-primary" disabled={busy}>{busy ? 'Updating…' : 'Update password'}</button></div>
          </form>
        </div>
      </section>
    </div>
  </>;
}
