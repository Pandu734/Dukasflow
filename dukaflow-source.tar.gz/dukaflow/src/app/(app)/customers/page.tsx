'use client';
import Link from 'next/link';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Pencil, Plus, Search, Users } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { ConfirmDialog, EmptyState, Modal } from '@/components/ui';
import { currency, errorMessage, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Customer, Debt } from '@/types';

const emptyForm = { name: '', phone: '', email: '', address: '', notes: '' };

export default function CustomersPage() {
  const { business, language, t, notify } = useApp();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [archiveTarget, setArchiveTarget] = useState<Customer | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const client = createClient();
    const [customerResult, debtResult] = await Promise.all([
      client.from('customers').select('*').eq('business_id', business.id).is('archived_at', null).order('name'),
      client.from('customer_debts').select('*').eq('business_id', business.id),
    ]);
    if (customerResult.error || debtResult.error) setError(errorMessage(customerResult.error || debtResult.error));
    else { setCustomers((customerResult.data ?? []) as Customer[]); setDebts((debtResult.data ?? []) as Debt[]); }
    setLoading(false);
  }, [business.id]);
  useEffect(() => { void load(); }, [load]);

  const balances = useMemo(() => {
    const map = new Map<string, number>();
    debts.forEach((debt) => map.set(debt.customer_id, (map.get(debt.customer_id) ?? 0) + Number(debt.outstanding)));
    return map;
  }, [debts]);
  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return customers.filter((customer) => !needle || customer.name.toLowerCase().includes(needle) || (customer.phone ?? '').includes(needle));
  }, [customers, search]);

  function openCreate() { setEditing(null); setFormError(''); setForm(emptyForm); setModalOpen(true); }
  function openEdit(customer: Customer) { setEditing(customer); setFormError(''); setForm({ name: customer.name, phone: customer.phone ?? '', email: customer.email ?? '', address: customer.address ?? '', notes: customer.notes ?? '' }); setModalOpen(true); }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormError('');
    if (form.name.trim().length < 2) { setFormError('Customer name must be at least 2 characters.'); return; }
    setBusy(true);
    try {
      const client = createClient();
      const payload = { name: form.name.trim(), phone: form.phone.trim() || null, email: form.email.trim() || null, address: form.address.trim() || null, notes: form.notes.trim() || null };
      if (editing) {
        const { error: updateError } = await client.from('customers').update(payload).eq('id', editing.id).eq('business_id', business.id);
        if (updateError) throw updateError;
        notify('Customer updated.');
      } else {
        const { data: { user } } = await client.auth.getUser();
        const { error: insertError } = await client.from('customers').insert({ ...payload, business_id: business.id, created_by: user?.id });
        if (insertError) throw insertError;
        notify('Customer added.');
      }
      setModalOpen(false); await load();
    } catch (err) { setFormError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function archive() {
    if (!archiveTarget) return;
    setBusy(true);
    try {
      const { error: archiveError } = await createClient().from('customers').update({ archived_at: new Date().toISOString() }).eq('id', archiveTarget.id).eq('business_id', business.id);
      if (archiveError) throw archiveError;
      notify('Customer archived. Their sales history is unchanged.'); setArchiveTarget(null); await load();
    } catch (err) { notify(errorMessage(err), 'error'); }
    finally { setBusy(false); }
  }

  const totalDebt = Array.from(balances.values()).reduce((sum, value) => sum + value, 0);

  return <>
    <PageHeader title={t('customers')} description="Contact details, purchase history and debt balances." actions={<button className="button button-primary" onClick={openCreate}><Plus size={16} /> {t('add')} customer</button>} />
    <div className="metric-grid" style={{ gridTemplateColumns: 'repeat(3,minmax(0,1fr))' }}>
      <div className="metric-card"><span className="metric-label">Customers</span><strong className="metric-value">{number(customers.length, language)}</strong><span className="metric-sub">Active customer records</span></div>
      <div className="metric-card"><span className="metric-label">Outstanding debt</span><strong className="metric-value" style={{ color: totalDebt > 0 ? 'var(--amber)' : undefined }}>{currency(totalDebt, business.currency_code, language)}</strong><span className="metric-sub">{number(new Set(debts.map((debt) => debt.customer_id)).size, language)} customers with balance</span></div>
      <div className="metric-card"><span className="metric-label">Settled customers</span><strong className="metric-value">{number(customers.filter((customer) => !balances.has(customer.id)).length, language)}</strong><span className="metric-sub">No outstanding balance</span></div>
    </div>
    <div className="toolbar"><div className="search-field"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name or phone" aria-label="Search customers" /></div><div className="toolbar-spacer" /></div>
    <section className="card">
      {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : error ? <div className="card-body"><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={load}>{t('tryAgain')}</button></div>
        : filtered.length === 0 ? <EmptyState icon={<Users size={22} />} title={search ? 'No matching customers' : 'No customers yet'} description={search ? 'Try another name or phone number.' : 'Add customers to track credit sales, balances and statements.'} action={!search ? <button className="button button-primary button-sm" onClick={openCreate}><Plus size={15} /> Add customer</button> : undefined} />
          : <div className="table-wrap"><table className="data-table"><thead><tr><th>{t('name')}</th><th>{t('phone')}</th><th>Email</th><th className="numeric">Balance</th><th /></tr></thead><tbody>
            {filtered.map((customer) => {
              const balance = balances.get(customer.id) ?? 0;
              return <tr key={customer.id}>
                <td className="cell-primary"><Link href={`/customers/${customer.id}`}>{customer.name}</Link><span className="cell-secondary">{customer.address || '—'}</span></td>
                <td>{customer.phone || '—'}</td>
                <td>{customer.email || '—'}</td>
                <td className={`numeric ${balance > 0 ? 'text-danger' : 'text-success'}`}><strong>{currency(balance, business.currency_code, language)}</strong></td>
                <td><div className="row-actions"><Link href={`/customers/${customer.id}`} className="row-action" aria-label={`Statement for ${customer.name}`}>Statement</Link><button className="row-action" onClick={() => openEdit(customer)} aria-label={`Edit ${customer.name}`}><Pencil size={14} /></button></div></td>
              </tr>;
            })}
          </tbody></table></div>}
    </section>
    <Modal open={modalOpen} title={editing ? 'Edit customer' : 'Add customer'} onClose={() => setModalOpen(false)} size="sm">
      <form className="form-stack" onSubmit={save}>
        {formError && <div className="form-error" role="alert">{formError}</div>}
        <div className="field"><label htmlFor="name">Full name</label><input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Neema Juma" /></div>
        <div className="form-row">
          <div className="field"><label htmlFor="phone">Phone</label><input id="phone" type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+255 7xx xxx xxx" /></div>
          <div className="field"><label htmlFor="email">Email</label><input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="optional" /></div>
        </div>
        <div className="field"><label htmlFor="address">Address</label><input id="address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
        <div className="field"><label htmlFor="notes">Notes</label><textarea id="notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Credit terms, delivery preference…" /></div>
        <div className="form-actions">
          {editing && <button type="button" className="button button-danger-soft" onClick={() => { setModalOpen(false); setArchiveTarget(editing); }}>{t('archive')}</button>}
          <div style={{ flex: 1 }} />
          <button type="button" className="button button-ghost" onClick={() => setModalOpen(false)}>{t('cancel')}</button>
          <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : t('save')}</button>
        </div>
      </form>
    </Modal>
    <ConfirmDialog open={!!archiveTarget} title="Archive customer" message="They will no longer appear in new sales. Past sales, repayments and statements remain available." confirmLabel="Archive" danger busy={busy} onConfirm={archive} onClose={() => setArchiveTarget(null)} />
  </>;
}
