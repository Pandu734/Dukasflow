'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, Printer } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { StatusBadge } from '@/components/ui';
import { currency, errorMessage, localDate, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Customer, DebtPayment, Sale } from '@/types';

export default function CustomerStatementPage() {
  const params = useParams<{ id: string }>();
  const { business, language, t } = useApp();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [sales, setSales] = useState<Sale[]>([]);
  const [payments, setPayments] = useState<DebtPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const client = createClient();
    const [customerResult, salesResult, paymentResult] = await Promise.all([
      client.from('customers').select('*').eq('business_id', business.id).eq('id', params.id).maybeSingle(),
      client.from('sales').select('*').eq('business_id', business.id).eq('customer_id', params.id).order('sold_at', { ascending: false }),
      client.from('debt_payments').select('*').eq('business_id', business.id).eq('customer_id', params.id).order('paid_at', { ascending: false }),
    ]);
    if (customerResult.error || !customerResult.data) setError(customerResult.error ? errorMessage(customerResult.error) : 'Customer not found.');
    else { setCustomer(customerResult.data as Customer); setSales((salesResult.data ?? []) as Sale[]); setPayments((paymentResult.data ?? []) as DebtPayment[]); }
    setLoading(false);
  }, [business.id, params.id]);
  useEffect(() => { void load(); }, [load]);

  const money = (value: number) => currency(value, business.currency_code, language);
  const activeSales = sales.filter((sale) => sale.status === 'completed');
  const lifetime = activeSales.reduce((sum, sale) => sum + Number(sale.total), 0);
  const balance = activeSales.reduce((sum, sale) => sum + Math.max(0, Number(sale.total) - Number(sale.amount_paid)), 0);
  const paid = activeSales.reduce((sum, sale) => sum + Number(sale.amount_paid), 0);

  if (loading) return <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div>;
  if (error || !customer) return <div className="card card-body"><div className="form-error">{error || 'Customer not found.'}</div><Link href="/customers" className="button button-ghost button-sm" style={{ marginTop: 12 }}>Back to customers</Link></div>;

  return <>
    <PageHeader title={customer.name} description={`${customer.phone ?? 'No phone'} · ${customer.address ?? 'No address'}`} actions={<><Link href="/customers" className="button button-ghost"><ArrowLeft size={15} /> Back</Link><button className="button button-ghost" onClick={() => window.print()}><Printer size={15} /> Print statement</button><Link href="/sales/new" className="button button-primary">New sale</Link></>} />
    <div className="metric-grid" style={{ gridTemplateColumns: 'repeat(3,minmax(0,1fr))' }}>
      <div className="metric-card"><span className="metric-label">Lifetime purchases</span><strong className="metric-value">{money(lifetime)}</strong><span className="metric-sub">{number(activeSales.length, language)} completed sales</span></div>
      <div className="metric-card"><span className="metric-label">Total paid</span><strong className="metric-value text-success">{money(paid)}</strong><span className="metric-sub">Initial payments + repayments</span></div>
      <div className="metric-card"><span className="metric-label">Outstanding balance</span><strong className="metric-value" style={{ color: balance > 0 ? 'var(--amber)' : 'var(--green-700)' }}>{money(balance)}</strong><span className="metric-sub">{balance > 0 ? 'Awaiting repayment' : 'Fully settled'}</span></div>
    </div>
    <div className="section-grid">
      <section className="card span-7">
        <div className="card-header"><h2>Sales history</h2></div>
        {activeSales.length === 0 && sales.length === 0 ? <div className="card-body muted" style={{ fontSize: 12 }}>No sales recorded for this customer yet.</div> : <div className="table-wrap"><table className="data-table" style={{ minWidth: 520 }}><thead><tr><th>Sale</th><th>{t('date')}</th><th className="numeric">Total</th><th className="numeric">Paid</th><th>Balance</th><th /></tr></thead><tbody>
          {sales.map((sale) => <tr key={sale.id}><td className="cell-primary">{sale.sale_number}</td><td>{localDate(sale.sold_at, language)}</td><td className="numeric">{money(Number(sale.total))}</td><td className="numeric">{money(Number(sale.amount_paid))}</td><td>{sale.status === 'reversed' ? <StatusBadge status="reversed" /> : money(Math.max(0, Number(sale.total) - Number(sale.amount_paid)))}</td><td><div className="row-actions"><Link href={`/sales/${sale.id}`} className="row-action" aria-label={`Open ${sale.sale_number}`}>↗</Link></div></td></tr>)}
        </tbody></table></div>}
      </section>
      <section className="card span-5">
        <div className="card-header"><h2>Repayment history</h2></div>
        {payments.length === 0 ? <div className="card-body muted" style={{ fontSize: 12 }}>No repayments recorded yet.</div> : <div className="card-body" style={{ paddingTop: 4 }}>{payments.map((payment) => <div key={payment.id} className="recent-item"><span className="recent-icon">✓</span><div><strong>{money(Number(payment.amount))}</strong><span>{localDate(payment.paid_at, language, true)} · {payment.payment_method.replaceAll('_', ' ')}</span></div><span className="badge badge-paid">received</span></div>)}</div>}
      </section>
    </div>
    <p className="field-help" style={{ marginTop: 14 }}>Statement generated by DukaFlow on {localDate(new Date(), language, true)}. Amounts in {business.currency_code}.</p>
  </>;
}
