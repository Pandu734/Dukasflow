'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Boxes, Plus, Search } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { EmptyState, Modal, StatusBadge } from '@/components/ui';
import { currency, errorMessage, localDate, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Product, StockMovement } from '@/types';

export default function InventoryPage() {
  const { business, language, t, notify } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [mode, setMode] = useState<'stock_in' | 'adjustment'>('stock_in');
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');
  const [form, setForm] = useState({ product_id: '', quantity: '', unit_cost: '', direction: 'decrease', reason: '' });

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const client = createClient();
    const [productResult, movementResult] = await Promise.all([
      client.from('products').select('*,categories!products_category_id_fkey(name)').eq('business_id', business.id).is('archived_at', null).order('name'),
      client.from('stock_movements').select('*,products!stock_movements_product_id_fkey(name,sku)').eq('business_id', business.id).order('created_at', { ascending: false }).limit(80),
    ]);
    if (productResult.error || movementResult.error) setError(errorMessage(productResult.error || movementResult.error));
    else { const list = (productResult.data ?? []) as Product[]; setProducts(list); setMovements((movementResult.data ?? []) as StockMovement[]); setForm((prev) => ({ ...prev, product_id: prev.product_id || list[0]?.id || '' })); }
    setLoading(false);
  }, [business.id]);
  useEffect(() => { void load(); }, [load]);

  const lowStock = products.filter((product) => product.quantity_stock <= product.low_stock_threshold);
  const valuation = products.reduce((sum, product) => sum + product.quantity_stock * product.purchase_cost, 0);
  const filteredMovements = useMemo(() => {
    const needle = search.trim().toLowerCase();
    if (!needle) return movements;
    return movements.filter((movement) => (movement.products?.name ?? '').toLowerCase().includes(needle) || (movement.reason ?? '').toLowerCase().includes(needle) || movement.movement_type.includes(needle));
  }, [movements, search]);

  const selected = products.find((product) => product.id === form.product_id);

  function open(modeValue: 'stock_in' | 'adjustment') {
    setMode(modeValue); setFormError(''); setModalOpen(true);
    setForm({ product_id: products[0]?.id ?? '', quantity: '', unit_cost: products[0] ? String(products[0].purchase_cost) : '', direction: 'decrease', reason: '' });
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormError('');
    const quantity = Number(form.quantity);
    if (!form.product_id) { setFormError('Choose a product.'); return; }
    if (!Number.isFinite(quantity) || quantity <= 0) { setFormError('Enter a quantity greater than zero.'); return; }
    if (mode === 'adjustment' && form.reason.trim().length < 3) { setFormError('Describe why you are adjusting stock.'); return; }
    if (mode === 'adjustment' && form.direction === 'decrease' && !business.allow_negative_stock && selected && selected.quantity_stock < quantity) { setFormError('This would make stock negative. Reduce the quantity or enable negative stock in Settings.'); return; }
    setBusy(true);
    try {
      const { error: rpcError } = await createClient().rpc('record_stock_movement', {
        p_business_id: business.id, p_product_id: form.product_id, p_movement_type: mode,
        p_quantity: mode === 'adjustment' && form.direction === 'decrease' ? -quantity : quantity,
        p_reason: form.reason.trim() || 'Stock received', p_unit_cost: mode === 'stock_in' && form.unit_cost !== '' ? Number(form.unit_cost) : null,
      });
      if (rpcError) throw rpcError;
      notify(mode === 'stock_in' ? 'Stock received and recorded.' : 'Stock adjustment recorded.');
      setModalOpen(false); await load();
    } catch (err) { setFormError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  return <>
    <PageHeader title={t('inventory')} description="Stock levels, valuation and an audited movement trail." actions={<>
      <button className="button button-ghost" onClick={() => open('adjustment')}>Adjust stock</button>
      <button className="button button-primary" onClick={() => open('stock_in')}><Plus size={16} /> Stock in</button>
    </>} />
    <div className="metric-grid" style={{ gridTemplateColumns: 'repeat(3,minmax(0,1fr))' }}>
      <div className="metric-card"><span className="metric-label">Inventory valuation</span><strong className="metric-value">{currency(valuation, business.currency_code, language)}</strong><span className="metric-sub">At purchase cost</span></div>
      <div className="metric-card"><span className="metric-label">Products tracked</span><strong className="metric-value">{number(products.length, language)}</strong><span className="metric-sub">{number(products.reduce((sum, product) => sum + product.quantity_stock, 0), language)} units on hand</span></div>
      <div className="metric-card"><span className="metric-label">Low stock</span><strong className="metric-value" style={{ color: lowStock.length ? 'var(--amber)' : undefined }}>{number(lowStock.length, language)}</strong><span className="metric-sub">At or below alert level</span></div>
    </div>
    {error && <div className="card card-body" style={{ marginBottom: 16 }}><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={load}>{t('tryAgain')}</button></div>}
    {lowStock.length > 0 && <div className="card" style={{ marginBottom: 16, borderColor: '#f0dfba', background: '#fffdf7' }}>
      <div className="card-header" style={{ borderColor: '#f3e7cd' }}><h2>Low-stock alerts</h2><span className="muted" style={{ fontSize: 10 }}>{lowStock.length} products need attention</span></div>
      <div className="card-body" style={{ display: 'grid', gap: 8 }}>{lowStock.slice(0, 5).map((product) => <div key={product.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}><span style={{ fontWeight: 700, color: 'var(--navy-900)' }}>{product.name}</span><span style={{ color: 'var(--amber)' }}>{number(product.quantity_stock, language)} left · alert at {number(product.low_stock_threshold, language)}</span></div>)}</div>
    </div>}
    <section className="card">
      <div className="card-header"><h2>Stock movement history</h2><div className="search-field" style={{ minWidth: 200, height: 34 }}><Search size={14} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search movements" aria-label="Search stock movements" /></div></div>
      {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : filteredMovements.length === 0 ? <EmptyState icon={<Boxes size={22} />} title="No stock movements yet" description="Receive stock or record an adjustment to start the audited trail." action={<button className="button button-primary button-sm" onClick={() => open('stock_in')}>Stock in</button>} />
        : <div className="table-wrap"><table className="data-table"><thead><tr><th>{t('date')}</th><th>Product</th><th>Type</th><th className="numeric">Change</th><th className="numeric">Before → After</th><th>Reason</th></tr></thead><tbody>
          {filteredMovements.map((movement) => <tr key={movement.id}>
            <td>{localDate(movement.created_at, language, true)}</td>
            <td className="cell-primary">{movement.products?.name ?? 'Deleted product'}<span className="cell-secondary">{movement.products?.sku ?? ''}</span></td>
            <td><StatusBadge status={movement.movement_type} /></td>
            <td className={`numeric ${movement.quantity_delta >= 0 ? 'text-success' : 'text-danger'}`}><strong>{movement.quantity_delta > 0 ? '+' : ''}{number(movement.quantity_delta, language, 3)}</strong></td>
            <td className="numeric">{number(movement.quantity_before, language, 3)} → {number(movement.quantity_after, language, 3)}</td>
            <td>{movement.reason || '—'}</td>
          </tr>)}
        </tbody></table></div>}
    </section>

    <Modal open={modalOpen} title={mode === 'stock_in' ? 'Receive stock' : 'Adjust stock'} onClose={() => setModalOpen(false)} size="sm">
      <form className="form-stack" onSubmit={submit}>
        {formError && <div className="form-error" role="alert">{formError}</div>}
        <div className="field"><label htmlFor="product">Product</label><select id="product" required value={form.product_id} onChange={(e) => setForm({ ...form, product_id: e.target.value })}>{products.length === 0 && <option value="">Add a product first</option>}{products.map((product) => <option key={product.id} value={product.id}>{product.name} — {number(product.quantity_stock, language, 3)} in stock</option>)}</select></div>
        {mode === 'adjustment' && <div className="field"><label htmlFor="direction">Direction</label><select id="direction" value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value })}><option value="decrease">Decrease stock</option><option value="increase">Increase stock</option></select></div>}
        <div className="form-row">
          <div className="field"><label htmlFor="quantity">Quantity</label><input id="quantity" type="number" min="0.001" step="0.001" required value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></div>
          {mode === 'stock_in' && <div className="field"><label htmlFor="unit_cost">Unit cost ({business.currency_code})</label><input id="unit_cost" type="number" min="0" step="0.01" value={form.unit_cost} onChange={(e) => setForm({ ...form, unit_cost: e.target.value })} /></div>}
        </div>
        <div className="field"><label htmlFor="reason">{mode === 'stock_in' ? 'Note (optional)' : 'Reason'}</label><input id="reason" required={mode === 'adjustment'} value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder={mode === 'stock_in' ? 'Supplier delivery, invoice no.' : 'Damaged, expired, stock count correction…'} /></div>
        {selected && <p className="field-help">Current stock: {number(selected.quantity_stock, language, 3)} {selected.sku ? `· ${selected.sku}` : ''}</p>}
        <div className="form-actions"><button type="button" className="button button-ghost" onClick={() => setModalOpen(false)}>{t('cancel')}</button><button className="button button-primary" disabled={busy || products.length === 0}>{busy ? 'Recording…' : 'Record movement'}</button></div>
      </form>
    </Modal>
  </>;
}
