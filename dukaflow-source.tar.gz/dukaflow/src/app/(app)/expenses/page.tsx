'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Pencil, Plus, Search, Wallet } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { ConfirmDialog, EmptyState, Modal, StatusBadge } from '@/components/ui';
import { currency, errorMessage, isoDate, localDate, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Expense } from '@/types';

const categories = ['Rent', 'Utilities', 'Salaries', 'Transport', 'Supplies', 'Marketing', 'Maintenance', 'Taxes & fees', 'Other'];
const emptyForm = { category: 'Rent', description: '', amount: '', expense_date: isoDate(), payment_method: 'cash' };

export default function ExpensesPage() {
  const { business, language, t, notify } = useApp();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Expense | null>(null);
  const [archiveTarget, setArchiveTarget] = useState<Expense | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const { data, error: queryError } = await createClient().from('expenses').select('*').eq('business_id', business.id).order('expense_date', { ascending: false }).limit(400);
    if (queryError) setError(errorMessage(queryError)); else setExpenses((data ?? []) as Expense[]);
    setLoading(false);
  }, [business.id]);
  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => expenses.filter((expense) => {
    if (showArchived ? !expense.archived_at : !!expense.archived_at) return false;
    const needle = search.trim().toLowerCase();
    return !needle || expense.description.toLowerCase().includes(needle) || expense.category.toLowerCase().includes(needle);
  }), [expenses, search, showArchived]);
  const total = filtered.reduce((sum, expense) => sum + Number(expense.amount), 0);
  const thisMonth = expenses.filter((expense) => !expense.archived_at && expense.expense_date.slice(0, 7) === isoDate().slice(0, 7)).reduce((sum, expense) => sum + Number(expense.amount), 0);

  function openCreate() { setEditing(null); setFormError(''); setForm({ ...emptyForm, expense_date: isoDate() }); setModalOpen(true); }
  function openEdit(expense: Expense) { setEditing(expense); setFormError(''); setForm({ category: expense.category, description: expense.description, amount: String(expense.amount), expense_date: expense.expense_date, payment_method: expense.payment_method }); setModalOpen(true); }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormError('');
    const amount = Number(form.amount);
    if (!form.description.trim()) { setFormError('Describe the expense.'); return; }
    if (!Number.isFinite(amount) || amount <= 0) { setFormError('Amount must be greater than zero.'); return; }
    if (!form.expense_date) { setFormError('Choose the expense date.'); return; }
    setBusy(true);
    try {
      const client = createClient();
      const payload = { category: form.category, description: form.description.trim(), amount, expense_date: form.expense_date, payment_method: form.payment_method };
      if (editing) {
        const { error: updateError } = await client.from('expenses').update(payload).eq('id', editing.id).eq('business_id', business.id);
        if (updateError) throw updateError;
        notify('Expense updated. The change is in the audit trail.');
      } else {
        const { data: { user } } = await client.auth.getUser();
        const { error: insertError } = await client.from('expenses').insert({ ...payload, business_id: business.id, created_by: user?.id });
        if (insertError) throw insertError;
        notify('Expense recorded. Net profit updated.');
      }
      setModalOpen(false); await load();
    } catch (err) { setFormError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function archive() {
    if (!archiveTarget) return;
    setBusy(true);
    try {
      const { error: archiveError } = await createClient().from('expenses').update({ archived_at: new Date().toISOString() }).eq('id', archiveTarget.id).eq('business_id', business.id);
      if (archiveError) throw archiveError;
      notify('Expense archived.'); setArchiveTarget(null); await load();
    } catch (err) { notify(errorMessage(err), 'error'); }
    finally { setBusy(false); }
  }

  return <>
    <PageHeader title={t('expenses')} description="Operating costs that reduce net profit—not cost of goods sold." actions={<button className="button button-primary" onClick={openCreate}><Plus size={16} /> {t('add')} expense</button>} />
    <div className="metric-grid" style={{ gridTemplateColumns: 'repeat(3,minmax(0,1fr))' }}>
      <div className="metric-card"><span className="metric-label">Shown total</span><strong className="metric-value">{currency(total, business.currency_code, language)}</strong><span className="metric-sub">{number(filtered.length, language)} records</span></div>
      <div className="metric-card"><span className="metric-label">This month</span><strong className="metric-value">{currency(thisMonth, business.currency_code, language)}</strong><span className="metric-sub">Excludes archived expenses</span></div>
      <div className="metric-card"><span className="metric-label">Categories used</span><strong className="metric-value">{number(new Set(expenses.filter((expense) => !expense.archived_at).map((expense) => expense.category)).size, language)}</strong><span className="metric-sub">Across active records</span></div>
    </div>
    <div className="toolbar">
      <div className="search-field"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search expenses" aria-label="Search expenses" /></div>
      <select className="select-control" value={showArchived ? 'archived' : 'active'} onChange={(e) => setShowArchived(e.target.value === 'archived')} aria-label="Filter expenses"><option value="active">Active expenses</option><option value="archived">Archived</option></select>
      <div className="toolbar-spacer" />
    </div>
    <section className="card">
      {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : error ? <div className="card-body"><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={load}>{t('tryAgain')}</button></div>
        : filtered.length === 0 ? <EmptyState icon={<Wallet size={22} />} title={showArchived ? 'No archived expenses' : 'No expenses recorded'} description={showArchived ? 'Archived expenses remain available with their audit history.' : 'Record rent, salaries, transport and other operating costs here.'} action={!showArchived ? <button className="button button-primary button-sm" onClick={openCreate}><Plus size={15} /> Add expense</button> : undefined} />
          : <div className="table-wrap"><table className="data-table"><thead><tr><th>{t('date')}</th><th>{t('description')}</th><th>{t('category')}</th><th>Method</th><th className="numeric">{t('amount')}</th><th>{t('status')}</th><th /></tr></thead><tbody>
            {filtered.map((expense) => <tr key={expense.id}>
              <td>{localDate(expense.expense_date + 'T12:00:00', language)}</td>
              <td className="cell-primary">{expense.description}</td>
              <td>{expense.category}</td>
              <td>{expense.payment_method.replaceAll('_', ' ')}</td>
              <td className="numeric cell-primary">{currency(expense.amount, business.currency_code, language)}</td>
              <td>{expense.archived_at ? <StatusBadge status="archived" /> : <StatusBadge status="active" />}</td>
              <td><div className="row-actions">{!expense.archived_at && <button className="row-action" onClick={() => openEdit(expense)} aria-label={`Edit ${expense.description}`}><Pencil size={14} /></button>}</div></td>
            </tr>)}
          </tbody></table></div>}
    </section>
    <Modal open={modalOpen} title={editing ? 'Edit expense' : 'Add expense'} onClose={() => setModalOpen(false)} size="sm">
      <form className="form-stack" onSubmit={save}>
        {formError && <div className="form-error" role="alert">{formError}</div>}
        <div className="field"><label htmlFor="category">Category</label><select id="category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{categories.map((category) => <option key={category}>{category}</option>)}</select></div>
        <div className="field"><label htmlFor="description">Description</label><input id="description" required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Shop rent for November" /></div>
        <div className="form-row">
          <div className="field"><label htmlFor="amount">Amount ({business.currency_code})</label><input id="amount" type="number" min="0.01" step="0.01" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
          <div className="field"><label htmlFor="expense_date">Date</label><input id="expense_date" type="date" required max={isoDate()} value={form.expense_date} onChange={(e) => setForm({ ...form, expense_date: e.target.value })} /></div>
        </div>
        <div className="field"><label htmlFor="payment_method">Paid by</label><select id="payment_method" value={form.payment_method} onChange={(e) => setForm({ ...form, payment_method: e.target.value })}><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="bank_transfer">Bank transfer</option><option value="other">Other</option></select></div>
        <div className="form-actions">
          {editing && <button type="button" className="button button-danger-soft" onClick={() => { setModalOpen(false); setArchiveTarget(editing); }}>{t('archive')}</button>}
          <div style={{ flex: 1 }} />
          <button type="button" className="button button-ghost" onClick={() => setModalOpen(false)}>{t('cancel')}</button>
          <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : t('save')}</button>
        </div>
      </form>
    </Modal>
    <ConfirmDialog open={!!archiveTarget} title="Archive expense" message="The expense will be excluded from reports but kept with its audit history." confirmLabel="Archive" danger busy={busy} onConfirm={archive} onClose={() => setArchiveTarget(null)} />
  </>;
}
