'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Package, Pencil, Plus, Search } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { ConfirmDialog, EmptyState, Modal, StatusBadge } from '@/components/ui';
import { currency, errorMessage, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Category, Product } from '@/types';

type FormState = { name: string; sku: string; category_id: string; purchase_cost: string; selling_price: string; quantity_stock: string; low_stock_threshold: string };

export default function ProductsPage() {
  const { business, language, t, notify } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [stockFilter, setStockFilter] = useState('active');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');
  const [archiveTarget, setArchiveTarget] = useState<Product | null>(null);
  const [form, setForm] = useState<FormState>({ name: '', sku: '', category_id: '', purchase_cost: '0', selling_price: '0', quantity_stock: '0', low_stock_threshold: '5' });

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const client = createClient();
    const [productsResult, categoriesResult] = await Promise.all([
      client.from('products').select('*,categories!products_category_id_fkey(name)').eq('business_id', business.id).order('created_at', { ascending: false }),
      client.from('categories').select('id,business_id,name,archived_at').eq('business_id', business.id).is('archived_at', null).order('name'),
    ]);
    if (productsResult.error || categoriesResult.error) setError(errorMessage(productsResult.error || categoriesResult.error));
    else { setProducts((productsResult.data ?? []) as Product[]); setCategories((categoriesResult.data ?? []) as Category[]); }
    setLoading(false);
  }, [business.id]);

  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => products.filter((product) => {
    if (stockFilter === 'active' && product.archived_at) return false;
    if (stockFilter === 'archived' && !product.archived_at) return false;
    if (stockFilter === 'low' && (product.archived_at || product.quantity_stock > product.low_stock_threshold)) return false;
    if (categoryFilter && product.category_id !== categoryFilter) return false;
    const needle = search.trim().toLowerCase();
    return !needle || product.name.toLowerCase().includes(needle) || (product.sku ?? '').toLowerCase().includes(needle);
  }), [products, search, categoryFilter, stockFilter]);

  function openCreate() { setEditing(null); setFormError(''); setForm({ name: '', sku: '', category_id: categories[0]?.id ?? '', purchase_cost: '0', selling_price: '0', quantity_stock: '0', low_stock_threshold: '5' }); setModalOpen(true); }
  function openEdit(product: Product) {
    setEditing(product); setFormError('');
    setForm({ name: product.name, sku: product.sku ?? '', category_id: product.category_id ?? '', purchase_cost: String(product.purchase_cost), selling_price: String(product.selling_price), quantity_stock: String(product.quantity_stock), low_stock_threshold: String(product.low_stock_threshold) });
    setModalOpen(true);
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormError('');
    const purchase = Number(form.purchase_cost), selling = Number(form.selling_price);
    if (form.name.trim().length < 2) { setFormError('Product name must be at least 2 characters.'); return; }
    if (!Number.isFinite(purchase) || purchase < 0 || !Number.isFinite(selling) || selling < 0) { setFormError('Prices must be valid positive numbers.'); return; }
    if (selling < purchase) { setFormError('Selling price should not be below the purchase cost.'); return; }
    setBusy(true);
    try {
      const client = createClient();
      if (editing) {
        if (Number(form.quantity_stock) !== editing.quantity_stock) { setFormError('Stock cannot be edited here. Use Inventory → Stock in or Adjustment so the change is audited.'); setBusy(false); return; }
        const { error: updateError } = await client.from('products').update({
          name: form.name.trim(), sku: form.sku.trim() || null, category_id: form.category_id || null,
          purchase_cost: purchase, selling_price: selling, low_stock_threshold: Number(form.low_stock_threshold) || 0,
        }).eq('id', editing.id).eq('business_id', business.id);
        if (updateError) throw updateError;
        notify('Product updated.');
      } else {
        const { data, error: insertError } = await client.from('products').insert({
          business_id: business.id, name: form.name.trim(), sku: form.sku.trim() || null, category_id: form.category_id || null,
          purchase_cost: purchase, selling_price: selling, low_stock_threshold: Number(form.low_stock_threshold) || 0, created_by: (await client.auth.getUser()).data.user?.id,
        }).select('id').single();
        if (insertError) throw insertError;
        const opening = Number(form.quantity_stock) || 0;
        if (opening > 0) {
          const { error: stockError } = await client.rpc('record_stock_movement', { p_business_id: business.id, p_product_id: data.id, p_movement_type: 'stock_in', p_quantity: opening, p_reason: 'Opening stock', p_unit_cost: purchase });
          if (stockError) throw stockError;
        }
        notify('Product added' + (opening > 0 ? ' with opening stock.' : '.'));
      }
      setModalOpen(false); await load();
    } catch (err) { setFormError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function archiveConfirmed() {
    if (!archiveTarget) return;
    setBusy(true);
    try {
      const { error: archiveError } = await createClient().from('products').update({ archived_at: new Date().toISOString() }).eq('id', archiveTarget.id).eq('business_id', business.id);
      if (archiveError) throw archiveError;
      notify('Product archived.'); setArchiveTarget(null); await load();
    } catch (err) { notify(errorMessage(err), 'error'); }
    finally { setBusy(false); }
  }

  return <>
    <PageHeader title={t('products')} description="Your catalogue, prices and stock levels." actions={<button className="button button-primary" onClick={openCreate}><Plus size={16} /> {t('add')} product</button>} />
    <div className="toolbar">
      <div className="search-field"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={`${t('search')} products or SKU`} aria-label="Search products" /></div>
      <select className="select-control" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} aria-label="Filter by category"><option value="">All categories</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select>
      <select className="select-control" value={stockFilter} onChange={(e) => setStockFilter(e.target.value)} aria-label="Filter by status"><option value="active">Active products</option><option value="low">Low stock</option><option value="archived">Archived</option><option value="all">All products</option></select>
      <div className="toolbar-spacer" /><span className="muted" style={{ fontSize: 11 }}>{number(filtered.length, language)} products</span>
    </div>
    <section className="card">
      {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : error ? <div className="card-body"><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={load}>{t('tryAgain')}</button></div>
        : filtered.length === 0 ? <EmptyState icon={<Package size={22} />} title={search || categoryFilter ? 'No matching products' : 'No products yet'} description={search || categoryFilter ? 'Try a different search or filter.' : 'Add your first product to start selling and tracking stock.'} action={!search && !categoryFilter ? <button className="button button-primary button-sm" onClick={openCreate}><Plus size={15} /> Add product</button> : undefined} />
          : <div className="table-wrap"><table className="data-table"><thead><tr><th>Product</th><th>{t('category')}</th><th className="numeric">Buy</th><th className="numeric">Sell</th><th>Stock</th><th>{t('status')}</th><th /></tr></thead><tbody>
            {filtered.map((product) => {
              const state = product.quantity_stock <= 0 ? 'out' : product.quantity_stock <= product.low_stock_threshold ? 'low' : '';
              const ratio = Math.min(100, (product.quantity_stock / Math.max(1, product.low_stock_threshold * 3)) * 100);
              return <tr key={product.id}>
                <td className="cell-primary">{product.name}<span className="cell-secondary">{product.sku || 'No SKU'}</span></td>
                <td>{product.categories?.name ?? '—'}</td>
                <td className="numeric">{currency(product.purchase_cost, business.currency_code, language)}</td>
                <td className="numeric cell-primary">{currency(product.selling_price, business.currency_code, language)}</td>
                <td><div className="stock-level"><strong>{number(product.quantity_stock, language)}</strong><span className={`stock-bar ${state}`}><span style={{ width: `${state === 'out' ? 0 : ratio}%` }} /></span></div></td>
                <td>{product.archived_at ? <StatusBadge status="archived" /> : product.quantity_stock <= product.low_stock_threshold ? <StatusBadge status="low" /> : <StatusBadge status="active" />}</td>
                <td><div className="row-actions"><button className="row-action" onClick={() => openEdit(product)} aria-label={`Edit ${product.name}`}><Pencil size={14} /></button></div></td>
              </tr>;
            })}
          </tbody></table></div>}
    </section>

    <Modal open={modalOpen} title={editing ? 'Edit product' : 'Add product'} onClose={() => setModalOpen(false)} size="md">
      <form onSubmit={save} className="form-stack">
        {formError && <div className="form-error" role="alert">{formError}</div>}
        <div className="form-row">
          <div className="field"><label htmlFor="name">Product name</label><input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Cooking oil 1L" /></div>
          <div className="field"><label htmlFor="sku">SKU / code</label><input id="sku" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} placeholder="OIL-1L" /></div>
        </div>
        <div className="field"><label htmlFor="category">Category</label><select id="category" value={form.category_id} onChange={(e) => setForm({ ...form, category_id: e.target.value })}><option value="">Uncategorised</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></div>
        <div className="form-row">
          <div className="field"><label htmlFor="purchase_cost">Purchase cost ({business.currency_code})</label><input id="purchase_cost" type="number" min="0" step="0.01" required value={form.purchase_cost} onChange={(e) => setForm({ ...form, purchase_cost: e.target.value })} /></div>
          <div className="field"><label htmlFor="selling_price">Selling price ({business.currency_code})</label><input id="selling_price" type="number" min="0" step="0.01" required value={form.selling_price} onChange={(e) => setForm({ ...form, selling_price: e.target.value })} /></div>
        </div>
        <div className="form-row">
          <div className="field"><label htmlFor="quantity_stock">{editing ? 'Current stock' : 'Opening stock'}</label><input id="quantity_stock" type="number" min="0" step="0.001" disabled={!!editing} value={form.quantity_stock} onChange={(e) => setForm({ ...form, quantity_stock: e.target.value })} /><span className="field-help">{editing ? 'Use Inventory for audited stock changes.' : 'Recorded as an audited stock-in movement.'}</span></div>
          <div className="field"><label htmlFor="low_stock_threshold">Low-stock alert at</label><input id="low_stock_threshold" type="number" min="0" step="1" value={form.low_stock_threshold} onChange={(e) => setForm({ ...form, low_stock_threshold: e.target.value })} /></div>
        </div>
        <div className="form-actions">
          {editing && !editing.archived_at && <button type="button" className="button button-danger-soft" onClick={() => { setModalOpen(false); setArchiveTarget(editing); }}>{t('archive')}</button>}
          <div style={{ flex: 1 }} />
          <button type="button" className="button button-ghost" onClick={() => setModalOpen(false)}>{t('cancel')}</button>
          <button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : t('save')}</button>
        </div>
      </form>
    </Modal>
    <ConfirmDialog open={!!archiveTarget} title="Archive product" message={`${archiveTarget?.name ?? 'This product'} will be hidden from new sales. Stock history and past sales stay intact.`} confirmLabel="Archive" danger busy={busy} onConfirm={archiveConfirmed} onClose={() => setArchiveTarget(null)} />
  </>;
}
