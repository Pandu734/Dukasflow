'use client';
import Link from 'next/link';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { CreditCard, Search } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { EmptyState, Modal, StatusBadge } from '@/components/ui';
import { currency, errorMessage, localDate, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Debt, DebtPayment } from '@/types';

export default function DebtsPage() {
  const { business, language, t, notify } = useApp();
  const [debts, setDebts] = useState<Debt[]>([]);
  const [payments, setPayments] = useState<DebtPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [payTarget, setPayTarget] = useState<Debt | null>(null);
  const [form, setForm] = useState({ amount: '', method: 'cash', note: '' });
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const client = createClient();
    const [debtResult, paymentResult] = await Promise.all([
      client.from('customer_debts').select('*').eq('business_id', business.id).order('sold_at', { ascending: false }),
      client.from('debt_payments').select('*,customers!debt_payments_customer_id_fkey(name),sales!debt_payments_sale_id_fkey(sale_number)').eq('business_id', business.id).order('paid_at', { ascending: false }).limit(40),
    ]);
    if (debtResult.error || paymentResult.error) setError(errorMessage(debtResult.error || paymentResult.error));
    else { setDebts((debtResult.data ?? []) as Debt[]); setPayments((paymentResult.data ?? []) as DebtPayment[]); }
    setLoading(false);
  }, [business.id]);
  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return debts.filter((debt) => !needle || debt.customer_name.toLowerCase().includes(needle) || debt.sale_number.toLowerCase().includes(needle) || (debt.phone ?? '').includes(needle));
  }, [debts, search]);
  const total = filtered.reduce((sum, debt) => sum + Number(debt.outstanding), 0);
  const customerTotals = useMemo(() => {
    const map = new Map<string, { name: string; phone: string | null; amount: number; sales: number }>();
    debts.forEach((debt) => {
      const existing = map.get(debt.customer_id) ?? { name: debt.customer_name, phone: debt.phone, amount: 0, sales: 0 };
      map.set(debt.customer_id, { ...existing, amount: existing.amount + Number(debt.outstanding), sales: existing.sales + 1 });
    });
    return Array.from(map.entries()).sort((a, b) => b[1].amount - a[1].amount);
  }, [debts]);

  function openPay(debt: Debt) { setPayTarget(debt); setFormError(''); setForm({ amount: String(debt.outstanding), method: 'cash', note: '' }); }

  async function submitPayment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormError('');
    if (!payTarget) return;
    const amount = Number(form.amount);
    if (!Number.isFinite(amount) || amount <= 0) { setFormError('Enter an amount greater than zero.'); return; }
    if (amount > Number(payTarget.outstanding)) { setFormError(`Maximum outstanding is ${currency(payTarget.outstanding, business.currency_code, language)}.`); return; }
    setBusy(true);
    try {
      const { error: rpcError } = await createClient().rpc('record_debt_payment', { p_business_id: business.id, p_sale_id: payTarget.sale_id, p_amount: amount, p_payment_method: form.method, p_paid_at: new Date().toISOString(), p_note: form.note.trim() || null });
      if (rpcError) throw rpcError;
      notify('Repayment saved. Customer balance updated.'); setPayTarget(null); await load();
    } catch (err) { setFormError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  return <>
    <PageHeader title={t('debts')} description="Credit sales, balances and repayments—separate from received cash." />
    <div className="metric-grid" style={{ gridTemplateColumns: 'repeat(3,minmax(0,1fr))' }}>
      <div className="metric-card"><span className="metric-label">Outstanding (shown)</span><strong className="metric-value" style={{ color: total > 0 ? 'var(--amber)' : 'var(--green-700)' }}>{currency(total, business.currency_code, language)}</strong><span className="metric-sub">{number(filtered.length, language)} open credit sales</span></div>
      <div className="metric-card"><span className="metric-label">Customers owing</span><strong className="metric-value">{number(customerTotals.length, language)}</strong><span className="metric-sub">Across all open sales</span></div>
      <div className="metric-card"><span className="metric-label">Repayments recorded</span><strong className="metric-value">{currency(payments.reduce((sum, payment) => sum + Number(payment.amount), 0), business.currency_code, language)}</strong><span className="metric-sub">Counted as cash when received</span></div>
    </div>
    <div className="toolbar"><div className="search-field"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search customer or sale number" aria-label="Search debts" /></div><div className="toolbar-spacer" /></div>
    <div className="section-grid">
      <section className="card span-8">
        <div className="card-header"><h2>Open credit sales</h2></div>
        {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : error ? <div className="card-body"><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={load}>{t('tryAgain')}</button></div>
          : filtered.length === 0 ? <EmptyState icon={<CreditCard size={22} />} title="No outstanding debts" description="Credit sales with a remaining balance appear here until fully repaid." /> :
            <div className="table-wrap"><table className="data-table"><thead><tr><th>Customer</th><th>Sale</th><th>{t('date')}</th><th className="numeric">Total</th><th className="numeric">Paid</th><th className="numeric">Balance</th><th /></tr></thead><tbody>
              {filtered.map((debt) => <tr key={debt.sale_id}>
                <td className="cell-primary"><Link href={`/customers/${debt.customer_id}`}>{debt.customer_name}</Link><span className="cell-secondary">{debt.phone ?? '—'}</span></td>
                <td><Link href={`/sales/${debt.sale_id}`} className="text-link">{debt.sale_number}</Link></td>
                <td>{localDate(debt.sold_at, language)}</td>
                <td className="numeric">{currency(debt.total, business.currency_code, language)}</td>
                <td className="numeric">{currency(debt.amount_paid, business.currency_code, language)}</td>
                <td className="numeric text-danger"><strong>{currency(debt.outstanding, business.currency_code, language)}</strong></td>
                <td><div className="row-actions"><button className="button button-soft button-sm" onClick={() => openPay(debt)}>Repay</button></div></td>
              </tr>)}
            </tbody></table></div>}
      </section>
      <aside className="card span-4">
        <div className="card-header"><h2>By customer</h2></div>
        <div className="card-body" style={{ paddingTop: 5 }}>
          {customerTotals.length === 0 && <p className="muted" style={{ fontSize: 12, padding: '18px 0' }}>No balances to show.</p>}
          {customerTotals.map(([id, entry]) => <Link key={id} href={`/customers/${id}`} className="recent-item"><span className="recent-icon"><CreditCard size={14} /></span><div><strong>{entry.name}</strong><span>{entry.sales} open sale{entry.sales === 1 ? '' : 's'}</span></div><div className="recent-amount"><strong style={{ color: 'var(--amber)' }}>{currency(entry.amount, business.currency_code, language)}</strong></div></Link>)}
        </div>
        <div className="card-header" style={{ borderTop: '1px solid var(--line-soft)' }}><h2>Recent repayments</h2></div>
        <div className="card-body" style={{ paddingTop: 5 }}>
          {payments.length === 0 ? <p className="muted" style={{ fontSize: 12, padding: '18px 0' }}>No repayments recorded yet.</p> : payments.slice(0, 6).map((payment) => <div key={payment.id} className="recent-item"><span className="recent-icon">✓</span><div><strong>{payment.customers?.name ?? 'Customer'}</strong><span>{localDate(payment.paid_at, language)} · {payment.sales?.sale_number ?? ''}</span></div><div className="recent-amount"><strong>{currency(payment.amount, business.currency_code, language)}</strong><span><StatusBadge status="paid" /></span></div></div>)}
        </div>
      </aside>
    </div>
    <Modal open={!!payTarget} title="Record repayment" onClose={() => setPayTarget(null)} size="sm">
      {payTarget && <form className="form-stack" onSubmit={submitPayment}>
        {formError && <div className="form-error" role="alert">{formError}</div>}
        <div className="field"><label>Customer and sale</label><div className="input" style={{ background: '#f6f8fa' }}>{payTarget.customer_name} · {payTarget.sale_number}</div></div>
        <div className="field"><label>Outstanding balance</label><div className="input" style={{ background: '#f6f8fa', fontWeight: 800 }}>{currency(payTarget.outstanding, business.currency_code, language)}</div></div>
        <div className="field"><label htmlFor="amount">Amount received</label><input id="amount" type="number" min="0.01" step="0.01" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
        <div className="field"><label htmlFor="method">Method</label><select id="method" value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="bank_transfer">Bank transfer</option><option value="other">Other</option></select></div>
        <div className="field"><label htmlFor="note">Note (optional)</label><input id="note" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></div>
        <div className="form-actions"><button type="button" className="button button-ghost" onClick={() => setPayTarget(null)}>{t('cancel')}</button><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Record payment'}</button></div>
      </form>}
    </Modal>
  </>;
}
