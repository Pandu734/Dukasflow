'use client';
import { useCallback, useEffect, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { MiniBarChart, PageHeader, TrendChart, type TrendPoint } from '@/components/data-display';
import { DateRangeFilter, defaultRange, type DateRange } from '@/components/date-range-filter';
import { currency, errorMessage, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';

type Report = {
  start_date: string; end_date: string; revenue: number; cash_collected: number; credit_sales: number; cogs: number;
  gross_profit: number; expenses: number; net_profit: number; outstanding_debt: number; inventory_valuation: number;
  product_performance: { product_id: string; product_name: string; product_sku: string; quantity_sold: number; net_revenue: number; cogs: number; gross_profit: number }[];
  expenses_by_category: { category: string; amount: number }[];
  trends: TrendPoint[];
};

export default function ReportsPage() {
  const { business, language, t } = useApp();
  const [range, setRange] = useState<DateRange>(() => defaultRange('month'));
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const { data, error: rpcError } = await createClient().rpc('get_financial_report', { p_business_id: business.id, p_start: range.start, p_end: range.end });
    if (rpcError) setError(errorMessage(rpcError)); else setReport(data as Report);
    setLoading(false);
  }, [business.id, range.start, range.end]);
  useEffect(() => { void load(); }, [load]);

  const money = (value: number | null | undefined) => currency(value, business.currency_code, language);

  function exportCsv() {
    if (!report) return;
    const rows: (string | number)[][] = [
      ['DukaFlow financial report', business.name],
      ['Period', report.start_date, report.end_date], ['Currency', business.currency_code], [],
      ['Summary'], ['Revenue (net sales)', report.revenue], ['Cost of goods sold', report.cogs], ['Gross profit', report.gross_profit],
      ['Operating expenses', report.expenses], ['Net profit', report.net_profit], ['Cash collected', report.cash_collected],
      ['Credit sales', report.credit_sales], ['Outstanding debt', report.outstanding_debt], ['Inventory valuation', report.inventory_valuation], [],
      ['Product performance'], ['Product', 'SKU', 'Qty sold', 'Net revenue', 'COGS', 'Gross profit'],
      ...report.product_performance.map((row) => [row.product_name, row.product_sku, row.quantity_sold, row.net_revenue, row.cogs, row.gross_profit]), [],
      ['Expenses by category'], ['Category', 'Amount'], ...report.expenses_by_category.map((row) => [row.category, row.amount]), [],
      ['Daily trends'], ['Date', 'Sales', 'Gross profit', 'Expenses', 'Net profit'],
      ...report.trends.map((row) => [row.date, row.sales, row.gross_profit, row.expenses, row.net_profit]),
    ];
    const csv = rows.map((row) => row.map((cell) => `"${String(cell ?? '').replaceAll('"', '""')}"`).join(',')).join('\r\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `dukaflow-report-${report.start_date}-to-${report.end_date}.csv`;
    link.click(); URL.revokeObjectURL(link.href);
  }

  return <>
    <PageHeader title={t('reports')} description="Financial performance, product and expense analysis from real records." actions={<>
      <button className="button button-ghost" onClick={() => window.print()}><Printer size={15} /> Print</button>
      <button className="button button-primary" onClick={exportCsv} disabled={!report}><Download size={15} /> Export CSV</button>
    </>} />
    <DateRangeFilter value={range} onChange={setRange} labels={{ today: t('today'), last7: t('last7'), thisMonth: t('thisMonth'), custom: t('custom'), from: t('from'), to: t('to'), apply: t('apply') }} />
    {error && <div className="card card-body"><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={load}>{t('tryAgain')}</button></div>}
    {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : report && <>
      <section className="card" style={{ marginBottom: 16 }}>
        <div className="card-header"><h2>Profit & loss summary</h2><span className="muted" style={{ fontSize: 10 }}>{report.start_date} → {report.end_date}</span></div>
        <div className="card-body">
          <div className="report-summary">
            <div className="report-block"><span>Revenue (net sales)</span><strong>{money(report.revenue)}</strong></div>
            <div className="report-block"><span>Cost of goods sold</span><strong>− {money(report.cogs)}</strong></div>
            <div className="report-block"><span>Gross profit</span><strong className="text-success">{money(report.gross_profit)}</strong></div>
            <div className="report-block"><span>Operating expenses</span><strong>− {money(report.expenses)}</strong></div>
            <div className="report-block" style={{ background: 'var(--green-50)', borderColor: '#cfeee0' }}><span>Net profit</span><strong className="text-success">{money(report.net_profit)}</strong></div>
            <div className="report-block"><span>Cash collected</span><strong>{money(report.cash_collected)}</strong></div>
            <div className="report-block"><span>Credit sales</span><strong>{money(report.credit_sales)}</strong></div>
            <div className="report-block"><span>Outstanding debt</span><strong style={{ color: report.outstanding_debt > 0 ? 'var(--amber)' : undefined }}>{money(report.outstanding_debt)}</strong></div>
          </div>
          <p className="field-help" style={{ marginTop: 14 }}>Gross profit = revenue − COGS. Net profit = gross profit − operating expenses. Cash collected includes repayments received in this period and is not the same as revenue. Inventory valuation is a separate balance figure.</p>
        </div>
      </section>
      <div className="section-grid">
        <section className="card span-8">
          <div className="card-header"><h2>Sales & expense trend</h2><span className="muted" style={{ fontSize: 10 }}>{number(report.trends.length, language)} days</span></div>
          <div className="card-body"><TrendChart data={report.trends.map((point) => ({ ...point, expenses: point.expenses, net_profit: point.net_profit }))} currencyFormatter={money} /></div>
        </section>
        <section className="card span-4">
          <div className="card-header"><h2>Expenses by category</h2></div>
          <div className="card-body"><MiniBarChart data={report.expenses_by_category.map((row) => ({ label: row.category, value: Number(row.amount) }))} /><div style={{ borderTop: '1px solid var(--line-soft)', marginTop: 14, paddingTop: 12, display: 'flex', justifyContent: 'space-between', fontSize: 12 }}><span className="muted">Inventory valuation</span><strong>{money(report.inventory_valuation)}</strong></div></div>
        </section>
        <section className="card span-12">
          <div className="card-header"><h2>Product performance</h2><span className="muted" style={{ fontSize: 10 }}>Net of discounts, by revenue</span></div>
          {report.product_performance.length === 0 ? <div className="card-body muted" style={{ fontSize: 12 }}>No completed sales in this period.</div> :
            <div className="table-wrap"><table className="data-table"><thead><tr><th>Product</th><th className="numeric">Qty sold</th><th className="numeric">Net revenue</th><th className="numeric">COGS</th><th className="numeric">Gross profit</th><th className="numeric">Margin</th></tr></thead><tbody>
              {report.product_performance.map((row) => <tr key={row.product_id ?? row.product_name}><td className="cell-primary">{row.product_name}<span className="cell-secondary">{row.product_sku || '—'}</span></td><td className="numeric">{number(row.quantity_sold, language, 3)}</td><td className="numeric">{money(row.net_revenue)}</td><td className="numeric">{money(row.cogs)}</td><td className="numeric text-success"><strong>{money(row.gross_profit)}</strong></td><td className="numeric">{row.net_revenue > 0 ? `${((Number(row.gross_profit) / Number(row.net_revenue)) * 100).toFixed(1)}%` : '—'}</td></tr>)}
            </tbody></table></div>}
        </section>
      </div>
    </>}
  </>;
}
