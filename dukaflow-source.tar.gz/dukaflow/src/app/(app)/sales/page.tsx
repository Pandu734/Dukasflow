'use client';
import Link from 'next/link';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Eye, ReceiptText, Search } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { EmptyState, StatusBadge } from '@/components/ui';
import { currency, errorMessage, localDate, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Sale } from '@/types';

export default function SalesPage() {
  const { business, language, t } = useApp();
  const [sales, setSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const { data, error: queryError } = await createClient().from('sales').select('*,customers!sales_customer_id_fkey(name,phone)').eq('business_id', business.id).order('sold_at', { ascending: false }).limit(300);
    if (queryError) setError(errorMessage(queryError)); else setSales((data ?? []) as Sale[]);
    setLoading(false);
  }, [business.id]);
  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => sales.filter((sale) => {
    if (status === 'completed' && sale.status !== 'completed') return false;
    if (status === 'reversed' && sale.status !== 'reversed') return false;
    if (status === 'credit' && !(sale.status === 'completed' && sale.amount_paid < sale.total)) return false;
    if (status === 'paid' && !(sale.status === 'completed' && sale.amount_paid >= sale.total)) return false;
    const needle = search.trim().toLowerCase();
    return !needle || sale.sale_number.toLowerCase().includes(needle) || (sale.customers?.name ?? '').toLowerCase().includes(needle);
  }), [sales, search, status]);
  const total = filtered.filter((sale) => sale.status === 'completed').reduce((sum, sale) => sum + Number(sale.total), 0);

  return <>
    <PageHeader title={t('sales')} description="Completed, credit and reversed sales with full receipts." actions={<Link href="/sales/new" className="button button-primary">New sale</Link>} />
    <div className="toolbar">
      <div className="search-field"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search sale number or customer" aria-label="Search sales" /></div>
      <select className="select-control" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter sales by status"><option value="all">All sales</option><option value="completed">Completed</option><option value="paid">Fully paid</option><option value="credit">Credit balance</option><option value="reversed">Reversed</option></select>
      <div className="toolbar-spacer" />
      <span className="muted" style={{ fontSize: 11 }}>{number(filtered.length, language)} sales · {currency(total, business.currency_code, language)}</span>
    </div>
    <section className="card">
      {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : error ? <div className="card-body"><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={load}>{t('tryAgain')}</button></div>
        : filtered.length === 0 ? <EmptyState icon={<ReceiptText size={22} />} title="No sales found" description="Complete your first sale to see it here with a printable receipt." action={<Link href="/sales/new" className="button button-primary button-sm">New sale</Link>} />
          : <div className="table-wrap"><table className="data-table"><thead><tr><th>Sale</th><th>{t('date')}</th><th>Customer</th><th className="numeric">{t('amount')}</th><th className="numeric">Paid</th><th>Payment</th><th>{t('status')}</th><th /></tr></thead><tbody>
            {filtered.map((sale) => <tr key={sale.id}>
              <td className="cell-primary">{sale.sale_number}</td>
              <td>{localDate(sale.sold_at, language, true)}</td>
              <td>{sale.customers?.name ?? 'Walk-in customer'}</td>
              <td className="numeric cell-primary">{currency(sale.total, business.currency_code, language)}</td>
              <td className="numeric">{currency(sale.amount_paid, business.currency_code, language)}</td>
              <td><StatusBadge status={sale.payment_status} /></td>
              <td><StatusBadge status={sale.status} /></td>
              <td><div className="row-actions"><Link href={`/sales/${sale.id}`} className="row-action" aria-label={`View ${sale.sale_number}`}><Eye size={14} /></Link></div></td>
            </tr>)}
          </tbody></table></div>}
    </section>
  </>;
}
