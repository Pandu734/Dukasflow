'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Minus, Plus, Search, ShoppingCart, Trash2 } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { EmptyState } from '@/components/ui';
import { currency, errorMessage, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Customer, Product } from '@/types';

type CartLine = { product: Product; quantity: number; unit_price: number };

export default function NewSalePage() {
  const { business, language, t, notify } = useApp();
  const router = useRouter();
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [customerId, setCustomerId] = useState('');
  const [discount, setDiscount] = useState('0');
  const [paid, setPaid] = useState('');
  const [method, setMethod] = useState('cash');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const client = createClient();
    const [productResult, customerResult] = await Promise.all([
      client.from('products').select('*,categories!products_category_id_fkey(name)').eq('business_id', business.id).is('archived_at', null).order('name'),
      client.from('customers').select('*').eq('business_id', business.id).is('archived_at', null).order('name'),
    ]);
    if (productResult.error) setError(errorMessage(productResult.error));
    setProducts((productResult.data ?? []) as Product[]);
    setCustomers((customerResult.data ?? []) as Customer[]);
    setLoading(false);
  }, [business.id]);
  useEffect(() => { void load(); }, [load]);

  const visible = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return products.filter((product) => !needle || product.name.toLowerCase().includes(needle) || (product.sku ?? '').toLowerCase().includes(needle));
  }, [products, search]);

  const subtotal = cart.reduce((sum, line) => sum + line.quantity * line.unit_price, 0);
  const discountValue = Math.min(Math.max(Number(discount) || 0, 0), subtotal);
  const total = subtotal - discountValue;
  const paidValue = paid === '' ? total : Math.max(0, Number(paid) || 0);
  const outstanding = Math.max(0, total - paidValue);
  const money = (value: number) => currency(value, business.currency_code, language);

  function addToCart(product: Product) {
    setError('');
    setCart((lines) => {
      const existing = lines.find((line) => line.product.id === product.id);
      if (existing) {
        const nextQuantity = existing.quantity + 1;
        if (!business.allow_negative_stock && nextQuantity > product.quantity_stock) { setError(`Only ${number(product.quantity_stock, language, 3)} units of ${product.name} available.`); return lines; }
        return lines.map((line) => line.product.id === product.id ? { ...line, quantity: nextQuantity } : line);
      }
      if (!business.allow_negative_stock && product.quantity_stock < 1) { setError(`${product.name} is out of stock.`); return lines; }
      return [...lines, { product, quantity: 1, unit_price: product.selling_price }];
    });
  }
  function updateQuantity(productId: string, quantity: number) {
    setCart((lines) => lines.map((line) => {
      if (line.product.id !== productId) return line;
      const next = Math.max(0, quantity);
      if (!business.allow_negative_stock && next > line.product.quantity_stock) { setError(`Only ${number(line.product.quantity_stock, language, 3)} available.`); return line; }
      return { ...line, quantity: next };
    }).filter((line) => line.quantity > 0));
  }

  async function checkout() {
    setError('');
    if (cart.length === 0) { setError('Add at least one product to the sale.'); return; }
    if (outstanding > 0 && !customerId) { setError('Credit sales require a customer. Select or add a customer below.'); return; }
    if (paidValue > total) { setError('Amount received cannot be more than the total.'); return; }
    setBusy(true);
    try {
      const client = createClient();
      const idempotencyKey = crypto.randomUUID();
      const { data, error: rpcError } = await client.rpc('create_sale', {
        p_business_id: business.id, p_customer_id: customerId || null,
        p_items: cart.map((line) => ({ product_id: line.product.id, quantity: line.quantity, unit_price: line.unit_price })),
        p_discount: discountValue, p_amount_paid: paidValue, p_payment_method: method,
        p_sold_at: new Date().toISOString(), p_note: note.trim() || null, p_idempotency_key: idempotencyKey,
      });
      if (rpcError) throw rpcError;
      notify('Sale completed. Stock and profit updated.');
      router.push(`/sales/${data}?created=1`);
    } catch (err) { setError(errorMessage(err)); setBusy(false); }
  }

  return <>
    <PageHeader title={t('newSale')} description="Prices, stock and totals are validated by the database." actions={<button className="button button-ghost" onClick={() => router.push('/sales')}>Back to sales</button>} />
    {error && <div className="form-error" role="alert" style={{ marginBottom: 14 }}>{error}</div>}
    <div className="sale-layout">
      <section className="card product-picker">
        <div className="search-field" style={{ maxWidth: 'none' }}><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products by name or SKU" aria-label="Search products" autoFocus /></div>
        {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : visible.length === 0 ? <EmptyState icon={<ShoppingCart size={22} />} title="No products available" description="Add products to your catalogue before selling." action={<button className="button button-primary button-sm" onClick={() => router.push('/products')}>Go to products</button>} />
          : <div className="product-grid">{visible.map((product) => <button key={product.id} className="product-tile" onClick={() => addToCart(product)} disabled={!business.allow_negative_stock && product.quantity_stock <= 0}>
            <strong>{product.name}</strong><small>{product.categories?.name ?? 'Uncategorised'}</small><b>{money(product.selling_price)}</b><span>{business.allow_negative_stock ? `${number(product.quantity_stock, language, 3)} in stock` : product.quantity_stock > 0 ? `${number(product.quantity_stock, language, 3)} in stock` : 'Out of stock'}</span>
          </button>)}</div>}
      </section>

      <aside className="card cart-panel">
        <div className="card-header"><h2>Current sale</h2><span className="muted" style={{ fontSize: 11 }}>{cart.length} line{cart.length === 1 ? '' : 's'}</span></div>
        <div className="card-body">
          {cart.length === 0 ? <EmptyState icon={<ShoppingCart size={20} />} title="Cart is empty" description="Tap a product to add it to this sale." /> : <div className="cart-list">{cart.map((line) => <div className="cart-item" key={line.product.id}>
            <div className="cart-item-top"><strong>{line.product.name}</strong><strong>{money(line.quantity * line.unit_price)}</strong></div>
            <div className="cart-item-controls">
              <div className="quantity-control"><button type="button" onClick={() => updateQuantity(line.product.id, line.quantity - 1)} aria-label="Decrease quantity"><Minus size={13} /></button><input type="number" min="0" step="0.001" value={line.quantity} onChange={(e) => updateQuantity(line.product.id, Number(e.target.value))} aria-label={`Quantity of ${line.product.name}`} /><button type="button" onClick={() => updateQuantity(line.product.id, line.quantity + 1)} aria-label="Increase quantity"><Plus size={13} /></button></div>
              <div className="mini-field"><label htmlFor={`price-${line.product.id}`}>Unit price</label><input id={`price-${line.product.id}`} type="number" min="0" step="0.01" value={line.unit_price} onChange={(e) => setCart((lines) => lines.map((item) => item.product.id === line.product.id ? { ...item, unit_price: Number(e.target.value) || 0 } : item))} /></div>
              <button type="button" className="cart-remove" onClick={() => updateQuantity(line.product.id, 0)} aria-label={`Remove ${line.product.name}`}><Trash2 size={14} /></button>
            </div>
            {line.unit_price !== line.product.selling_price && <span className="field-help" style={{ color: 'var(--amber)' }}>Price changed from {money(line.product.selling_price)} — permissions apply.</span>}
          </div>)}</div>}

          <div className="totals">
            <div className="total-row"><span>Subtotal</span><strong>{money(subtotal)}</strong></div>
            <div className="total-row"><span>Discount</span><input className="input" style={{ width: 110, height: 30, textAlign: 'right', fontSize: 11 }} type="number" min="0" step="0.01" value={discount} onChange={(e) => setDiscount(e.target.value)} aria-label="Discount" /></div>
            <div className="total-row grand"><span>Total</span><strong>{money(total)}</strong></div>
          </div>

          <div className="form-stack" style={{ gap: 12 }}>
            <div className="field"><label htmlFor="customer">Customer {outstanding > 0 ? '(required for credit)' : '(optional)'}</label><select id="customer" value={customerId} onChange={(e) => setCustomerId(e.target.value)}><option value="">Walk-in customer</option>{customers.map((customer) => <option key={customer.id} value={customer.id}>{customer.name}{customer.phone ? ` · ${customer.phone}` : ''}</option>)}</select></div>
            <div className="field"><label htmlFor="method">Payment method</label><select id="method" value={method} onChange={(e) => setMethod(e.target.value)}><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="bank_transfer">Bank transfer</option><option value="other">Other</option></select></div>
            <div className="field"><label htmlFor="paid">Amount received</label><input id="paid" type="number" min="0" step="0.01" placeholder={total.toFixed(2)} value={paid} onChange={(e) => setPaid(e.target.value)} /><span className="field-help">{outstanding > 0 ? `${money(outstanding)} will be recorded as customer debt.` : 'Leave blank to record the sale as fully paid.'}</span></div>
            <div className="field"><label htmlFor="note">Note (optional)</label><input id="note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. delivery reference" /></div>
            <button className="button button-primary button-lg" onClick={checkout} disabled={busy || cart.length === 0}>{busy ? 'Processing sale…' : `Complete sale · ${money(total)}`}</button>
          </div>
        </div>
      </aside>
    </div>
  </>;
}
