'use client';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, Printer, RotateCcw } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { Modal, StatusBadge } from '@/components/ui';
import { currency, errorMessage, localDate, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Sale } from '@/types';

type SaleItem = { id: string; product_name: string; product_sku: string | null; quantity: number; unit_price: number; unit_cost: number; line_subtotal: number };

export default function SaleDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { business, language, t, notify } = useApp();
  const [sale, setSale] = useState<Sale | null>(null);
  const [items, setItems] = useState<SaleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [reverseOpen, setReverseOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [payment, setPayment] = useState({ amount: '', method: 'cash', note: '' });
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const client = createClient();
    const { data, error: saleError } = await client.from('sales').select('*,customers!sales_customer_id_fkey(name,phone)').eq('business_id', business.id).eq('id', params.id).maybeSingle();
    if (saleError || !data) { setError(saleError ? errorMessage(saleError) : 'Sale not found.'); setLoading(false); return; }
    const { data: itemData, error: itemError } = await client.from('sale_items').select('*').eq('sale_id', params.id).eq('business_id', business.id);
    if (itemError) setError(errorMessage(itemError));
    setSale(data as Sale); setItems((itemData ?? []) as SaleItem[]); setLoading(false);
  }, [business.id, params.id]);
  useEffect(() => { void load(); }, [load]);

  const money = (value: number) => currency(value, business.currency_code, language);
  const outstanding = sale ? Math.max(0, Number(sale.total) - Number(sale.amount_paid)) : 0;

  async function reverse() {
    setFormError('');
    if (reason.trim().length < 3) { setFormError('Give a short reason for reversing this sale.'); return; }
    setBusy(true);
    try {
      const { error: rpcError } = await createClient().rpc('reverse_sale', { p_business_id: business.id, p_sale_id: params.id, p_reason: reason.trim() });
      if (rpcError) throw rpcError;
      notify('Sale reversed. Stock has been restored.'); setReverseOpen(false); setReason(''); await load();
    } catch (err) { setFormError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function recordPayment() {
    setFormError('');
    const amount = Number(payment.amount);
    if (!Number.isFinite(amount) || amount <= 0) { setFormError('Enter a payment amount greater than zero.'); return; }
    if (amount > outstanding) { setFormError(`Payment cannot exceed the outstanding balance of ${money(outstanding)}.`); return; }
    setBusy(true);
    try {
      const { error: rpcError } = await createClient().rpc('record_debt_payment', {
        p_business_id: business.id, p_sale_id: params.id, p_amount: amount, p_payment_method: payment.method, p_paid_at: new Date().toISOString(), p_note: payment.note.trim() || null,
      });
      if (rpcError) throw rpcError;
      notify('Repayment recorded.'); setPayOpen(false); setPayment({ amount: '', method: 'cash', note: '' }); await load();
    } catch (err) { setFormError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  if (loading) return <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div>;
  if (error || !sale) return <div className="card card-body"><div className="form-error">{error || 'Sale not found.'}</div><Link href="/sales" className="button button-ghost button-sm" style={{ marginTop: 12 }}>Back to sales</Link></div>;

  return <>
    <PageHeader title={sale.sale_number} description={`${localDate(sale.sold_at, language, true)} · ${sale.customers?.name ?? 'Walk-in customer'}`} actions={<>
      <Link href="/sales" className="button button-ghost"><ArrowLeft size={15} /> Back</Link>
      <button className="button button-ghost" onClick={() => window.print()}><Printer size={15} /> Print</button>
      {sale.status === 'completed' && sale.amount_paid < sale.total && <button className="button button-primary" onClick={() => { setFormError(''); setPayment({ amount: String(outstanding), method: 'cash', note: '' }); setPayOpen(true); }}>Record repayment</button>}
      {sale.status === 'completed' && <button className="button button-danger-soft" onClick={() => { setFormError(''); setReverseOpen(true); }}><RotateCcw size={15} /> Reverse</button>}
    </>} />
    {sale.status === 'reversed' && <div className="form-error" style={{ marginBottom: 14 }}>This sale was reversed{sale.reversal_reason ? `: ${sale.reversal_reason}` : ''}. Stock was restored and it is excluded from revenue and profit.</div>}
    <div className="section-grid">
      <section className="card span-8">
        <div className="card-header"><h2>Receipt · {business.name}</h2><StatusBadge status={sale.status} /></div>
        <div className="card-body">
          <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12, marginBottom: 16 }}>
            <div><span className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: 1 }}>Customer</span><strong style={{ display: 'block', color: 'var(--navy-900)' }}>{sale.customers?.name ?? 'Walk-in customer'}</strong>{sale.customers?.phone && <span className="muted" style={{ fontSize: 11 }}>{sale.customers.phone}</span>}</div>
            <div style={{ textAlign: 'right' }}><span className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: 1 }}>Payment</span><strong style={{ display: 'block', color: 'var(--navy-900)' }}><StatusBadge status={sale.payment_status} /> {sale.payment_method.replaceAll('_', ' ')}</strong></div>
          </div>
          <div className="table-wrap"><table className="data-table" style={{ minWidth: 420 }}><thead><tr><th>Item</th><th className="numeric">Qty</th><th className="numeric">Unit price</th><th className="numeric">Line total</th></tr></thead><tbody>
            {items.map((item) => <tr key={item.id}><td className="cell-primary">{item.product_name}<span className="cell-secondary">{item.product_sku ?? ''}</span></td><td className="numeric">{number(item.quantity, language, 3)}</td><td className="numeric">{money(item.unit_price)}</td><td className="numeric cell-primary">{money(item.line_subtotal)}</td></tr>)}
          </tbody></table></div>
          <div className="totals" style={{ maxWidth: 320, marginLeft: 'auto' }}>
            <div className="total-row"><span>Subtotal</span><strong>{money(sale.subtotal)}</strong></div>
            <div className="total-row"><span>Discount</span><strong>− {money(sale.discount)}</strong></div>
            <div className="total-row grand"><span>Total</span><strong>{money(sale.total)}</strong></div>
            <div className="total-row"><span>Paid</span><strong>{money(sale.amount_paid)}</strong></div>
            {outstanding > 0 && sale.status === 'completed' && <div className="total-row" style={{ color: 'var(--amber)' }}><span>Balance due</span><strong style={{ color: 'var(--amber)' }}>{money(outstanding)}</strong></div>}
          </div>
          {sale.note && <p className="muted" style={{ fontSize: 11, marginTop: 12 }}>Note: {sale.note}</p>}
        </div>
      </section>
      <aside className="card span-4">
        <div className="card-header"><h2>Financial position</h2></div>
        <div className="card-body" style={{ display: 'grid', gap: 12 }}>
          <Line label="Revenue (this sale)" value={money(Number(sale.total))} />
          <Line label="Cost of goods sold" value={money(Number(sale.cost_total))} />
          <Line label="Gross profit" value={money(Number(sale.total) - Number(sale.cost_total))} strong />
          <Line label="Cash received" value={money(Number(sale.amount_paid))} />
          <Line label="Credit outstanding" value={money(outstanding)} tone={outstanding > 0 ? 'var(--amber)' : undefined} />
          <p className="field-help">Gross profit uses the cost captured at the time of sale. Service fee and expenses are reported separately.</p>
        </div>
      </aside>
    </div>

    <Modal open={reverseOpen} title="Reverse this sale" onClose={() => setReverseOpen(false)} size="sm">
      {formError && <div className="form-error" style={{ marginBottom: 12 }}>{formError}</div>}
      <p className="muted" style={{ fontSize: 12, marginBottom: 14 }}>Reversal restores stock for every item and excludes the sale from revenue, COGS and profit. The record and reason stay in the audit history. A sale with recorded repayments cannot be reversed.</p>
      <div className="field"><label htmlFor="reason">Reason</label><input id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Customer returned goods" /></div>
      <div className="form-actions"><button className="button button-ghost" onClick={() => setReverseOpen(false)}>{t('cancel')}</button><button className="button button-danger" disabled={busy} onClick={reverse}>{busy ? 'Reversing…' : 'Reverse sale'}</button></div>
    </Modal>

    <Modal open={payOpen} title="Record repayment" onClose={() => setPayOpen(false)} size="sm">
      {formError && <div className="form-error" style={{ marginBottom: 12 }}>{formError}</div>}
      <div className="form-stack">
        <div className="field"><label>Outstanding balance</label><div className="input" style={{ background: '#f6f8fa', fontWeight: 800 }}>{money(outstanding)}</div></div>
        <div className="field"><label htmlFor="pay-amount">Amount received</label><input id="pay-amount" type="number" min="0" step="0.01" value={payment.amount} onChange={(e) => setPayment({ ...payment, amount: e.target.value })} /></div>
        <div className="field"><label htmlFor="pay-method">Payment method</label><select id="pay-method" value={payment.method} onChange={(e) => setPayment({ ...payment, method: e.target.value })}><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="bank_transfer">Bank transfer</option><option value="other">Other</option></select></div>
        <div className="field"><label htmlFor="pay-note">Note (optional)</label><input id="pay-note" value={payment.note} onChange={(e) => setPayment({ ...payment, note: e.target.value })} /></div>
      </div>
      <div className="form-actions"><button className="button button-ghost" onClick={() => setPayOpen(false)}>{t('cancel')}</button><button className="button button-primary" disabled={busy} onClick={recordPayment}>{busy ? 'Saving…' : 'Record payment'}</button></div>
    </Modal>
  </>;
}

function Line({ label, value, strong, tone }: { label: string; value: string; strong?: boolean; tone?: string }) {
  return <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, paddingBottom: 9, borderBottom: '1px solid var(--line-soft)' }}><span className="muted">{label}</span><strong style={{ color: tone ?? (strong ? 'var(--green-700)' : 'var(--navy-900)') }}>{value}</strong></div>;
}
