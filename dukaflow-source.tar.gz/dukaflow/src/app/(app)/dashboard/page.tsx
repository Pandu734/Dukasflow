'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { AlertTriangle, Boxes, CreditCard, Package, ReceiptText, TrendingUp, Wallet } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { MetricCard, PageHeader, TrendChart, type TrendPoint } from '@/components/data-display';
import { DateRangeFilter, defaultRange, type DateRange } from '@/components/date-range-filter';
import { currency, errorMessage, localDate, number } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';

type Metrics = {
  today_sales: number; month_sales: number; period_sales: number; cash_collected: number; credit_sales: number;
  expenses: number; cogs: number; gross_profit: number; net_profit: number; total_products: number;
  low_stock_products: number; outstanding_debt: number;
  recent_sales: { id: string; sale_number: string; sold_at: string; total: number; payment_status: string; status: string; customer_name: string | null }[];
  series: TrendPoint[];
};

export default function DashboardPage() {
  const { business, user, language, t } = useApp();
  const [range, setRange] = useState<DateRange>(() => defaultRange('month'));
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    setLoading(true); setError('');
    createClient().rpc('get_dashboard_metrics', { p_business_id: business.id, p_start: range.start, p_end: range.end })
      .then((result: { data: unknown; error: { message: string } | null }) => {
        const { data, error: rpcError } = result;
        if (!active) return;
        if (rpcError) setError(errorMessage(rpcError)); else setMetrics(data as Metrics);
        setLoading(false);
      });
    return () => { active = false; };
  }, [business.id, range.start, range.end]);

  const money = (value: number | null | undefined) => currency(value, business.currency_code, language);
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return <>
    <PageHeader title={`${greeting}${user.full_name ? `, ${user.full_name.split(' ')[0]}` : ''}`} description={`${business.name} · ${t('welcomeBack')}`} />
    <DateRangeFilter value={range} onChange={setRange} labels={{ today: t('today'), last7: t('last7'), thisMonth: t('thisMonth'), custom: t('custom'), from: t('from'), to: t('to'), apply: t('apply') }} />
    {error && <div className="card card-body" style={{ marginBottom: 16 }}><div className="form-error">{error}</div><button className="button button-ghost button-sm" style={{ marginTop: 10 }} onClick={() => setRange({ ...range })}>{t('tryAgain')}</button></div>}
    {loading ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : metrics && <>
      <div className="metric-grid">
        <MetricCard label={t('todaySales')} value={money(metrics.today_sales)} sub={localDate(new Date(), language)} icon={<ReceiptText size={16} />} />
        <MetricCard label={t('monthlySales')} value={money(metrics.month_sales)} sub={`${t('revenue')} · ${number(metrics.series.length, language)} days`} icon={<TrendingUp size={16} />} tone="navy" />
        <MetricCard label={t('grossProfit')} value={money(metrics.gross_profit)} sub={`${t('revenue')} ${money(metrics.period_sales)}`} icon={<Wallet size={16} />} />
        <MetricCard label={t('netProfit')} value={money(metrics.net_profit)} sub={`${t('totalExpenses')} ${money(metrics.expenses)}`} icon={<Wallet size={16} />} tone="green" />
      </div>
      <div className="metric-grid">
        <MetricCard label={t('cashCollected')} value={money(metrics.cash_collected)} sub={`${t('creditSales')} ${money(metrics.credit_sales)}`} icon={<CreditCard size={16} />} tone="navy" />
        <MetricCard label={t('outstandingDebts')} value={money(metrics.outstanding_debt)} sub={metrics.outstanding_debt > 0 ? 'View customer balances' : 'All settled'} icon={<AlertTriangle size={16} />} tone={metrics.outstanding_debt > 0 ? 'amber' : 'green'} />
        <MetricCard label={t('totalProducts')} value={number(metrics.total_products, language)} sub={`${t('lowStock')} ${number(metrics.low_stock_products, language)}`} icon={<Package size={16} />} tone="navy" />
        <MetricCard label={t('cogs')} value={money(metrics.cogs)} sub={`${t('revenue')} ${money(metrics.period_sales)}`} icon={<Boxes size={16} />} />
      </div>
      <div className="section-grid">
        <section className="card span-8">
          <div className="card-header"><h2>{t('salesProfitTrend')}</h2><span className="muted" style={{ fontSize: 10 }}>{range.start} → {range.end}</span></div>
          <div className="card-body"><TrendChart data={metrics.series} currencyFormatter={money} /></div>
        </section>
        <section className="card span-4">
          <div className="card-header"><h2>{t('recentSales')}</h2><Link href="/sales" className="text-link" style={{ fontSize: 11 }}>{t('viewAll')}</Link></div>
          <div className="card-body" style={{ paddingTop: 5 }}>
            {metrics.recent_sales.length === 0 && <p className="muted" style={{ fontSize: 12, padding: '20px 0' }}>{t('noData')}</p>}
            <div className="recent-list">{metrics.recent_sales.map((sale) => <Link href={`/sales/${sale.id}`} key={sale.id} className="recent-item"><span className="recent-icon"><ReceiptText size={15} /></span><div><strong>{sale.customer_name || sale.sale_number}</strong><span>{localDate(sale.sold_at, language, true)} · {sale.payment_status.replaceAll('_', ' ')}</span></div><div className="recent-amount"><strong>{money(sale.total)}</strong><span>{sale.status === 'reversed' ? 'reversed' : ''}</span></div></Link>)}</div>
            {metrics.recent_sales.length > 0 && <Link href="/sales/new" className="button button-soft button-sm" style={{ width: '100%', marginTop: 14 }}>{t('newSale')}</Link>}
          </div>
        </section>
      </div>
    </>}
  </>;
}
