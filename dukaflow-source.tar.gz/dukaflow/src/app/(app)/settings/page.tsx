'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Plus } from 'lucide-react';
import { useApp } from '@/components/app-provider';
import { PageHeader } from '@/components/data-display';
import { Modal } from '@/components/ui';
import { errorMessage } from '@/lib/format';
import { createClient } from '@/lib/supabase/client';
import type { Category } from '@/types';
type Subscription = { id: string; business_id: string; plan_code: string; status: string; created_at: string };

const tabs = ['Business', 'Categories', 'Preferences', 'Plan & team'] as const;
const currencies = ['TZS', 'KES', 'UGX', 'USD', 'EUR', 'GBP', 'ZAR', 'NGN'];

export default function SettingsPage() {
  const { business, businesses, language, t, notify, setLanguage, user } = useApp();
  const router = useRouter();
  const [tab, setTab] = useState<(typeof tabs)[number]>('Business');
  const [categories, setCategories] = useState<Category[]>([]);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [members, setMembers] = useState<{ id: string; role: string; status: string; user_id: string }[]>([]);
  const [loadingCats, setLoadingCats] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [bizOpen, setBizOpen] = useState(false);
  const [newBusiness, setNewBusiness] = useState({ name: '', business_type: 'Retail shop', currency_code: 'TZS', country_code: 'TZ' });
  const [form, setForm] = useState({
    name: business.name, business_type: business.business_type, currency_code: business.currency_code,
    phone: business.phone ?? '', address: business.address ?? '', preferred_language: business.preferred_language,
    allow_negative_stock: business.allow_negative_stock,
  });

  const load = useCallback(async () => {
    setLoadingCats(true); setError('');
    const client = createClient();
    const [catResult, subResult, memberResult] = await Promise.all([
      client.from('categories').select('id,business_id,name,archived_at').eq('business_id', business.id).order('name'),
      client.from('subscriptions').select('id,business_id,plan_code,status,created_at').eq('business_id', business.id).maybeSingle(),
      client.from('business_members').select('id,user_id,role,status').eq('business_id', business.id).order('created_at'),
    ]);
    if (catResult.error) setError(errorMessage(catResult.error));
    setCategories((catResult.data ?? []) as Category[]);
    setSubscription((subResult.data ?? null) as Subscription | null);
    setMembers((memberResult.data ?? []) as { id: string; role: string; status: string; user_id: string }[]);
    setLoadingCats(false);
  }, [business.id]);
  useEffect(() => { void load(); }, [load]);

  const archivedCount = useMemo(() => categories.filter((category) => category.archived_at).length, [categories]);

  async function saveBusiness(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      if (!['owner', 'admin'].includes(business.role)) throw new Error('Only owners and admins can update business settings.');
      if (form.name.trim().length < 2) throw new Error('Business name must be at least 2 characters.');
      const { error: updateError } = await createClient().from('businesses').update({
        name: form.name.trim(), business_type: form.business_type, currency_code: form.currency_code,
        phone: form.phone.trim() || null, address: form.address.trim() || null,
        preferred_language: form.preferred_language, allow_negative_stock: form.allow_negative_stock,
      }).eq('id', business.id);
      if (updateError) throw updateError;
      setLanguage(form.preferred_language);
      notify('Business settings saved.'); window.location.reload();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function addCategory(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    if (newCategory.trim().length < 2) { setError('Category name must be at least 2 characters.'); return; }
    setBusy(true);
    try {
      const { error: insertError } = await createClient().from('categories').insert({ business_id: business.id, name: newCategory.trim() });
      if (insertError) throw insertError;
      setNewCategory(''); setCatOpen(false); notify('Category added.'); await load();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function archiveCategory(category: Category) {
    setBusy(true);
    try {
      const { error: updateError } = await createClient().from('categories').update({ archived_at: new Date().toISOString() }).eq('id', category.id).eq('business_id', business.id);
      if (updateError) throw updateError;
      notify('Category archived.'); await load();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function switchBusiness(id: string) {
    setError(''); setBusy(true);
    try {
      const { error: updateError } = await createClient().from('profiles').update({ active_business_id: id }).eq('id', user.id);
      if (updateError) throw updateError;
      router.replace('/dashboard'); router.refresh();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function createBusiness(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    if (newBusiness.name.trim().length < 2) { setError('Business name must be at least 2 characters.'); return; }
    setBusy(true);
    try {
      const { data, error: rpcError } = await createClient().rpc('create_business', {
        p_name: newBusiness.name.trim(), p_business_type: newBusiness.business_type,
        p_country_code: newBusiness.country_code, p_currency_code: newBusiness.currency_code,
        p_phone: null, p_address: null, p_preferred_language: language, p_timezone: business.timezone,
      });
      if (rpcError) throw rpcError;
      const { error: preferenceError } = await createClient().from('profiles').update({ active_business_id: String(data) }).eq('id', user.id);
      if (preferenceError) throw preferenceError;
      setBizOpen(false); router.replace('/dashboard'); router.refresh();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  return <>
    <PageHeader title={t('settings')} description="Business details, catalogue structure, preferences and plan." />
    {error && <div className="form-error" style={{ marginBottom: 14 }}>{error}</div>}
    <div className="settings-layout">
      <nav className="card settings-nav no-print" aria-label="Settings sections">{tabs.map((item) => <button key={item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)}>{item}</button>)}</nav>
      <div>
        {tab === 'Business' && <section className="card settings-section">
          <h2>Business details</h2><p>These details appear on receipts and reports.</p>
          <form className="form-stack" onSubmit={saveBusiness}>
            <div className="form-row">
              <div className="field"><label htmlFor="b-name">Business name</label><input id="b-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="field"><label htmlFor="b-type">Business type</label><input id="b-type" value={form.business_type} onChange={(e) => setForm({ ...form, business_type: e.target.value })} /></div>
            </div>
            <div className="form-row">
              <div className="field"><label htmlFor="b-currency">Currency</label><select id="b-currency" value={form.currency_code} onChange={(e) => setForm({ ...form, currency_code: e.target.value })}>{currencies.map((code) => <option key={code}>{code}</option>)}</select></div>
              <div className="field"><label htmlFor="b-phone">Phone</label><input id="b-phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            </div>
            <div className="field"><label htmlFor="b-address">Address</label><input id="b-address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="form-actions"><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : t('save')}</button></div>
          </form>
        </section>}

        {tab === 'Categories' && <section className="card settings-section">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}><div><h2>Product categories</h2><p>Group products to filter your catalogue, sales and reports.</p></div><button className="button button-primary button-sm" onClick={() => { setNewCategory(''); setCatOpen(true); }}><Plus size={15} /> Add category</button></div>
          {loadingCats ? <div className="spinner-wrap"><span className="spinner" /> {t('loading')}</div> : <div className="table-wrap"><table className="data-table" style={{ minWidth: 420 }}><thead><tr><th>{t('name')}</th><th>{t('status')}</th><th /></tr></thead><tbody>
            {categories.map((category) => <tr key={category.id}><td className="cell-primary">{category.name}</td><td>{category.archived_at ? 'Archived' : 'Active'}</td><td><div className="row-actions">{!category.archived_at && <button className="button button-ghost button-sm" disabled={busy} onClick={() => archiveCategory(category)}>Archive</button>}</div></td></tr>)}
            {categories.length === 0 && <tr><td colSpan={3} className="muted">No categories yet.</td></tr>}
          </tbody></table></div>}
          {archivedCount > 0 && <p className="field-help" style={{ marginTop: 10 }}>{archivedCount} archived {archivedCount === 1 ? 'category' : 'categories'} hidden from new products.</p>}
        </section>}

        {tab === 'Preferences' && <section className="card settings-section">
          <h2>Preferences</h2><p>Language, formatting and stock behaviour for this business.</p>
          <form className="form-stack" onSubmit={saveBusiness}>
            <div className="field"><label htmlFor="p-language">{t('language')}</label><select id="p-language" value={form.preferred_language} onChange={(e) => setForm({ ...form, preferred_language: e.target.value as 'en' | 'sw' })}><option value="en">English</option><option value="sw">Kiswahili</option></select><span className="field-help">Used across the app and saved to your business.</span></div>
            <div className="toggle-row" style={{ borderTop: '1px solid var(--line-soft)' }}><div><strong>Allow negative stock</strong><span>If disabled, sales and adjustments cannot reduce stock below zero.</span></div><label className="switch"><input type="checkbox" checked={form.allow_negative_stock} onChange={(e) => setForm({ ...form, allow_negative_stock: e.target.checked })} aria-label="Allow negative stock" /><span className="switch-slider" /></label></div>
            <div className="toggle-row"><div><strong>Currency and timezone</strong><span>{form.currency_code} · Africa/Dar_es_Salaam. Dates and money use local formatting.</span></div></div>
            <div className="form-actions"><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : t('save')}</button></div>
          </form>
        </section>}

        {tab === 'Plan & team' && <>
          <section className="card settings-section" style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}><div><h2>Your businesses</h2><p>Each business is an isolated workspace with its own records, staff and currency.</p></div><button className="button button-primary button-sm" onClick={() => setBizOpen(true)}><Plus size={15} /> New business</button></div>
            <div style={{ display: 'grid', gap: 9 }}>
              {businesses.map((item) => <div key={item.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '12px 14px', border: '1px solid var(--line-soft)', borderRadius: 10 }}>
                <div><strong style={{ fontSize: 12, color: 'var(--navy-900)' }}>{item.name}</strong><span className="muted" style={{ display: 'block', fontSize: 10, textTransform: 'capitalize' }}>{item.role}{item.id === business.id ? ' · current' : ''}</span></div>
                {item.id === business.id
                  ? <span className="badge badge-active">active</span>
                  : <button type="button" className="button button-soft button-sm" disabled={busy} onClick={() => switchBusiness(item.id)}>Switch</button>}
              </div>)}
            </div>
          </section>
          <section className="card settings-section" style={{ marginBottom: 16 }}>
            <h2>Subscription</h2><p>Plans are defined in the data model. Billing is not active in this build.</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px', border: '1px solid var(--line-soft)', borderRadius: 11 }}>
              <div><strong style={{ textTransform: 'capitalize', color: 'var(--navy-900)' }}>{subscription?.plan_code ?? 'free'} plan</strong><span className="muted" style={{ display: 'block', fontSize: 11 }}>Status: {subscription?.status ?? 'active'} · No payment method connected</span></div>
              <span className="badge badge-active">current</span>
            </div>
            <div style={{ display: 'grid', gap: 8, marginTop: 14 }}>
              {['Free — 1 business, core records', 'Starter — staff memberships, more products', 'Business — advanced reporting', 'Enterprise — multi-location (planned)'].map((plan) => <div key={plan} className="muted" style={{ fontSize: 11, padding: '8px 12px', background: '#f7fafb', borderRadius: 8 }}>{plan}</div>)}
            </div>
          </section>
          <section className="card settings-section">
            <h2>Team members</h2><p>Owners and admins can add staff. Permissions are enforced by database policies.</p>
            <div className="table-wrap"><table className="data-table" style={{ minWidth: 420 }}><thead><tr><th>Member</th><th>Role</th><th>{t('status')}</th></tr></thead><tbody>
              {members.map((member) => <tr key={member.id}><td className="cell-primary">{member.user_id === user.id ? 'You' : 'Team member'}<span className="cell-secondary">ID {member.user_id.slice(0, 8)}…</span></td><td style={{ textTransform: 'capitalize' }}>{member.role}</td><td>{member.status}</td></tr>)}
            </tbody></table></div>
            <p className="field-help" style={{ marginTop: 10 }}>Staff invitations are not enabled yet. The membership table and role checks are ready for them.</p>
          </section>
        </>}
      </div>
    </div>
    <Modal open={bizOpen} title="Create another business" onClose={() => setBizOpen(false)} size="sm">
      <form className="form-stack" onSubmit={createBusiness}>
        <div className="field"><label htmlFor="nb-name">Business name</label><input id="nb-name" required value={newBusiness.name} onChange={(e) => setNewBusiness({ ...newBusiness, name: e.target.value })} /></div>
        <div className="field"><label htmlFor="nb-type">Business type</label><select id="nb-type" value={newBusiness.business_type} onChange={(e) => setNewBusiness({ ...newBusiness, business_type: e.target.value })}><option>Retail shop</option><option>Wholesale</option><option>Restaurant or food</option><option>Services</option><option>Pharmacy</option><option>Salon or barbershop</option><option>Other</option></select></div>
        <div className="form-row">
          <div className="field"><label htmlFor="nb-currency">Currency</label><select id="nb-currency" value={newBusiness.currency_code} onChange={(e) => setNewBusiness({ ...newBusiness, currency_code: e.target.value })}>{currencies.map((code) => <option key={code}>{code}</option>)}</select></div>
          <div className="field"><label htmlFor="nb-country">Country</label><input id="nb-country" maxLength={2} value={newBusiness.country_code} onChange={(e) => setNewBusiness({ ...newBusiness, country_code: e.target.value.toUpperCase() })} /></div>
        </div>
        <div className="form-actions"><button type="button" className="button button-ghost" onClick={() => setBizOpen(false)}>{t('cancel')}</button><button className="button button-primary" disabled={busy}>{busy ? 'Creating…' : 'Create business'}</button></div>
      </form>
    </Modal>
    <Modal open={catOpen} title="Add category" onClose={() => setCatOpen(false)} size="sm">
      <form className="form-stack" onSubmit={addCategory}>
        <div className="field"><label htmlFor="cat-name">Category name</label><input id="cat-name" required value={newCategory} onChange={(e) => setNewCategory(e.target.value)} placeholder="Beverages" /></div>
        <div className="form-actions"><button type="button" className="button button-ghost" onClick={() => setCatOpen(false)}>{t('cancel')}</button><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Add category'}</button></div>
      </form>
    </Modal>
  </>;
}
