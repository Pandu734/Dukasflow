import { redirect } from 'next/navigation';
import { AppProvider } from '@/components/app-provider';
import { MobileNav, Sidebar } from '@/components/navigation';
import { Topbar } from '@/components/topbar';
import { getSessionContext } from '@/lib/session';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await getSessionContext(true);
  if (!session.business) redirect('/onboarding');
  return <AppProvider business={session.business} businesses={session.businesses} user={{ id: session.userId, email: session.email, full_name: session.fullName, phone: session.phone }}>
    <div className="app-layout">
      <Sidebar />
      <main className="app-main"><Topbar /><div className="app-content">{children}</div></main>
      <MobileNav />
    </div>
  </AppProvider>;
}
