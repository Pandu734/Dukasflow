import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: { default: 'DukaFlow — Run Your Business Smarter', template: '%s · DukaFlow' },
  description: 'Sales, stock, expenses, customers, debts and profit in one simple business platform.',
  applicationName: 'DukaFlow',
  manifest: '/manifest.webmanifest',
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, maximumScale: 1, themeColor: '#0f2742' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
