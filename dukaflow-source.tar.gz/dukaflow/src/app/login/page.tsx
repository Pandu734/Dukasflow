'use client';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { FormEvent, Suspense, useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { AuthShell } from '@/components/auth-shell';
import { createClient } from '@/lib/supabase/client';
import { errorMessage } from '@/lib/format';

function LoginForm() {
  const router = useRouter(); const params = useSearchParams();
  const [show, setShow] = useState(false); const [busy,setBusy]=useState(false); const [error,setError]=useState('');
  async function submit(e: FormEvent<HTMLFormElement>) { e.preventDefault();setBusy(true);setError('');const form=new FormData(e.currentTarget);
    try { const { error }=await createClient().auth.signInWithPassword({email:String(form.get('email')).trim(),password:String(form.get('password'))});if(error)throw error;const next=params.get('next');router.replace(next?.startsWith('/')?next:'/dashboard');router.refresh(); } catch(err){setError(errorMessage(err));setBusy(false);} }
  return <AuthShell><h2>Welcome back</h2><p>Sign in to continue to your business.</p><form className="form-stack" onSubmit={submit}>{error&&<div className="form-error" role="alert">{error}</div>}<div className="field"><label htmlFor="email">Email address</label><input id="email" name="email" type="email" autoComplete="email" required placeholder="you@example.com"/></div><div className="field"><label htmlFor="password">Password</label><div className="password-field"><input id="password" name="password" type={show?'text':'password'} autoComplete="current-password" required placeholder="Your password"/><button type="button" onClick={()=>setShow(!show)} aria-label={show?'Hide password':'Show password'}>{show?<EyeOff size={17}/>:<Eye size={17}/>}</button></div></div><div className="form-meta"><span/><Link href="/forgot-password" className="text-link">Forgot password?</Link></div><button className="button button-primary button-lg" disabled={busy}>{busy?'Signing in…':'Sign in'}</button></form><p className="auth-footer">New to DukaFlow? <Link href="/register">Create an account</Link></p></AuthShell>;
}
export default function LoginPage(){return <Suspense><LoginForm/></Suspense>}
