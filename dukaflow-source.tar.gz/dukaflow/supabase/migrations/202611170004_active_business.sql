-- Applied to the live project as "dukaflow_active_business_preference".
-- Lets a user with several businesses remember which workspace is active.
alter table public.profiles add column if not exists active_business_id uuid references public.businesses(id) on delete set null;
create index if not exists profiles_active_business_idx on public.profiles(active_business_id);
grant update(active_business_id) on public.profiles to authenticated;

update public.profiles p
set active_business_id = (
  select bm.business_id from public.business_members bm
  where bm.user_id = p.id and bm.status = 'active'
  order by bm.created_at limit 1
)
where p.active_business_id is null;
