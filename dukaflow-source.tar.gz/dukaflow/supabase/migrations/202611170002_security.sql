-- DukaFlow tenant isolation, grants, and audit enforcement.

create or replace function public.is_business_member(p_business_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.business_members bm
    where bm.business_id = p_business_id
      and bm.user_id = auth.uid()
      and bm.status = 'active'
  );
$$;

create or replace function public.business_role(p_business_id uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select bm.role from public.business_members bm
  where bm.business_id = p_business_id
    and bm.user_id = auth.uid()
    and bm.status = 'active'
  limit 1;
$$;

create or replace function public.has_business_role(p_business_id uuid, p_roles text[])
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(public.business_role(p_business_id) = any(p_roles), false);
$$;

revoke all on function public.is_business_member(uuid) from public;
revoke all on function public.business_role(uuid) from public;
revoke all on function public.has_business_role(uuid, text[]) from public;
grant execute on function public.is_business_member(uuid) to authenticated;
grant execute on function public.business_role(uuid) to authenticated;
grant execute on function public.has_business_role(uuid, text[]) to authenticated;

alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.business_members enable row level security;
alter table public.subscription_plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.business_counters enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.expenses enable row level security;
alter table public.stock_movements enable row level security;
alter table public.debt_payments enable row level security;
alter table public.audit_logs enable row level security;

alter table public.profiles force row level security;
alter table public.businesses force row level security;
alter table public.business_members force row level security;
alter table public.subscriptions force row level security;
alter table public.categories force row level security;
alter table public.products force row level security;
alter table public.customers force row level security;
alter table public.business_counters force row level security;
alter table public.sales force row level security;
alter table public.sale_items force row level security;
alter table public.expenses force row level security;
alter table public.stock_movements force row level security;
alter table public.debt_payments force row level security;
alter table public.audit_logs force row level security;

create policy profiles_select_own on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_update_own on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy plans_read on public.subscription_plans for select to anon, authenticated using (is_active = true);

create policy businesses_read_member on public.businesses for select to authenticated using (public.is_business_member(id));
create policy businesses_update_admin on public.businesses for update to authenticated
  using (public.has_business_role(id, array['owner','admin']))
  with check (public.has_business_role(id, array['owner','admin']));

create policy members_read_member on public.business_members for select to authenticated using (public.is_business_member(business_id));
create policy members_insert_owner on public.business_members for insert to authenticated
  with check (public.has_business_role(business_id, array['owner']));
create policy members_update_owner on public.business_members for update to authenticated
  using (public.has_business_role(business_id, array['owner']))
  with check (public.has_business_role(business_id, array['owner']));
create policy members_delete_owner on public.business_members for delete to authenticated
  using (public.has_business_role(business_id, array['owner']) and user_id <> auth.uid());

create policy subscriptions_read_admin on public.subscriptions for select to authenticated
  using (public.has_business_role(business_id, array['owner','admin']));

create policy categories_read_member on public.categories for select to authenticated using (public.is_business_member(business_id));
create policy categories_insert_manager on public.categories for insert to authenticated
  with check (public.has_business_role(business_id, array['owner','admin','manager']));
create policy categories_update_manager on public.categories for update to authenticated
  using (public.has_business_role(business_id, array['owner','admin','manager']))
  with check (public.has_business_role(business_id, array['owner','admin','manager']));

create policy products_read_member on public.products for select to authenticated using (public.is_business_member(business_id));
create policy products_insert_manager on public.products for insert to authenticated
  with check (public.has_business_role(business_id, array['owner','admin','manager']) and created_by = auth.uid());
create policy products_update_manager on public.products for update to authenticated
  using (public.has_business_role(business_id, array['owner','admin','manager']))
  with check (public.has_business_role(business_id, array['owner','admin','manager']));

create policy customers_read_member on public.customers for select to authenticated using (public.is_business_member(business_id));
create policy customers_insert_staff on public.customers for insert to authenticated
  with check (public.has_business_role(business_id, array['owner','admin','manager','cashier','staff']) and created_by = auth.uid());
create policy customers_update_staff on public.customers for update to authenticated
  using (public.has_business_role(business_id, array['owner','admin','manager','cashier','staff']))
  with check (public.has_business_role(business_id, array['owner','admin','manager','cashier','staff']));

create policy sales_read_member on public.sales for select to authenticated using (public.is_business_member(business_id));
create policy sale_items_read_member on public.sale_items for select to authenticated using (public.is_business_member(business_id));

create policy expenses_read_member on public.expenses for select to authenticated using (public.is_business_member(business_id));
create policy expenses_insert_manager on public.expenses for insert to authenticated
  with check (public.has_business_role(business_id, array['owner','admin','manager']) and created_by = auth.uid());
create policy expenses_update_manager on public.expenses for update to authenticated
  using (public.has_business_role(business_id, array['owner','admin','manager']))
  with check (public.has_business_role(business_id, array['owner','admin','manager']));

create policy stock_movements_read_member on public.stock_movements for select to authenticated using (public.is_business_member(business_id));
create policy debt_payments_read_member on public.debt_payments for select to authenticated using (public.is_business_member(business_id));
create policy audit_logs_read_admin on public.audit_logs for select to authenticated
  using (public.has_business_role(business_id, array['owner','admin']));

-- Prevent moving rows across tenants, even for a user who belongs to both businesses.
create or replace function public.prevent_business_id_change()
returns trigger language plpgsql set search_path = '' as $$
begin
  if new.business_id is distinct from old.business_id then
    raise exception 'business_id cannot be changed';
  end if;
  return new;
end;
$$;

create or replace function public.prevent_business_owner_change()
returns trigger language plpgsql set search_path = '' as $$
begin
  if new.owner_id is distinct from old.owner_id then raise exception 'owner_id cannot be changed directly'; end if;
  return new;
end;
$$;
create trigger businesses_owner_immutable before update on public.businesses for each row execute function public.prevent_business_owner_change();

create trigger members_business_immutable before update on public.business_members for each row execute function public.prevent_business_id_change();
create trigger categories_business_immutable before update on public.categories for each row execute function public.prevent_business_id_change();
create trigger products_business_immutable before update on public.products for each row execute function public.prevent_business_id_change();
create trigger customers_business_immutable before update on public.customers for each row execute function public.prevent_business_id_change();
create trigger subscriptions_business_immutable before update on public.subscriptions for each row execute function public.prevent_business_id_change();
create trigger expenses_business_immutable before update on public.expenses for each row execute function public.prevent_business_id_change();

-- Append audit entries for user-editable master and expense data.
create or replace function public.audit_row_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_business_id uuid;
  v_entity_id text;
begin
  v_business_id := coalesce(new.business_id, old.business_id);
  v_entity_id := coalesce(new.id, old.id)::text;
  insert into public.audit_logs (business_id, user_id, action, entity_type, entity_id, before_data, after_data)
  values (
    v_business_id,
    auth.uid(),
    lower(tg_op),
    tg_table_name,
    v_entity_id,
    case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) else null end,
    case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) else null end
  );
  return coalesce(new, old);
end;
$$;

create trigger categories_audit after insert or update or delete on public.categories for each row execute function public.audit_row_change();
create trigger products_audit after insert or update or delete on public.products for each row execute function public.audit_row_change();
create trigger customers_audit after insert or update or delete on public.customers for each row execute function public.audit_row_change();
create trigger expenses_audit after insert or update or delete on public.expenses for each row execute function public.audit_row_change();

-- Tight grants: RLS plus column grants. Stock and financial ledgers are RPC-only.
revoke all on all tables in schema public from anon;
revoke all on all tables in schema public from authenticated;
grant select on public.subscription_plans to anon, authenticated;
grant select on public.profiles, public.businesses, public.business_members, public.subscriptions,
  public.categories, public.products, public.customers, public.sales, public.sale_items,
  public.expenses, public.stock_movements, public.debt_payments, public.audit_logs to authenticated;
grant update (full_name, phone, preferred_language) on public.profiles to authenticated;
grant update (name, business_type, country_code, currency_code, phone, address, preferred_language, timezone, allow_negative_stock) on public.businesses to authenticated;
grant insert (business_id, name) on public.categories to authenticated;
grant update (name, archived_at) on public.categories to authenticated;
grant insert (business_id, category_id, name, sku, purchase_cost, selling_price, low_stock_threshold, created_by) on public.products to authenticated;
grant update (category_id, name, sku, purchase_cost, selling_price, low_stock_threshold, archived_at) on public.products to authenticated;
grant insert (business_id, name, phone, email, address, notes, created_by) on public.customers to authenticated;
grant update (name, phone, email, address, notes, archived_at) on public.customers to authenticated;
grant insert (business_id, category, description, amount, expense_date, payment_method, created_by) on public.expenses to authenticated;
grant update (category, description, amount, expense_date, payment_method, archived_at) on public.expenses to authenticated;
grant insert (business_id, user_id, role, permissions, status) on public.business_members to authenticated;
grant update (role, permissions, status) on public.business_members to authenticated;
grant delete on public.business_members to authenticated;
grant usage, select on sequence public.audit_logs_id_seq to authenticated;
