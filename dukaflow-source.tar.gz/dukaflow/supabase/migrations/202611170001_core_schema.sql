-- DukaFlow core schema
-- Generated 2026-11-17. Money values use numeric, never floating point.

create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  preferred_language text not null default 'en' check (preferred_language in ('en','sw')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete restrict,
  name text not null check (char_length(trim(name)) between 2 and 120),
  business_type text not null,
  country_code text not null default 'TZ' check (char_length(country_code) = 2),
  currency_code text not null default 'TZS' check (char_length(currency_code) = 3),
  phone text,
  address text,
  preferred_language text not null default 'en' check (preferred_language in ('en','sw')),
  timezone text not null default 'Africa/Dar_es_Salaam',
  allow_negative_stock boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.business_members (
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'staff' check (role in ('owner','admin','manager','cashier','staff','viewer')),
  permissions jsonb not null default '{}'::jsonb,
  status text not null default 'active' check (status in ('invited','active','suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (business_id, user_id)
);

create table public.subscription_plans (
  code text primary key,
  name text not null,
  description text,
  limits jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

insert into public.subscription_plans (code, name, description, limits, sort_order) values
  ('free', 'Free', 'Core tools for a small business getting started', '{"staff":1,"products":100}'::jsonb, 10),
  ('starter', 'Starter', 'More products and day-to-day operations', '{"staff":3,"products":1000}'::jsonb, 20),
  ('business', 'Business', 'Advanced controls for growing teams', '{"staff":15,"products":10000}'::jsonb, 30),
  ('enterprise', 'Enterprise', 'Custom limits and support', '{}'::jsonb, 40)
on conflict (code) do nothing;

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null unique references public.businesses(id) on delete cascade,
  plan_code text not null default 'free' references public.subscription_plans(code),
  status text not null default 'active' check (status in ('trialing','active','past_due','paused','canceled')),
  current_period_start timestamptz,
  current_period_end timestamptz,
  external_provider text,
  external_customer_id text,
  external_subscription_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 80),
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index categories_business_name_active_uidx on public.categories (business_id, lower(name)) where archived_at is null;
-- Required by the composite foreign key from products.
create unique index categories_business_id_id_uidx on public.categories (business_id, id);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  name text not null check (char_length(trim(name)) between 1 and 160),
  sku text,
  purchase_cost numeric(18,2) not null default 0 check (purchase_cost >= 0),
  selling_price numeric(18,2) not null default 0 check (selling_price >= 0),
  quantity_stock numeric(18,3) not null default 0,
  low_stock_threshold numeric(18,3) not null default 0 check (low_stock_threshold >= 0),
  archived_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint product_category_same_business foreign key (business_id, category_id)
    references public.categories(business_id, id) deferrable initially deferred
);
create unique index products_business_sku_active_uidx on public.products (business_id, lower(sku)) where sku is not null and archived_at is null;
create index products_business_active_idx on public.products (business_id, archived_at, name);
create index products_low_stock_idx on public.products (business_id, quantity_stock, low_stock_threshold) where archived_at is null;

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 160),
  phone text,
  email text,
  address text,
  notes text,
  archived_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index customers_business_active_idx on public.customers (business_id, archived_at, name);
create index customers_phone_idx on public.customers (business_id, phone);

create table public.business_counters (
  business_id uuid primary key references public.businesses(id) on delete cascade,
  next_sale_number bigint not null default 1 check (next_sale_number > 0)
);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete restrict,
  customer_id uuid references public.customers(id) on delete set null,
  sale_number text not null,
  sold_at timestamptz not null default now(),
  subtotal numeric(18,2) not null check (subtotal >= 0),
  discount numeric(18,2) not null default 0 check (discount >= 0),
  total numeric(18,2) not null check (total >= 0),
  cost_total numeric(18,2) not null default 0 check (cost_total >= 0),
  initial_amount_paid numeric(18,2) not null default 0 check (initial_amount_paid >= 0),
  amount_paid numeric(18,2) not null default 0 check (amount_paid >= 0),
  payment_method text not null check (payment_method in ('cash','mobile_money','bank_transfer','other')),
  payment_status text not null check (payment_status in ('paid','partially_paid','unpaid')),
  status text not null default 'completed' check (status in ('completed','reversed')),
  note text,
  idempotency_key uuid not null,
  created_by uuid not null references auth.users(id) on delete restrict,
  reversed_by uuid references auth.users(id) on delete restrict,
  reversed_at timestamptz,
  reversal_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, sale_number),
  unique (business_id, idempotency_key),
  check (discount <= subtotal),
  check (total = subtotal - discount),
  check (initial_amount_paid <= amount_paid),
  check (amount_paid <= total)
);
create index sales_business_sold_at_idx on public.sales (business_id, sold_at desc);
create index sales_customer_idx on public.sales (business_id, customer_id, sold_at desc);
create index sales_outstanding_idx on public.sales (business_id, payment_status, status) where payment_status <> 'paid';
-- Required by the composite foreign key from sale_items.
create unique index sales_business_id_id_uidx on public.sales (business_id, id);

create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete restrict,
  sale_id uuid not null references public.sales(id) on delete restrict,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  product_sku text,
  quantity numeric(18,3) not null check (quantity > 0),
  unit_price numeric(18,2) not null check (unit_price >= 0),
  unit_cost numeric(18,2) not null check (unit_cost >= 0),
  line_subtotal numeric(18,2) not null check (line_subtotal >= 0),
  created_at timestamptz not null default now(),
  constraint sale_item_sale_same_business foreign key (business_id, sale_id)
    references public.sales(business_id, id) deferrable initially deferred
);
create index sale_items_sale_idx on public.sale_items (sale_id);
create index sale_items_product_idx on public.sale_items (business_id, product_id);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  category text not null check (char_length(trim(category)) between 1 and 80),
  description text not null check (char_length(trim(description)) between 1 and 300),
  amount numeric(18,2) not null check (amount > 0),
  expense_date date not null default current_date,
  payment_method text not null check (payment_method in ('cash','mobile_money','bank_transfer','other')),
  archived_at timestamptz,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index expenses_business_date_idx on public.expenses (business_id, expense_date desc) where archived_at is null;
create index expenses_category_idx on public.expenses (business_id, category, expense_date desc) where archived_at is null;

create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  movement_type text not null check (movement_type in ('opening','stock_in','sale','sale_reversal','adjustment')),
  quantity_delta numeric(18,3) not null check (quantity_delta <> 0),
  quantity_before numeric(18,3) not null,
  quantity_after numeric(18,3) not null,
  unit_cost numeric(18,2),
  reason text,
  reference_type text,
  reference_id uuid,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  check (quantity_after = quantity_before + quantity_delta)
);
create index stock_movements_business_created_idx on public.stock_movements (business_id, created_at desc);
create index stock_movements_product_idx on public.stock_movements (product_id, created_at desc);

create table public.debt_payments (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete restrict,
  customer_id uuid not null references public.customers(id) on delete restrict,
  sale_id uuid not null references public.sales(id) on delete restrict,
  amount numeric(18,2) not null check (amount > 0),
  paid_at timestamptz not null default now(),
  payment_method text not null check (payment_method in ('cash','mobile_money','bank_transfer','other')),
  note text,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);
create index debt_payments_sale_idx on public.debt_payments (sale_id, paid_at desc);
create index debt_payments_customer_idx on public.debt_payments (business_id, customer_id, paid_at desc);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  business_id uuid not null references public.businesses(id) on delete restrict,
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  before_data jsonb,
  after_data jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_business_created_idx on public.audit_logs (business_id, created_at desc);
create index audit_logs_entity_idx on public.audit_logs (business_id, entity_type, entity_id);

-- Generic timestamps.
create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_set_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger businesses_set_updated_at before update on public.businesses for each row execute function public.set_updated_at();
create trigger members_set_updated_at before update on public.business_members for each row execute function public.set_updated_at();
create trigger subscriptions_set_updated_at before update on public.subscriptions for each row execute function public.set_updated_at();
create trigger categories_set_updated_at before update on public.categories for each row execute function public.set_updated_at();
create trigger products_set_updated_at before update on public.products for each row execute function public.set_updated_at();
create trigger customers_set_updated_at before update on public.customers for each row execute function public.set_updated_at();
create trigger sales_set_updated_at before update on public.sales for each row execute function public.set_updated_at();
create trigger expenses_set_updated_at before update on public.expenses for each row execute function public.set_updated_at();

-- Auth profile bootstrap.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, phone, preferred_language)
  values (
    new.id,
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'full_name', '')), ''),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'phone', '')), ''),
    case when new.raw_user_meta_data ->> 'preferred_language' = 'sw' then 'sw' else 'en' end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();
