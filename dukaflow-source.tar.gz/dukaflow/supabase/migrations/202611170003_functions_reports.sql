-- DukaFlow transactional RPCs and accounting reports.

create or replace function public.create_business(
  p_name text,
  p_business_type text,
  p_country_code text default 'TZ',
  p_currency_code text default 'TZS',
  p_phone text default null,
  p_address text default null,
  p_preferred_language text default 'en',
  p_timezone text default 'Africa/Dar_es_Salaam'
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_business uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if char_length(trim(coalesce(p_name, ''))) < 2 then raise exception 'Business name is required'; end if;
  if char_length(trim(coalesce(p_business_type, ''))) < 2 then raise exception 'Business type is required'; end if;
  if upper(coalesce(p_currency_code, '')) !~ '^[A-Z]{3}$' then raise exception 'Invalid currency code'; end if;
  if upper(coalesce(p_country_code, '')) !~ '^[A-Z]{2}$' then raise exception 'Invalid country code'; end if;
  if p_preferred_language not in ('en','sw') then raise exception 'Unsupported language'; end if;

  insert into public.businesses (owner_id, name, business_type, country_code, currency_code, phone, address, preferred_language, timezone)
  values (v_user, trim(p_name), trim(p_business_type), upper(p_country_code), upper(p_currency_code), nullif(trim(p_phone),''), nullif(trim(p_address),''), p_preferred_language, p_timezone)
  returning id into v_business;

  insert into public.business_members (business_id, user_id, role, status)
  values (v_business, v_user, 'owner', 'active');
  insert into public.subscriptions (business_id, plan_code, status) values (v_business, 'free', 'active');
  insert into public.business_counters (business_id, next_sale_number) values (v_business, 1);
  insert into public.categories (business_id, name) values
    (v_business, 'General'), (v_business, 'Food & Drinks'), (v_business, 'Household')
  on conflict do nothing;
  update public.profiles set preferred_language = p_preferred_language where id = v_user;

  insert into public.audit_logs (business_id, user_id, action, entity_type, entity_id, after_data)
  values (v_business, v_user, 'create', 'businesses', v_business::text, jsonb_build_object('name', trim(p_name), 'plan', 'free'));
  return v_business;
end;
$$;

create or replace function public.create_sale(
  p_business_id uuid,
  p_customer_id uuid,
  p_items jsonb,
  p_discount numeric default 0,
  p_amount_paid numeric default 0,
  p_payment_method text default 'cash',
  p_sold_at timestamptz default now(),
  p_note text default null,
  p_idempotency_key uuid default gen_random_uuid()
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_member public.business_members%rowtype;
  v_business public.businesses%rowtype;
  v_product public.products%rowtype;
  v_item jsonb;
  v_qty numeric(18,3);
  v_unit_price numeric(18,2);
  v_subtotal numeric(18,2) := 0;
  v_cost_total numeric(18,2) := 0;
  v_discount numeric(18,2) := round(coalesce(p_discount,0),2);
  v_total numeric(18,2);
  v_paid numeric(18,2) := round(coalesce(p_amount_paid,0),2);
  v_status text;
  v_sale_id uuid;
  v_existing uuid;
  v_counter bigint;
  v_sale_number text;
  v_before numeric(18,3);
  v_after numeric(18,3);
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select * into v_member from public.business_members
    where business_id = p_business_id and user_id = v_user and status = 'active';
  if not found or v_member.role not in ('owner','admin','manager','cashier') then raise exception 'Not permitted to create sales'; end if;
  select * into v_business from public.businesses where id = p_business_id;

  select id into v_existing from public.sales where business_id = p_business_id and idempotency_key = p_idempotency_key;
  if v_existing is not null then return v_existing; end if;

  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'A sale must contain at least one item';
  end if;
  if jsonb_array_length(p_items) > 100 then raise exception 'A sale cannot contain more than 100 items'; end if;
  if exists (
    select 1 from jsonb_array_elements(p_items) e
    group by e ->> 'product_id' having count(*) > 1
  ) then raise exception 'Duplicate products are not allowed; combine their quantities'; end if;
  if p_payment_method not in ('cash','mobile_money','bank_transfer','other') then raise exception 'Invalid payment method'; end if;
  if p_sold_at > now() + interval '1 day' then raise exception 'Sale date cannot be in the future'; end if;
  if v_discount < 0 or v_paid < 0 then raise exception 'Amounts cannot be negative'; end if;
  if v_discount > 0 and not (
    v_member.role in ('owner','admin','manager') or coalesce((v_member.permissions ->> 'allow_discounts')::boolean,false)
  ) then raise exception 'You do not have permission to apply a discount'; end if;
  if p_customer_id is not null and not exists (
    select 1 from public.customers where id = p_customer_id and business_id = p_business_id and archived_at is null
  ) then raise exception 'Customer does not belong to this business'; end if;

  -- Lock every product in deterministic order and calculate authoritative totals.
  for v_item in select value from jsonb_array_elements(p_items) order by value ->> 'product_id'
  loop
    begin
      v_qty := round((v_item ->> 'quantity')::numeric,3);
    exception when others then raise exception 'Invalid item quantity'; end;
    if v_qty <= 0 then raise exception 'Item quantity must be greater than zero'; end if;
    select * into v_product from public.products
      where id = (v_item ->> 'product_id')::uuid and business_id = p_business_id and archived_at is null
      for update;
    if not found then raise exception 'Product is unavailable'; end if;
    v_unit_price := round(coalesce(nullif(v_item ->> 'unit_price','')::numeric, v_product.selling_price),2);
    if v_unit_price < 0 then raise exception 'Selling price cannot be negative'; end if;
    if v_unit_price is distinct from v_product.selling_price and not (
      v_member.role in ('owner','admin') or coalesce((v_member.permissions ->> 'allow_price_override')::boolean,false)
    ) then raise exception 'You do not have permission to override prices'; end if;
    if not v_business.allow_negative_stock and v_product.quantity_stock < v_qty then
      raise exception 'Insufficient stock for %', v_product.name;
    end if;
    v_subtotal := v_subtotal + round(v_qty * v_unit_price,2);
    v_cost_total := v_cost_total + round(v_qty * v_product.purchase_cost,2);
  end loop;

  v_subtotal := round(v_subtotal,2);
  v_cost_total := round(v_cost_total,2);
  if v_discount > v_subtotal then raise exception 'Discount cannot exceed subtotal'; end if;
  v_total := v_subtotal - v_discount;
  if v_paid > v_total then raise exception 'Amount paid cannot exceed total'; end if;
  if v_paid < v_total and p_customer_id is null then raise exception 'A customer is required for credit sales'; end if;
  v_status := case when v_paid = 0 and v_total > 0 then 'unpaid' when v_paid < v_total then 'partially_paid' else 'paid' end;

  update public.business_counters
    set next_sale_number = next_sale_number + 1
    where business_id = p_business_id
    returning next_sale_number - 1 into v_counter;
  if v_counter is null then raise exception 'Business sale counter is missing'; end if;
  v_sale_number := 'SL-' || to_char(p_sold_at at time zone v_business.timezone, 'YYYYMM') || '-' || lpad(v_counter::text, 6, '0');

  insert into public.sales (
    business_id, customer_id, sale_number, sold_at, subtotal, discount, total, cost_total,
    initial_amount_paid, amount_paid, payment_method, payment_status, status, note, idempotency_key, created_by
  ) values (
    p_business_id, p_customer_id, v_sale_number, p_sold_at, v_subtotal, v_discount, v_total, v_cost_total,
    v_paid, v_paid, p_payment_method, v_status, 'completed', nullif(trim(p_note),''), p_idempotency_key, v_user
  ) returning id into v_sale_id;

  for v_item in select value from jsonb_array_elements(p_items) order by value ->> 'product_id'
  loop
    v_qty := round((v_item ->> 'quantity')::numeric,3);
    select * into v_product from public.products
      where id = (v_item ->> 'product_id')::uuid and business_id = p_business_id
      for update;
    v_unit_price := round(coalesce(nullif(v_item ->> 'unit_price','')::numeric, v_product.selling_price),2);
    v_before := v_product.quantity_stock;
    v_after := v_before - v_qty;

    insert into public.sale_items (business_id, sale_id, product_id, product_name, product_sku, quantity, unit_price, unit_cost, line_subtotal)
    values (p_business_id, v_sale_id, v_product.id, v_product.name, v_product.sku, v_qty, v_unit_price, v_product.purchase_cost, round(v_qty*v_unit_price,2));
    update public.products set quantity_stock = v_after where id = v_product.id;
    insert into public.stock_movements (
      business_id, product_id, movement_type, quantity_delta, quantity_before, quantity_after,
      unit_cost, reason, reference_type, reference_id, created_by
    ) values (
      p_business_id, v_product.id, 'sale', -v_qty, v_before, v_after,
      v_product.purchase_cost, 'Completed sale ' || v_sale_number, 'sale', v_sale_id, v_user
    );
  end loop;

  insert into public.audit_logs (business_id, user_id, action, entity_type, entity_id, after_data)
  values (p_business_id, v_user, 'create', 'sales', v_sale_id::text,
    jsonb_build_object('sale_number',v_sale_number,'total',v_total,'amount_paid',v_paid,'payment_status',v_status));
  return v_sale_id;
end;
$$;

create or replace function public.reverse_sale(p_business_id uuid, p_sale_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_sale public.sales%rowtype;
  v_item public.sale_items%rowtype;
  v_product public.products%rowtype;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if not public.has_business_role(p_business_id, array['owner','admin','manager']) then raise exception 'Not permitted to reverse sales'; end if;
  if char_length(trim(coalesce(p_reason,''))) < 3 then raise exception 'A reversal reason is required'; end if;
  select * into v_sale from public.sales where id = p_sale_id and business_id = p_business_id for update;
  if not found then raise exception 'Sale not found'; end if;
  if v_sale.status <> 'completed' then raise exception 'Sale has already been reversed'; end if;
  if exists (select 1 from public.debt_payments where sale_id = p_sale_id) then
    raise exception 'Reverse debt repayments before reversing this sale';
  end if;

  for v_item in select * from public.sale_items where sale_id = p_sale_id order by product_id
  loop
    if v_item.product_id is not null then
      select * into v_product from public.products where id = v_item.product_id for update;
      if found then
        update public.products set quantity_stock = v_product.quantity_stock + v_item.quantity where id = v_product.id;
        insert into public.stock_movements (
          business_id, product_id, movement_type, quantity_delta, quantity_before, quantity_after,
          unit_cost, reason, reference_type, reference_id, created_by
        ) values (
          p_business_id, v_product.id, 'sale_reversal', v_item.quantity, v_product.quantity_stock,
          v_product.quantity_stock + v_item.quantity, v_item.unit_cost, trim(p_reason), 'sale', p_sale_id, v_user
        );
      end if;
    end if;
  end loop;
  update public.sales set status='reversed', reversed_by=v_user, reversed_at=now(), reversal_reason=trim(p_reason)
    where id=p_sale_id;
  insert into public.audit_logs (business_id,user_id,action,entity_type,entity_id,before_data,after_data)
  values (p_business_id,v_user,'reverse','sales',p_sale_id::text,to_jsonb(v_sale),jsonb_build_object('status','reversed','reason',trim(p_reason)));
end;
$$;

create or replace function public.record_stock_movement(
  p_business_id uuid,
  p_product_id uuid,
  p_movement_type text,
  p_quantity numeric,
  p_reason text,
  p_unit_cost numeric default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_product public.products%rowtype;
  v_business public.businesses%rowtype;
  v_delta numeric(18,3) := round(coalesce(p_quantity,0),3);
  v_after numeric(18,3);
  v_id uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if not public.has_business_role(p_business_id, array['owner','admin','manager']) then raise exception 'Not permitted to change stock'; end if;
  if p_movement_type not in ('stock_in','adjustment') then raise exception 'Invalid stock movement type'; end if;
  if p_movement_type = 'stock_in' and v_delta <= 0 then raise exception 'Stock-in quantity must be positive'; end if;
  if p_movement_type = 'adjustment' and v_delta = 0 then raise exception 'Adjustment cannot be zero'; end if;
  if p_movement_type = 'adjustment' and char_length(trim(coalesce(p_reason,''))) < 3 then raise exception 'An adjustment reason is required'; end if;
  if p_unit_cost is not null and p_unit_cost < 0 then raise exception 'Unit cost cannot be negative'; end if;

  select * into v_business from public.businesses where id=p_business_id;
  select * into v_product from public.products where id=p_product_id and business_id=p_business_id and archived_at is null for update;
  if not found then raise exception 'Product not found'; end if;
  v_after := v_product.quantity_stock + v_delta;
  if not v_business.allow_negative_stock and v_after < 0 then raise exception 'This adjustment would create negative stock'; end if;

  update public.products set
    quantity_stock=v_after,
    purchase_cost=case when p_movement_type='stock_in' and p_unit_cost is not null then round(p_unit_cost,2) else purchase_cost end
  where id=p_product_id;
  insert into public.stock_movements (
    business_id,product_id,movement_type,quantity_delta,quantity_before,quantity_after,unit_cost,reason,reference_type,created_by
  ) values (
    p_business_id,p_product_id,p_movement_type,v_delta,v_product.quantity_stock,v_after,
    coalesce(round(p_unit_cost,2),v_product.purchase_cost),nullif(trim(p_reason),''),'manual',v_user
  ) returning id into v_id;
  insert into public.audit_logs (business_id,user_id,action,entity_type,entity_id,before_data,after_data)
  values (p_business_id,v_user,p_movement_type,'products',p_product_id::text,
    jsonb_build_object('quantity_stock',v_product.quantity_stock),jsonb_build_object('quantity_stock',v_after,'reason',p_reason));
  return v_id;
end;
$$;

create or replace function public.record_debt_payment(
  p_business_id uuid,
  p_sale_id uuid,
  p_amount numeric,
  p_payment_method text,
  p_paid_at timestamptz default now(),
  p_note text default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_sale public.sales%rowtype;
  v_amount numeric(18,2) := round(coalesce(p_amount,0),2);
  v_new_paid numeric(18,2);
  v_payment_id uuid;
  v_status text;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if not public.has_business_role(p_business_id, array['owner','admin','manager','cashier']) then raise exception 'Not permitted to record repayments'; end if;
  if v_amount <= 0 then raise exception 'Payment amount must be greater than zero'; end if;
  if p_payment_method not in ('cash','mobile_money','bank_transfer','other') then raise exception 'Invalid payment method'; end if;
  if p_paid_at > now() + interval '1 day' then raise exception 'Payment date cannot be in the future'; end if;
  select * into v_sale from public.sales where id=p_sale_id and business_id=p_business_id for update;
  if not found or v_sale.status <> 'completed' then raise exception 'Active sale not found'; end if;
  if v_sale.customer_id is null then raise exception 'Sale has no customer'; end if;
  if v_amount > v_sale.total-v_sale.amount_paid then raise exception 'Payment exceeds outstanding balance'; end if;
  v_new_paid := v_sale.amount_paid + v_amount;
  v_status := case when v_new_paid >= v_sale.total then 'paid' else 'partially_paid' end;
  insert into public.debt_payments (business_id,customer_id,sale_id,amount,paid_at,payment_method,note,created_by)
  values (p_business_id,v_sale.customer_id,p_sale_id,v_amount,p_paid_at,p_payment_method,nullif(trim(p_note),''),v_user)
  returning id into v_payment_id;
  update public.sales set amount_paid=v_new_paid,payment_status=v_status where id=p_sale_id;
  insert into public.audit_logs (business_id,user_id,action,entity_type,entity_id,before_data,after_data)
  values (p_business_id,v_user,'debt_payment','sales',p_sale_id::text,
    jsonb_build_object('amount_paid',v_sale.amount_paid,'outstanding',v_sale.total-v_sale.amount_paid),
    jsonb_build_object('amount_paid',v_new_paid,'outstanding',v_sale.total-v_new_paid,'payment_id',v_payment_id));
  return v_payment_id;
end;
$$;

create or replace function public.get_dashboard_metrics(p_business_id uuid, p_start date, p_end date)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_timezone text;
  v_today date;
  v_result jsonb;
begin
  if auth.uid() is null or not public.is_business_member(p_business_id) then raise exception 'Access denied'; end if;
  if p_start is null or p_end is null or p_start > p_end or p_end-p_start > 3660 then raise exception 'Invalid date range'; end if;
  select timezone into v_timezone from public.businesses where id=p_business_id;
  v_today := (now() at time zone v_timezone)::date;

  with
  period_sales as (
    select * from public.sales s where s.business_id=p_business_id and s.status='completed'
      and (s.sold_at at time zone v_timezone)::date between p_start and p_end
  ),
  period_expenses as (
    select * from public.expenses e where e.business_id=p_business_id and e.archived_at is null
      and e.expense_date between p_start and p_end
  ),
  initial_cash as (select coalesce(sum(initial_amount_paid),0) amount from period_sales),
  repayment_cash as (
    select coalesce(sum(dp.amount),0) amount from public.debt_payments dp
    join public.sales s on s.id=dp.sale_id and s.status='completed'
    where dp.business_id=p_business_id and (dp.paid_at at time zone v_timezone)::date between p_start and p_end
  ),
  totals as (
    select
      coalesce(sum(ps.total),0) revenue,
      coalesce(sum(ps.cost_total),0) cogs,
      coalesce(sum(ps.total-ps.initial_amount_paid),0) credit_sales,
      (select coalesce(sum(pe.amount),0) from period_expenses pe) expenses,
      (select amount from initial_cash)+(select amount from repayment_cash) cash_collected
    from period_sales ps
  ),
  recent as (
    select coalesce(jsonb_agg(to_jsonb(r) order by r.sold_at desc),'[]'::jsonb) data from (
      select s.id,s.sale_number,s.sold_at,s.total,s.payment_status,s.status,c.name customer_name
      from public.sales s left join public.customers c on c.id=s.customer_id
      where s.business_id=p_business_id order by s.sold_at desc limit 6
    ) r
  ),
  series as (
    select coalesce(jsonb_agg(jsonb_build_object(
      'date',d.day::date,
      'sales',coalesce(sa.sales,0),
      'gross_profit',coalesce(sa.gross_profit,0),
      'expenses',coalesce(ex.expenses,0),
      'net_profit',coalesce(sa.gross_profit,0)-coalesce(ex.expenses,0)
    ) order by d.day),'[]'::jsonb) data
    from generate_series(p_start::timestamp,p_end::timestamp,interval '1 day') d(day)
    left join (
      select (sold_at at time zone v_timezone)::date day,sum(total) sales,sum(total-cost_total) gross_profit
      from public.sales where business_id=p_business_id and status='completed'
        and (sold_at at time zone v_timezone)::date between p_start and p_end group by 1
    ) sa on sa.day=d.day::date
    left join (
      select expense_date day,sum(amount) expenses from public.expenses
      where business_id=p_business_id and archived_at is null and expense_date between p_start and p_end group by 1
    ) ex on ex.day=d.day::date
  )
  select jsonb_build_object(
    'today_sales',(select coalesce(sum(total),0) from public.sales where business_id=p_business_id and status='completed' and (sold_at at time zone v_timezone)::date=v_today),
    'month_sales',(select coalesce(sum(total),0) from public.sales where business_id=p_business_id and status='completed' and date_trunc('month',sold_at at time zone v_timezone)=date_trunc('month',v_today::timestamp)),
    'period_sales',t.revenue,
    'cash_collected',t.cash_collected,
    'credit_sales',t.credit_sales,
    'expenses',t.expenses,
    'cogs',t.cogs,
    'gross_profit',t.revenue-t.cogs,
    'net_profit',t.revenue-t.cogs-t.expenses,
    'total_products',(select count(*) from public.products where business_id=p_business_id and archived_at is null),
    'low_stock_products',(select count(*) from public.products where business_id=p_business_id and archived_at is null and quantity_stock<=low_stock_threshold),
    'outstanding_debt',(select coalesce(sum(total-amount_paid),0) from public.sales where business_id=p_business_id and status='completed' and amount_paid<total),
    'recent_sales',(select data from recent),
    'series',(select data from series),
    'start_date',p_start,
    'end_date',p_end
  ) into v_result from totals t;
  return v_result;
end;
$$;

create or replace function public.get_financial_report(p_business_id uuid, p_start date, p_end date)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_timezone text;
  v_result jsonb;
begin
  if auth.uid() is null or not public.is_business_member(p_business_id) then raise exception 'Access denied'; end if;
  if p_start is null or p_end is null or p_start > p_end or p_end-p_start > 3660 then raise exception 'Invalid date range'; end if;
  select timezone into v_timezone from public.businesses where id=p_business_id;
  with
  ps as (
    select * from public.sales where business_id=p_business_id and status='completed'
      and (sold_at at time zone v_timezone)::date between p_start and p_end
  ),
  pe as (
    select * from public.expenses where business_id=p_business_id and archived_at is null and expense_date between p_start and p_end
  ),
  summary as (
    select coalesce(sum(total),0) revenue,coalesce(sum(cost_total),0) cogs,
      coalesce(sum(initial_amount_paid),0) initial_cash,coalesce(sum(total-initial_amount_paid),0) credit_sales
    from ps
  ),
  repayment as (
    select coalesce(sum(dp.amount),0) amount from public.debt_payments dp join public.sales s on s.id=dp.sale_id and s.status='completed'
    where dp.business_id=p_business_id and (dp.paid_at at time zone v_timezone)::date between p_start and p_end
  ),
  products as (
    select coalesce(jsonb_agg(to_jsonb(x) order by x.net_revenue desc),'[]'::jsonb) data from (
      select si.product_id,si.product_name,coalesce(si.product_sku,'') product_sku,sum(si.quantity) quantity_sold,
        round(sum(case when s.subtotal=0 then 0 else si.line_subtotal*(s.total/s.subtotal) end),2) net_revenue,
        round(sum(si.quantity*si.unit_cost),2) cogs,
        round(sum(case when s.subtotal=0 then 0 else si.line_subtotal*(s.total/s.subtotal) end)-sum(si.quantity*si.unit_cost),2) gross_profit
      from public.sale_items si join ps s on s.id=si.sale_id group by si.product_id,si.product_name,si.product_sku limit 100
    ) x
  ),
  expense_categories as (
    select coalesce(jsonb_agg(to_jsonb(x) order by x.amount desc),'[]'::jsonb) data from (
      select category,sum(amount) amount from pe group by category
    ) x
  ),
  trends as (
    select coalesce(jsonb_agg(jsonb_build_object('date',d.day::date,'sales',coalesce(sa.sales,0),'expenses',coalesce(ex.expenses,0)) order by d.day),'[]'::jsonb) data
    from generate_series(p_start::timestamp,p_end::timestamp,interval '1 day') d(day)
    left join (select (sold_at at time zone v_timezone)::date day,sum(total) sales from ps group by 1) sa on sa.day=d.day::date
    left join (select expense_date day,sum(amount) expenses from pe group by 1) ex on ex.day=d.day::date
  )
  select jsonb_build_object(
    'start_date',p_start,'end_date',p_end,
    'revenue',s.revenue,
    'cash_collected',s.initial_cash+(select amount from repayment),
    'credit_sales',s.credit_sales,
    'cogs',s.cogs,
    'gross_profit',s.revenue-s.cogs,
    'expenses',(select coalesce(sum(amount),0) from pe),
    'net_profit',s.revenue-s.cogs-(select coalesce(sum(amount),0) from pe),
    'outstanding_debt',(select coalesce(sum(total-amount_paid),0) from public.sales where business_id=p_business_id and status='completed' and amount_paid<total),
    'inventory_valuation',(select coalesce(sum(quantity_stock*purchase_cost),0) from public.products where business_id=p_business_id and archived_at is null),
    'product_performance',(select data from products),
    'expenses_by_category',(select data from expense_categories),
    'trends',(select data from trends)
  ) into v_result from summary s;
  return v_result;
end;
$$;

create or replace view public.customer_debts
with (security_invoker = true)
as
select s.business_id,s.customer_id,c.name customer_name,c.phone,s.id sale_id,s.sale_number,s.sold_at,
  s.total,s.amount_paid,(s.total-s.amount_paid) outstanding,s.payment_status
from public.sales s
join public.customers c on c.id=s.customer_id
where s.status='completed' and s.amount_paid<s.total;

grant select on public.customer_debts to authenticated;

revoke all on function public.create_business(text,text,text,text,text,text,text,text) from public;
revoke all on function public.create_sale(uuid,uuid,jsonb,numeric,numeric,text,timestamptz,text,uuid) from public;
revoke all on function public.reverse_sale(uuid,uuid,text) from public;
revoke all on function public.record_stock_movement(uuid,uuid,text,numeric,text,numeric) from public;
revoke all on function public.record_debt_payment(uuid,uuid,numeric,text,timestamptz,text) from public;
revoke all on function public.get_dashboard_metrics(uuid,date,date) from public;
revoke all on function public.get_financial_report(uuid,date,date) from public;
grant execute on function public.create_business(text,text,text,text,text,text,text,text) to authenticated;
grant execute on function public.create_sale(uuid,uuid,jsonb,numeric,numeric,text,timestamptz,text,uuid) to authenticated;
grant execute on function public.reverse_sale(uuid,uuid,text) to authenticated;
grant execute on function public.record_stock_movement(uuid,uuid,text,numeric,text,numeric) to authenticated;
grant execute on function public.record_debt_payment(uuid,uuid,numeric,text,timestamptz,text) to authenticated;
grant execute on function public.get_dashboard_metrics(uuid,date,date) to authenticated;
grant execute on function public.get_financial_report(uuid,date,date) to authenticated;
